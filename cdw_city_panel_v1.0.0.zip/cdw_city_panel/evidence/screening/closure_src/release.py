from __future__ import annotations

import hashlib
import json
import shutil
from datetime import UTC, datetime
from pathlib import Path


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def create_release_manifest(
    release_id: str,
    fixed_inputs: dict[str, Path],
    density_ton_per_m3: float,
    maximum_total_attempts: int,
) -> dict:
    inputs = []
    for logical_name, path in sorted(fixed_inputs.items()):
        if not path.is_file():
            raise FileNotFoundError(f"Fixed release input is missing: {logical_name} -> {path}")
        inputs.append(
            {
                "logical_name": logical_name,
                "path": str(path.resolve()),
                "sha256": sha256_file(path),
                "bytes": path.stat().st_size,
            }
        )
    return {
        "release_id": release_id,
        "created_at_utc": datetime.now(UTC).isoformat(),
        "density_ton_per_m3": density_ton_per_m3,
        "maximum_total_attempts": maximum_total_attempts,
        "inputs": inputs,
    }


def freeze_release_inputs(
    run_dir: Path,
    release_id: str,
    fixed_inputs: dict[str, Path],
    density_ton_per_m3: float,
    maximum_total_attempts: int,
) -> dict:
    if run_dir.exists() and any(run_dir.iterdir()):
        raise FileExistsError(f"Refusing to overwrite non-empty release directory: {run_dir}")
    run_dir.mkdir(parents=True, exist_ok=True)
    manifest = create_release_manifest(
        release_id=release_id,
        fixed_inputs=fixed_inputs,
        density_ton_per_m3=density_ton_per_m3,
        maximum_total_attempts=maximum_total_attempts,
    )
    copied_names = {
        "candidate_queue": "frozen_queue.csv",
        "schema": "schema.json",
        "prompt": "prompt.txt",
        "code": "run_closure.py",
    }
    for logical_name, source in fixed_inputs.items():
        shutil.copy2(source, run_dir / copied_names.get(logical_name, source.name))
    (run_dir / "manifest.json").write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    return manifest
