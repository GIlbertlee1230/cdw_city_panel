"""Reproducible sampling for the DeepSeek deployment-audit benchmark.

This is a stratified human audit of the deployed candidate batch.  It is not an
external, document-disjoint benchmark for the earlier BERT pilot.
"""

from __future__ import annotations

from collections.abc import Mapping

import pandas as pd


DEPLOYMENT_AUDIT_QUOTAS: dict[str, int] = {
    "provincial_generation": 70,
    "annual_generation": 20,
    "annual_non_target": 16,
    "municipal_non_target": 14,
}


def _document_balanced_sample(records: pd.DataFrame, n: int, seed: int) -> pd.DataFrame:
    """Sample with a round-robin document preference, then deterministic fallback."""

    if len(records) < n:
        raise ValueError(f"Only {len(records)} eligible records available; need {n}")
    frame = records.copy()
    frame["_document_key"] = frame["source_file_name"].fillna("").astype(str).str.strip()
    frame.loc[frame["_document_key"] == "", "_document_key"] = (
        "field_" + frame.loc[frame["_document_key"] == "", "field_id"].astype(str)
    )
    frame = frame.sample(frac=1, random_state=seed).reset_index(drop=True)
    buckets = {
        name: group.index.tolist()
        for name, group in frame.groupby("_document_key", sort=True, dropna=False)
    }
    selected_indices: list[int] = []
    while len(selected_indices) < n:
        progressed = False
        for name in sorted(buckets):
            if buckets[name] and len(selected_indices) < n:
                selected_indices.append(buckets[name].pop(0))
                progressed = True
        if not progressed:
            break
    return frame.loc[selected_indices].drop(columns="_document_key").reset_index(drop=True)


def _stratum_mask(records: pd.DataFrame, stratum: str) -> pd.Series:
    generation = records["indicator_standard_rule"].eq("cdw_generation_total")
    source = records["field_source_level"]
    masks = {
        "provincial_generation": source.eq("省级计划") & generation,
        "annual_generation": source.eq("每年披露") & generation,
        "annual_non_target": source.eq("每年披露") & ~generation,
        "municipal_non_target": source.eq("市级计划") & ~generation,
    }
    return masks[stratum]


def select_deployment_audit(
    records: pd.DataFrame,
    *,
    seed: int,
    quotas: Mapping[str, int] = DEPLOYMENT_AUDIT_QUOTAS,
) -> pd.DataFrame:
    """Return a 120-record blind human-audit sample with locked source strata."""

    required = {"field_id", "field_source_level", "indicator_standard_rule", "source_file_name"}
    missing = sorted(required - set(records.columns))
    if missing:
        raise ValueError(f"Candidate queue is missing required columns: {', '.join(missing)}")
    selections: list[pd.DataFrame] = []
    for position, (stratum, quota) in enumerate(quotas.items()):
        eligible = records.loc[_stratum_mask(records, stratum)].copy()
        if len(eligible) < quota:
            raise ValueError(f"{stratum}: only {len(eligible)} eligible candidates; need {quota}")
        chosen = _document_balanced_sample(eligible, quota, seed + position)
        chosen["benchmark_stratum"] = stratum
        selections.append(chosen)
    selected = pd.concat(selections, ignore_index=True)
    if not selected["field_id"].is_unique:
        raise ValueError("A candidate was selected more than once across benchmark strata")
    selected.insert(0, "benchmark_id", [f"DSA-{index:03d}" for index in range(1, len(selected) + 1)])
    return selected
