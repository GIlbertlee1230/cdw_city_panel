"""Auditable post-run closure checks for the r04 DeepSeek deployment batch."""

from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd

from models import ExtractionResponse
from validation import validate_response


SOURCE_RANK = {"省级计划": 3, "市级计划": 2, "每年披露": 1}
PANEL_EXCLUSIONS = {
    ("肇庆", 2018), ("肇庆", 2019), ("肇庆", 2020),
    ("阳江", 2018), ("阳江", 2019), ("阳江", 2020),
    ("中山", 2018),
}


def normalize_city(value: object) -> str:
    return str(value).strip().replace("市", "")


def final_attempts(api_audit: pd.DataFrame) -> pd.DataFrame:
    ordered = api_audit.sort_values(["field_id", "attempt_number"], kind="stable")
    return ordered.groupby("field_id", as_index=False, sort=False).tail(1).copy()


def _nullable(value: object) -> object | None:
    return None if pd.isna(value) else value


def posthoc_revalidate(api_final: pd.DataFrame) -> pd.DataFrame:
    """Reapply deterministic validation after Unicode-safe text normalisation changes."""

    frame = api_final.copy()
    refreshed_errors: list[str] = []
    for _, row in frame.iterrows():
        original_errors = "" if pd.isna(row.get("validation_error_codes")) else str(row["validation_error_codes"])
        # Only an otherwise structured response whose sole failure was quote grounding
        # can be repaired by Unicode-safe comparison. A schema/API failure remains a
        # raw-run failure and must not be reinterpreted post hoc.
        if original_errors != "EVIDENCE_NOT_FOUND":
            refreshed_errors.append(original_errors)
            continue
        try:
            response = ExtractionResponse.model_validate(
                {
                    "decision": row["decision"],
                    "indicator_type": row["indicator_type"],
                    "city": _nullable(row["llm_city"]),
                    "data_year": _nullable(row["llm_data_year"]),
                    "raw_value": _nullable(row["llm_raw_value"]),
                    "raw_unit": _nullable(row["llm_raw_unit"]),
                    "evidence_quote": _nullable(row["llm_evidence_quote"]),
                    "rationale": _nullable(row["llm_rationale"]),
                    "confidence": _nullable(row["llm_confidence"]),
                }
            )
            validation = validate_response(
                response=response,
                evidence_text=str(row["evidence_text"]),
                rule_city=str(row["city"]),
                rule_year=int(row["year"]) if pd.notna(row["year"]) else None,
            )
            refreshed_errors.append(";".join(validation.error_codes))
        except (ValueError, TypeError):
            refreshed_errors.append(original_errors)
    frame["posthoc_validation_error_codes"] = refreshed_errors
    frame["validation_repaired_by_unicode_normalisation"] = (
        frame["validation_error_codes"].fillna("").astype(str).ne(frame["posthoc_validation_error_codes"])
    )
    return frame


def _blank(value: object) -> bool:
    return pd.isna(value) or not str(value).strip()


def derive_human_labels(annotation: pd.DataFrame) -> pd.DataFrame:
    """Derive analysis-ready labels without altering the human-authored cells."""

    labels = annotation.copy()
    labels["human_final_decision"] = labels["human_final_decision"].astype(str).str.strip().str.lower()
    labels["human_positive"] = labels["human_final_decision"].isin(["accepted", "corrected"])
    if "human_evidence_quote" not in labels:
        labels["human_evidence_quote"] = ""
    if "evidence_text" not in labels:
        labels["evidence_text"] = ""
    labels["resolved_evidence_quote"] = labels["human_evidence_quote"]
    missing_quote = labels["resolved_evidence_quote"].map(_blank)
    labels.loc[missing_quote, "resolved_evidence_quote"] = labels.loc[missing_quote, "evidence_text"]
    labels["evidence_quote_provenance"] = np.where(
        missing_quote, "derived_from_retained_evidence_text", "human_entered"
    )
    return labels


def benchmark_metrics(labels_and_model: pd.DataFrame) -> dict:
    """Return target-versus-nontarget metrics for the blind audit."""

    frame = labels_and_model.copy()
    if "human_positive" not in frame:
        frame = derive_human_labels(frame)
    frame["model_positive"] = frame["decision"].astype(str).str.strip().str.lower().eq("accept")
    tp = int((frame["human_positive"] & frame["model_positive"]).sum())
    fp = int((~frame["human_positive"] & frame["model_positive"]).sum())
    fn = int((frame["human_positive"] & ~frame["model_positive"]).sum())
    tn = int((~frame["human_positive"] & ~frame["model_positive"]).sum())
    precision = tp / (tp + fp) if tp + fp else float("nan")
    recall = tp / (tp + fn) if tp + fn else float("nan")
    f1 = 2 * precision * recall / (precision + recall) if precision + recall else float("nan")
    return {
        "n": int(len(frame)),
        "confusion_matrix": {"tp": tp, "fp": fp, "fn": fn, "tn": tn},
        "accuracy": (tp + tn) / len(frame) if len(frame) else float("nan"),
        "precision": precision,
        "recall": recall,
        "f1": f1,
    }


def extract_b1_totals(pdf_path: Path) -> pd.DataFrame:
    """Read the official B1 table with blank cells preserved as null values."""

    import pdfplumber

    rows: list[dict] = []
    current_city: str | None = None
    with pdfplumber.open(pdf_path) as pdf:
        for page_number in range(39, 43):
            table = pdf.pages[page_number - 1].extract_tables()[0]
            for row in table[1:]:
                year = (row[2] or "").strip()
                if not (year.isdigit() and len(year) == 4):
                    continue
                city = (row[1] or "").replace("\n", "").strip()
                if city:
                    current_city = city
                if current_city in (None, "全省"):
                    continue
                total = (row[3] or "").strip()
                rows.append(
                    {
                        "city": current_city,
                        "year": int(year),
                        "official_total": float(total) if total else np.nan,
                        "source_pdf_page": page_number,
                    }
                )
    return pd.DataFrame(rows)


def audit_b1_records(official: pd.DataFrame, candidates: pd.DataFrame) -> pd.DataFrame:
    """Compare PDF cells to parsed candidates, retaining both blank and missing states."""

    merged = official.merge(candidates, on=["city", "year"], how="outer", indicator=True)
    official_blank = merged["official_total"].isna()
    candidate_missing = merged["candidate_total"].isna()
    value_match = np.isclose(
        pd.to_numeric(merged["official_total"], errors="coerce"),
        pd.to_numeric(merged["candidate_total"], errors="coerce"),
        rtol=0,
        atol=1e-10,
        equal_nan=False,
    )
    merged["audit_status"] = np.select(
        [
            official_blank & ~candidate_missing,
            ~official_blank & candidate_missing,
            ~official_blank & ~candidate_missing & value_match,
            ~official_blank & ~candidate_missing & ~value_match,
            official_blank & candidate_missing,
        ],
        [
            "TABLE_BLANK_CELL_SHIFT",
            "MISSING_SOURCE_RECORD",
            "MATCH",
            "VALUE_MISMATCH",
            "SOURCE_BLANK_NO_CANDIDATE",
        ],
        default="UNCLASSIFIED",
    )
    return merged.sort_values(["city", "year"]).reset_index(drop=True)


def select_source_records(
    api_final: pd.DataFrame, *, validation_column: str = "validation_error_codes"
) -> pd.DataFrame:
    """Select one accepted actual-generation candidate per city-year by source priority."""

    frame = api_final.copy()
    frame["district_name"] = frame["city"].map(normalize_city)
    frame["source_rank"] = frame["field_source_level"].map(SOURCE_RANK).fillna(0)
    frame["candidate_value_m3"] = pd.to_numeric(frame["value_m3_if_applicable"], errors="coerce")
    eligible = frame.loc[
        frame["decision"].eq("accept")
        & frame["indicator_type"].eq("cdw_generation_total")
        & frame["candidate_value_m3"].notna()
        & frame[validation_column].map(_blank)
    ].copy()
    eligible["panel_exclusion_code"] = eligible.apply(
        lambda row: "EXCLUDED_BY_LOCKED_PANEL_QUALITY_RULE"
        if (row["district_name"], int(row["year"])) in PANEL_EXCLUSIONS
        else "",
        axis=1,
    )
    eligible = eligible[eligible["panel_exclusion_code"].eq("")].copy()
    eligible = eligible.sort_values(
        ["district_name", "year", "source_rank", "field_id"],
        ascending=[True, True, False, True],
        kind="stable",
    )
    selected = eligible.drop_duplicates(["district_name", "year"], keep="first").copy()
    selected["selected_by_source_priority"] = True
    return selected.reset_index(drop=True)


def validation_blocked_records(
    api_final: pd.DataFrame, *, validation_column: str = "validation_error_codes"
) -> pd.DataFrame:
    """Retain accepted candidate pairs that cannot be auto-selected due to validation errors."""

    frame = api_final.copy()
    frame["district_name"] = frame["city"].map(normalize_city)
    frame["source_rank"] = frame["field_source_level"].map(SOURCE_RANK).fillna(0)
    blocked = frame.loc[
        frame["decision"].eq("accept")
        & frame["indicator_type"].eq("cdw_generation_total")
        & ~frame[validation_column].map(_blank)
    ].copy()
    blocked = blocked.sort_values(
        ["district_name", "year", "source_rank", "field_id"],
        ascending=[True, True, False, True],
        kind="stable",
    )
    if validation_column != "validation_error_codes":
        blocked["validation_error_codes"] = blocked[validation_column]
    return blocked.drop_duplicates(["district_name", "year"], keep="first").reset_index(drop=True)


def reconcile_model_targets(
    model_panel: pd.DataFrame,
    source_selected: pd.DataFrame,
    validation_blocked: pd.DataFrame | None = None,
) -> pd.DataFrame:
    """Map source-selected records to actual rows usable by the locked Part2 model."""

    required_features = ["ln_cdw_m3", "L1_outcome", "L2_ntl", "L2_urban_rate", "L2_fai", "L2_disp_income"]
    targets = model_panel.dropna(subset=required_features).copy()
    targets = targets[["district_name", "year", "C_DW_generation_m3", *required_features]].rename(
        columns={"C_DW_generation_m3": "locked_model_value_m3"}
    )
    selected_columns = [
        "district_name", "year", "field_id", "field_source_level", "source_file_name",
        "source_document_type", "candidate_value_m3", "raw_value", "raw_unit",
    ]
    merged = targets.merge(source_selected[selected_columns], on=["district_name", "year"], how="left")
    if validation_blocked is not None:
        blocked = validation_blocked[["district_name", "year", "field_id", "validation_error_codes"]].rename(
            columns={"field_id": "validation_blocked_field_id"}
        )
        merged = merged.merge(blocked, on=["district_name", "year"], how="left")
    else:
        merged["validation_blocked_field_id"] = np.nan
        merged["validation_error_codes"] = np.nan
    merged["difference_m3"] = merged["candidate_value_m3"] - merged["locked_model_value_m3"]
    direct_exact = merged["candidate_value_m3"].notna() & merged["difference_m3"].abs().le(1e-6)
    rounded = (
        merged["candidate_value_m3"].notna()
        & ~direct_exact
        & merged["difference_m3"].abs().le(34)
    )
    special_zhuhai = merged["district_name"].eq("珠海") & merged["year"].eq(2024)
    blocked = merged["candidate_value_m3"].isna() & merged["validation_blocked_field_id"].notna()
    merged["reconciliation_status"] = np.select(
        [direct_exact, rounded, special_zhuhai, blocked, merged["candidate_value_m3"].isna()],
        [
            "DIRECT_EXACT_MATCH",
            "UNIT_CONVERSION_ROUNDING_MATCH",
            "MANUAL_SOURCE_CORRECTION_REQUIRED",
            "CANDIDATE_REQUIRES_HUMAN_AUDIT",
            "LEGACY_SOURCE_NOT_IN_R04",
        ],
        default="VALUE_CONFLICT_REQUIRES_REVIEW",
    )
    return merged.sort_values(["year", "district_name"]).reset_index(drop=True)


def confirm_zhuhai_2024_planning_attachment(reconciliation: pd.DataFrame) -> pd.DataFrame:
    """Replace the conflicting annual-disclosure candidate with the verified planning attachment.

    The public municipal planning attachment reports the historical 2024 C&DW
    generation total directly in m3 and repeats it in Appendix B1. It is not a
    planning target, capacity, or unit-converted annual-disclosure value.
    """

    frame = reconciliation.copy()
    mask = frame["district_name"].eq("珠海") & frame["year"].eq(2024)
    if int(mask.sum()) != 1:
        raise ValueError("Expected exactly one Zhuhai 2024 reconciliation row")
    updates = {
        "field_id": "OFFICIAL_ATTACHMENT_ZHUHAI_2024_B1",
        "field_source_level": "市级专项规划附件（历史实际披露）",
        "source_file_name": "附件1 珠海市建筑垃圾污染环境防治工作规划（2024-2028年）（征求意见稿）.pdf",
        "source_document_type": "municipal_plan_attachment_historical_actual",
        "candidate_value_m3": 5613300.0,
        "raw_value": 561.33,
        "raw_unit": "万立方米",
        "source_evidence_location": "PDF physical p.13 / printed p.9, Article 8; corroborated by Appendix B1, PDF physical p.58 / printed p.54",
        "reconciliation_status": "OFFICIAL_ATTACHMENT_CONFIRMED",
    }
    for column, value in updates.items():
        if column not in frame:
            frame[column] = pd.Series(index=frame.index, dtype="object" if isinstance(value, str) else "float64")
        elif isinstance(value, str) and not pd.api.types.is_object_dtype(frame[column]):
            frame[column] = frame[column].astype("object")
    for column, value in updates.items():
        frame.loc[mask, column] = value
    frame.loc[mask, "difference_m3"] = (
        frame.loc[mask, "candidate_value_m3"] - frame.loc[mask, "locked_model_value_m3"]
    )
    return frame
