from __future__ import annotations

import json
import re
import unicodedata
from dataclasses import dataclass
from typing import Callable

from pydantic import ValidationError

from models import ExtractionResponse


@dataclass(frozen=True)
class ConversionResult:
    value_m3: float | None
    conversion_rule: str | None
    error_codes: list[str]


@dataclass(frozen=True)
class ValidationResult:
    error_codes: list[str]
    conversion: ConversionResult


@dataclass(frozen=True)
class AttemptRecord:
    attempt_number: int
    raw_content: str
    format_recovered: bool
    response: ExtractionResponse | None
    error_codes: list[str]


def _parse_number(raw_value: str | None) -> float | None:
    if raw_value is None:
        return None
    match = re.search(r"[-+]?\d+(?:[,.，]\d+)?", str(raw_value).replace(",", ""))
    if not match:
        return None
    return float(match.group(0).replace("，", "."))


def _normalise_unit(raw_unit: str | None) -> str:
    if raw_unit is None:
        return ""
    return str(raw_unit).strip().lower().replace("³", "3").replace("m^3", "m3").replace(" ", "")


def standardise_value(
    raw_value: str | None,
    raw_unit: str | None,
    model_value_m3: str | None = None,
) -> ConversionResult:
    """Convert only grounded raw evidence; model_value_m3 is intentionally ignored."""

    del model_value_m3
    value = _parse_number(raw_value)
    unit = _normalise_unit(raw_unit)
    if value is None:
        return ConversionResult(None, None, ["VALUE_NOT_GROUNDED"])
    if unit in {"m3", "立方米", "立方"}:
        return ConversionResult(value, "volume_unit_kept", [])
    if unit in {"万立方米", "万m3", "万立方"}:
        return ConversionResult(value * 10000, "ten_thousand_m3_to_m3", [])
    if unit in {"吨", "t", "ton", "tons"}:
        return ConversionResult(value / 1.5, "ton_to_m3_by_density_1_5", [])
    if unit in {"万吨", "万t", "万ton"}:
        return ConversionResult(value * 10000 / 1.5, "ten_thousand_ton_to_m3_by_density_1_5", [])
    return ConversionResult(None, None, ["UNIT_UNCLEAR"])


def _compact(value: object) -> str:
    normalized = unicodedata.normalize("NFKC", str(value or ""))
    normalized = "".join(
        character for character in normalized if unicodedata.category(character) != "Cf"
    )
    return re.sub(r"[\s，,。；;：:()（）]", "", normalized).lower()


def _norm_city(value: object) -> str:
    text = str(value or "").strip()
    return text[:-1] if text.endswith("市") else text


def validate_response(
    response: ExtractionResponse,
    evidence_text: str,
    rule_city: str,
    rule_year: int | None,
) -> ValidationResult:
    """Validate evidence grounding and return every applicable deterministic flag."""

    codes: list[str] = []
    compact_evidence = _compact(evidence_text)
    quote = _compact(response.evidence_quote)
    if not quote or quote not in compact_evidence:
        codes.append("EVIDENCE_NOT_FOUND")
    if response.raw_value and _compact(response.raw_value) not in compact_evidence:
        codes.append("VALUE_NOT_GROUNDED")
    if response.raw_unit and _compact(response.raw_unit) not in compact_evidence:
        codes.append("UNIT_UNCLEAR")
    if response.indicator_type != "cdw_generation_total":
        codes.append("INDICATOR_NOT_GENERATION")
    if response.city and _norm_city(response.city) != _norm_city(rule_city):
        codes.append("CITY_MISMATCH")
    if rule_year is not None and response.data_year is not None and response.data_year != int(rule_year):
        codes.append("YEAR_MISMATCH")

    conversion = standardise_value(response.raw_value, response.raw_unit)
    codes.extend(code for code in conversion.error_codes if code not in codes)
    if conversion.value_m3 is not None and conversion.value_m3 > 1_000_000_000:
        codes.append("MAGNITUDE_FLAG")
    return ValidationResult(error_codes=codes, conversion=conversion)


def _parse_model_response(raw_content: str) -> tuple[ExtractionResponse, bool]:
    try:
        return ExtractionResponse.model_validate_json(raw_content), False
    except (ValidationError, ValueError):
        start = raw_content.find("{")
        end = raw_content.rfind("}")
        if start < 0 or end <= start:
            raise
        recovered = json.loads(raw_content[start : end + 1])
        return ExtractionResponse.model_validate(recovered), True


def run_with_bounded_retries(
    call_model: Callable[[dict, list[str]], str],
    candidate: dict,
    maximum_total_attempts: int = 3,
) -> list[AttemptRecord]:
    """Call a model at most three times and preserve each raw attempt result."""

    if maximum_total_attempts < 1:
        raise ValueError("maximum_total_attempts must be at least one")
    attempts: list[AttemptRecord] = []
    prior_errors: list[str] = []
    for attempt_number in range(1, maximum_total_attempts + 1):
        raw_content = ""
        try:
            raw_content = call_model(candidate, prior_errors)
            response, format_recovered = _parse_model_response(raw_content)
            validation = validate_response(
                response=response,
                evidence_text=str(candidate.get("evidence_text", "")),
                rule_city=str(candidate.get("city", "")),
                rule_year=candidate.get("year"),
            )
            record = AttemptRecord(
                attempt_number=attempt_number,
                raw_content=raw_content,
                format_recovered=format_recovered,
                response=response,
                error_codes=validation.error_codes,
            )
        except OSError as error:
            record = AttemptRecord(
                attempt_number=attempt_number,
                raw_content=raw_content,
                format_recovered=False,
                response=None,
                error_codes=["API_ERROR", str(error)],
            )
        except (json.JSONDecodeError, ValidationError, ValueError, TypeError) as error:
            record = AttemptRecord(
                attempt_number=attempt_number,
                raw_content=raw_content,
                format_recovered=False,
                response=None,
                error_codes=["SCHEMA_INVALID", str(error)],
            )
        attempts.append(record)
        # A semantic reject/hold is a legitimate model conclusion for an ambiguous
        # or non-target candidate, not a malformed extraction to be retried.
        # Only an attempted acceptance with deterministic failures is repairable.
        if record.response is not None and record.response.decision in {"reject", "hold"}:
            prior_errors = []
        else:
            prior_errors = record.error_codes
        if not prior_errors:
            break
    return attempts
