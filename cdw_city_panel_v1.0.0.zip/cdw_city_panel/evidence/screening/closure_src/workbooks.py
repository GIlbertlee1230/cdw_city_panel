from __future__ import annotations

import itertools
import random
from pathlib import Path

import pandas as pd


SOURCE_RANK = {
    "provincial_actual": 3,
    "municipal_actual": 2,
    "other_actual": 1,
}

HUMAN_AUDIT_COLUMNS = [
    "reviewer_id",
    "review_date",
    "final_decision",
    "corrected_city",
    "corrected_year",
    "corrected_raw_value",
    "corrected_raw_unit",
    "confirmed_value_m3",
    "source_level_confirmed",
    "human_rationale",
    "final_selected_for_panel",
]


def _eligible_rows(records: pd.DataFrame) -> pd.DataFrame:
    frame = records.copy()
    for column, default in {
        "final_decision": "",
        "indicator_type": "",
        "source_level_confirmed": "",
        "district_name": "",
        "year": "",
        "evidence_complete": False,
    }.items():
        if column not in frame.columns:
            frame[column] = default
    frame["final_decision"] = frame["final_decision"].astype(str).str.lower()
    frame["indicator_type"] = frame["indicator_type"].astype(str)
    frame["source_rank"] = frame["source_level_confirmed"].map(SOURCE_RANK).fillna(0)
    return frame[
        (frame["final_decision"] == "accepted")
        & (frame["indicator_type"] == "cdw_generation_total")
        & (frame["source_rank"] > 0)
    ].copy()


def resolve_conflicts(records: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Choose an eligible actual-generation record and retain all duplicate evidence."""

    eligible = _eligible_rows(records)
    if eligible.empty:
        return eligible, eligible
    eligible = eligible.sort_values(
        ["district_name", "year", "source_rank", "evidence_complete"],
        ascending=[True, True, False, False],
    )
    duplicate_mask = eligible.duplicated(["district_name", "year"], keep=False)
    conflicts = eligible.loc[duplicate_mask].copy()
    selected = eligible.drop_duplicates(["district_name", "year"], keep="first").copy()
    selected["final_selected_for_panel"] = True
    return selected.reset_index(drop=True), conflicts.reset_index(drop=True)


def _instruction_sheet() -> pd.DataFrame:
    return pd.DataFrame(
        {
            "instruction": [
                "Review the original evidence text before selecting a final decision.",
                "Use accepted only for observed city-year total C&DW generation with a grounded value and clear unit.",
                "Choose corrected when evidence supports the record but a city, year, value, unit or source field must change.",
                "Provincial actual generation disclosures outrank municipal actual disclosures for the same city-year; plans and targets never override actual generation.",
                "Every panel row requires reviewer ID, date, final decision and factual rationale.",
            ]
        }
    )


def _data_dictionary() -> pd.DataFrame:
    return pd.DataFrame(
        {
            "column": HUMAN_AUDIT_COLUMNS,
            "meaning": [
                "Human reviewer identifier.",
                "Review completion date in YYYY-MM-DD.",
                "accepted, corrected, rejected, or needs_review.",
                "Corrected city without 市, if needed.",
                "Actual data year, if needed.",
                "Raw observed numeric string, if corrected.",
                "Observed unit, if corrected.",
                "Deterministically verified cubic-metre value.",
                "provincial_actual, municipal_actual, other_actual, or a non-eligible source label.",
                "Short factual decision reason.",
                "Set only after conflict resolution; not a reviewer preference field.",
            ],
        }
    )


def export_human_audit_workbook(records: pd.DataFrame, output_path: Path) -> None:
    """Write an editable audit workbook while leaving every original evidence column intact."""

    output_path.parent.mkdir(parents=True, exist_ok=True)
    audit_queue = records.copy()
    for column in HUMAN_AUDIT_COLUMNS:
        if column not in audit_queue.columns:
            audit_queue[column] = ""
    selected, conflicts = resolve_conflicts(audit_queue)
    with pd.ExcelWriter(output_path, engine="openpyxl") as writer:
        _instruction_sheet().to_excel(writer, sheet_name="Instructions", index=False)
        audit_queue.to_excel(writer, sheet_name="Audit_queue", index=False)
        conflicts.to_excel(writer, sheet_name="Conflict_resolution", index=False)
        _data_dictionary().to_excel(writer, sheet_name="Data_dictionary", index=False)


def make_document_disjoint_gold_split(
    records: pd.DataFrame,
    gold_document_count: int,
    seed: int,
) -> pd.DataFrame:
    """Assign all rows from sampled documents to gold, never individual rows."""

    documents = sorted(
        str(value)
        for value in records["source_file_name"].dropna().unique()
        if str(value).strip()
    )
    if gold_document_count < 1 or gold_document_count >= len(documents):
        raise ValueError("gold_document_count must be at least 1 and smaller than the document count")
    gold_documents = set(random.Random(seed).sample(documents, gold_document_count))
    split = records.copy()
    split["split"] = split["source_file_name"].astype(str).map(
        lambda name: "gold" if name in gold_documents else "non_gold"
    )
    split["split_seed"] = seed
    return split


def make_heldout_gold_split(
    records: pd.DataFrame,
    bert_document_names: set[str],
    minimum_candidates: int,
    maximum_candidates: int,
    target_candidates: int,
    seed: int,
) -> pd.DataFrame:
    """Select 100--150 candidates only from documents never used by the BERT pilot."""

    eligible = records.loc[
        ~records["source_file_name"].astype(str).isin({str(name) for name in bert_document_names})
    ].copy()
    document_sizes = eligible.groupby("source_file_name", dropna=True).size().to_dict()
    documents = sorted(str(name) for name in document_sizes)
    random.Random(seed).shuffle(documents)
    best: tuple[float, tuple[str, ...], int] | None = None
    for size in range(1, len(documents) + 1):
        for combo in itertools.combinations(documents, size):
            candidate_count = sum(int(document_sizes[name]) for name in combo)
            if minimum_candidates <= candidate_count <= maximum_candidates:
                score = abs(candidate_count - target_candidates)
                if best is None or score < best[0]:
                    best = (score, combo, candidate_count)
    if best is None:
        raise ValueError("No BERT-disjoint document combination meets the requested gold candidate range")
    gold_documents = set(best[1])
    split = eligible.copy()
    split["split"] = split["source_file_name"].astype(str).map(
        lambda name: "gold" if name in gold_documents else "non_gold_eligible"
    )
    split["split_seed"] = seed
    split["bert_document_disjoint"] = True
    return split


def reconcile_panels(authority: pd.DataFrame, provisional: pd.DataFrame) -> dict:
    """Compare panels without modifying either input or treating either as selected."""

    keys = ["district_name", "year"]
    authority_frame = authority[keys + ["C_DW_generation_m3"]].rename(
        columns={"C_DW_generation_m3": "authority_value_m3"}
    )
    provisional_frame = provisional[keys + ["C_DW_generation_m3"]].rename(
        columns={"C_DW_generation_m3": "provisional_value_m3"}
    )
    merged = authority_frame.merge(provisional_frame, on=keys, how="outer", indicator=True)
    both = merged[merged["_merge"] == "both"].copy()
    both["difference_m3"] = both["provisional_value_m3"] - both["authority_value_m3"]
    exact = both[both["difference_m3"].abs() <= 1e-6].copy()
    different = both[both["difference_m3"].abs() > 1e-6].copy()
    authority_only = merged[merged["_merge"] == "left_only"].copy()
    provisional_only = merged[merged["_merge"] == "right_only"].copy()
    return {
        "summary": {
            "exact_matches": int(len(exact)),
            "value_differences": int(len(different)),
            "authority_only": int(len(authority_only)),
            "provisional_only": int(len(provisional_only)),
        },
        "exact_matches": exact,
        "value_differences": different,
        "authority_only": authority_only,
        "provisional_only": provisional_only,
    }
