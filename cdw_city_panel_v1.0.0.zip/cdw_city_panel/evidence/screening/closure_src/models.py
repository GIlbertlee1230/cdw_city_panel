from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, ConfigDict, Field


Decision = Literal["accept", "reject", "hold"]
IndicatorType = Literal[
    "cdw_generation_total",
    "subcategory",
    "planning_target",
    "facility_capacity",
    "recycling_or_disposal",
    "non_target",
    "uncertain",
]


class ExtractionResponse(BaseModel):
    """The only model-produced record accepted by the closure pipeline."""

    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True)

    decision: Decision
    indicator_type: IndicatorType
    city: str | None = None
    data_year: int | None = Field(default=None, ge=1900, le=2100)
    raw_value: str | None = None
    raw_unit: str | None = None
    evidence_quote: str | None = None
    rationale: str | None = None
    confidence: float | None = Field(default=None, ge=0, le=1)
