from __future__ import annotations

import argparse
import re
import subprocess
from pathlib import Path

from cdw_mining.config import config_path, output_path
from cdw_mining.extract import (
    CDW_OBJECT_TERMS,
    NON_CDW_WASTE_TERMS,
    VALUE_UNIT_RE,
    _closest_indicator,
    _indicator_label_map,
    _nearest_waste_term_before_value,
)
from cdw_mining.io_utils import file_sha256, read_csv, stable_id, write_csv
from cdw_mining.parse import parse_document_pages, sanitize_text_for_utf8
from cdw_mining.text_utils import normalize_unit, normalize_whitespace, split_sentences, strip_html


GD21_CITIES = [
    "广州市",
    "深圳市",
    "珠海市",
    "汕头市",
    "佛山市",
    "韶关市",
    "河源市",
    "梅州市",
    "惠州市",
    "汕尾市",
    "东莞市",
    "中山市",
    "江门市",
    "阳江市",
    "湛江市",
    "茂名市",
    "肇庆市",
    "清远市",
    "潮州市",
    "揭阳市",
    "云浮市",
]

INVENTORY_FIELDS = [
    "evidence_file_id",
    "source_file",
    "source_file_name",
    "source_file_category",
    "file_type",
    "file_size_bytes",
    "file_sha256",
    "source_url",
    "source_document_type",
    "field_source_level",
    "inferred_city",
    "inferred_year",
    "parse_status",
    "page_count",
    "text_char_count",
    "parse_note",
]

FIELD_FIELDS = [
    "field_id",
    "evidence_file_id",
    "source_file",
    "source_file_name",
    "source_file_category",
    "source_url",
    "source_document_type",
    "field_source_level",
    "field_source_detail",
    "city",
    "year",
    "year_source",
    "indicator_standard",
    "indicator_label",
    "raw_value",
    "raw_unit",
    "value_standardized",
    "unit_standardized",
    "unit_family",
    "unit_standardization_applied",
    "value_m3_if_applicable",
    "m3_standardization_applied",
    "standardization_status",
    "m3_conversion_note",
    "page",
    "evidence_text",
    "extraction_method",
    "needs_llm_review",
    "needs_human_review",
    "quality_flags",
]

YEAR_RE = re.compile(r"(20\d{2})\s*(?:年|年度)?")
FILENAME_YEAR_RE = re.compile(r"(20\d{2})\s*(?:年度|年)")
ANNUAL_DISCLOSURE_YEAR_PATTERNS = [
    re.compile(r"(20\d{2})\s*年度[^。\n]{0,40}固体废物污染"),
    re.compile(r"(20\d{2})\s*年[^。\n]{0,40}固体废物污染"),
    re.compile(r"现予发布[^。\n]{0,20}(20\d{2})\s*年度[^。\n]{0,40}固体废物污染"),
    re.compile(r"产生固体废物总量[^。\n]{0,120}?(20\d{2})\s*年"),
]


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Extract first-pass C&DW field candidates from the Part0 evidence library."
    )
    parser.add_argument(
        "--root",
        type=Path,
        default=Path("Conference/Part0/Step1/evidence_by_city"),
        help="Evidence library root. Files are scanned recursively.",
    )
    parser.add_argument(
        "--manifest",
        type=Path,
        default=Path("Conference/Part0/Step1/step1_evidence_manifest.csv"),
        help="Locked Step1 evidence manifest. Used for city/source folder and SHA-256 metadata.",
    )
    parser.add_argument(
        "--extra-file",
        type=Path,
        action="append",
        default=[],
        help="Additional evidence file outside --root. Can be passed more than once.",
    )
    parser.add_argument(
        "--inventory-output",
        type=Path,
        default=output_path("part0_step2_evidence_file_inventory.csv"),
    )
    parser.add_argument(
        "--field-output",
        type=Path,
        default=output_path("part0_step2_candidate_fields.csv"),
    )
    parser.add_argument(
        "--verification-report",
        type=Path,
        default=Path("Conference/Part0/Step1/logs/part0_url_crawl_verification_report.csv"),
    )
    return parser.parse_args()


def source_level_for_document_type(document_type: str) -> str:
    return {
        "provincial_plan": "省级计划",
        "municipal_plan": "市级计划",
        "annual_disclosure": "每年披露",
        "other_public_disclosure": "其他公开披露",
    }.get(document_type, "其他公开披露")


def compact_for_matching(text: str) -> str:
    return re.sub(r"\s+", "", text)


def infer_city_from_text(text: str) -> str:
    compact = compact_for_matching(text)
    for city in GD21_CITIES:
        short = city[:-1]
        if city in compact or short in compact:
            return city
    return ""


def infer_year_from_name_or_text(name: str, text: str) -> tuple[str, str]:
    match = FILENAME_YEAR_RE.search(name)
    if match:
        return match.group(1), "filename"
    head = text[:4000]
    for pattern in ANNUAL_DISCLOSURE_YEAR_PATTERNS:
        match = pattern.search(head)
        if match:
            return match.group(1), "document_title_or_lead"
    match = YEAR_RE.search(text[:2000])
    if match:
        return match.group(1), "document_text"
    return "", ""


def infer_document_type(path: Path, text: str) -> str:
    combined = f"{path.name}\n{text[:4000]}"
    compact = compact_for_matching(combined)
    if "广东省建筑垃圾污染环境防治工作规划" in compact:
        return "provincial_plan"
    municipal_plan_terms = (
        "建筑垃圾污染环境防治工作规划",
        "建筑废弃物处置设施布局规划",
        "建筑垃圾治理专项规划",
        "建筑废弃物治理专项规划",
    )
    if any(term in compact for term in municipal_plan_terms):
        return "municipal_plan"
    annual_terms = ("固体废物污染环境防治信息", "固体废物污染防治信息", "信息发布公报", "年度公告")
    if any(term in compact for term in annual_terms):
        return "annual_disclosure"
    if re.search(r"20\d{2}年.*(建筑垃圾|建筑废弃物).*(年度信息|情况通报|管理年度信息)", compact):
        return "annual_disclosure"
    return "other_public_disclosure"


def load_source_url_map(report_path: Path) -> dict[str, dict[str, str]]:
    rows = read_csv(report_path)
    mapping: dict[str, dict[str, str]] = {}
    for row in rows:
        local_path = row.get("local_path", "")
        if not local_path:
            continue
        path = Path(local_path)
        keys = {str(path), path.name}
        try:
            keys.add(str(path.resolve()))
        except OSError:
            pass
        if row.get("file_hash"):
            keys.add(row["file_hash"])
        for key in keys:
            mapping[key] = row
    return mapping


def source_row_for_path(path: Path, source_map: dict[str, dict[str, str]]) -> dict[str, str]:
    keys = [str(path), path.name]
    try:
        keys.insert(0, str(path.resolve()))
    except OSError:
        pass
    try:
        keys.append(file_sha256(path))
    except OSError:
        pass
    for key in keys:
        if key in source_map:
            return source_map[key]
    return {}


def load_manifest_map(manifest_path: Path) -> dict[str, dict[str, str]]:
    if not manifest_path.exists():
        return {}
    mapping: dict[str, dict[str, str]] = {}
    for row in read_csv(manifest_path):
        keys = [
            row.get("sha256", ""),
            row.get("relative_path", ""),
            row.get("file_name", ""),
        ]
        for key in keys:
            if key:
                mapping[key] = row
    return mapping


def manifest_row_for_path(path: Path, manifest_map: dict[str, dict[str, str]]) -> dict[str, str]:
    keys = [path.name]
    try:
        keys.insert(0, file_sha256(path))
    except OSError:
        pass
    for key in keys:
        if key in manifest_map:
            return manifest_map[key]
    return {}


def extract_doc_text(path: Path) -> list[dict[str, str]]:
    try:
        completed = subprocess.run(
            ["textutil", "-convert", "txt", "-stdout", str(path)],
            check=False,
            capture_output=True,
            text=True,
            timeout=20,
        )
    except (FileNotFoundError, subprocess.SubprocessError):
        return []
    text = sanitize_text_for_utf8(completed.stdout or "")
    if completed.returncode != 0 or not text.strip():
        return []
    return [{"page": "", "text": normalize_whitespace(text)}]


def parse_evidence_file(path: Path) -> tuple[list[dict[str, str]], str]:
    suffix = path.suffix.lower().lstrip(".")
    if suffix in {"doc", "docx", "wps"}:
        pages = extract_doc_text(path)
        return pages, "textutil_doc_extraction" if pages else "doc_parse_failed"
    if suffix in {"html", "htm"}:
        raw = path.read_text(encoding="utf-8", errors="ignore")
        return [{"page": "", "text": sanitize_text_for_utf8(strip_html(raw))}], "html_strip"
    if suffix == "pdf":
        pages = parse_document_pages(str(path), "pdf")
        return pages, "pdf_text_extraction" if pages else "pdf_parse_failed"
    if suffix in {"txt", "csv"}:
        return [{"page": "", "text": sanitize_text_for_utf8(path.read_text(encoding="utf-8", errors="ignore"))}], "plain_text"
    if suffix == "xlsx":
        try:
            from openpyxl import load_workbook

            workbook = load_workbook(path, read_only=True, data_only=True)
            pages: list[dict[str, str]] = []
            for sheet in workbook.worksheets:
                lines: list[str] = []
                for row in sheet.iter_rows(values_only=True):
                    values = [str(cell).strip() for cell in row if cell is not None and str(cell).strip()]
                    if values:
                        lines.append("\t".join(values))
                if lines:
                    pages.append({"page": sheet.title, "text": sanitize_text_for_utf8("\n".join(lines))})
            return pages, "xlsx_openpyxl_extraction" if pages else "xlsx_parse_empty"
        except Exception as exc:
            return [], f"xlsx_parse_failed:{type(exc).__name__}"
    return [], "unsupported_file_type"


def city_alias_pattern(city: str) -> str:
    return r"\s*".join(re.escape(ch) for ch in city)


def extract_provincial_b1_generation(
    text: str,
    file_meta: dict[str, str],
    labels: dict[str, str],
) -> list[dict[str, object]]:
    if "B1.2018-2023" not in text or "建筑垃圾产生量汇总表" not in text:
        return []
    section = ""
    for match in re.finditer(r"B1\.2018-2023", text):
        section_start = match.start()
        section_end = text.find("B2.", section_start)
        candidate_section = text[section_start : section_end if section_end != -1 else len(text)]
        compact_section = compact_for_matching(candidate_section)
        if "单位：万立方米" in compact_section and "全省" in compact_section and "广州" in compact_section:
            section = candidate_section
            break
    if not section:
        return []

    matches: list[tuple[str, int, int]] = []
    for city in GD21_CITIES:
        match = re.search(city_alias_pattern(city), section)
        if match:
            matches.append((city, match.start(), match.end()))
    matches.sort(key=lambda item: item[1])

    rows: list[dict[str, object]] = []
    for index, (city, _start, end) in enumerate(matches):
        next_start = matches[index + 1][1] if index + 1 < len(matches) else len(section)
        block = section[end:next_start]
        for year_match in re.finditer(r"\b(2018|2019|2020|2021|2022|2023)\s+(\d+(?:\.\d+)?)", block):
            year, value = year_match.groups()
            evidence = f"B1.2018-2023年各地级以上市建筑垃圾产生量汇总表：{city}{year}年产生总量{value}万立方米。"
            rows.append(
                build_field_row(
                    file_meta=file_meta,
                    city=city,
                    year=year,
                    year_source="province_b1_table",
                    indicator="cdw_generation_total",
                    raw_value=value,
                    raw_unit="万立方米",
                    page="31-34",
                    evidence_text=evidence,
                    extraction_method="province_b1_table_regex",
                    labels=labels,
                    field_source_detail="B1_provincial_generation_table",
                    needs_llm_review="0",
                    needs_human_review="1",
                    quality_flags="table_extracted;manual_audit_required",
                )
            )
    return rows


def extract_guangzhou_municipal_generation_tables(
    text: str,
    file_meta: dict[str, str],
    labels: dict[str, str],
) -> list[dict[str, object]]:
    head_compact = compact_for_matching(text[:5000])
    full_compact = compact_for_matching(text)
    if "广州市建筑废弃物处置设施布局规划" not in head_compact:
        return []
    if "表2-3" not in full_compact or "表2-4" not in full_compact:
        return []

    rows: list[dict[str, object]] = []
    simple_section_start = text.find("表 2-3")
    simple_section_end = text.find("表 2-4", simple_section_start)
    simple_section = text[simple_section_start:simple_section_end] if simple_section_start != -1 and simple_section_end != -1 else ""
    for match in re.finditer(r"\b(201[0-5])\s+广州市\s+([\d,]+)", simple_section):
        year, raw_value = match.groups()
        value = raw_value.replace(",", "")
        evidence = f"表2-3 广州市2010-2015年建筑废弃物产生量：{year}年广州市产生数量{raw_value}m3。"
        rows.append(
            build_field_row(
                file_meta=file_meta,
                city="广州市",
                year=year,
                year_source="municipal_plan_table_2_3",
                indicator="cdw_generation_total",
                raw_value=value,
                raw_unit="立方米",
                page="10",
                evidence_text=evidence,
                extraction_method="guangzhou_municipal_plan_table_regex",
                labels=labels,
                field_source_detail="table_2_3_guangzhou_2010_2015_generation",
                needs_llm_review="0",
                needs_human_review="1",
                quality_flags="table_extracted;manual_audit_required",
            )
        )

    detailed_section_start = text.find("表 2-4")
    detailed_section_end = text.find("2.3.1.2", detailed_section_start)
    detailed_section = text[detailed_section_start:detailed_section_end] if detailed_section_start != -1 and detailed_section_end != -1 else ""
    year_matches = list(re.finditer(r"\b(2016|2017|2018|2019)\s+越秀区", detailed_section))
    for index, year_match in enumerate(year_matches):
        year = year_match.group(1)
        block_end = year_matches[index + 1].start() if index + 1 < len(year_matches) else len(detailed_section)
        block = detailed_section[year_match.start():block_end]
        total_match = re.search(r"合计\s+([\d,]+)\s+100\.00%", block)
        if not total_match:
            continue
        raw_value = total_match.group(1)
        value = raw_value.replace(",", "")
        evidence = f"表2-4 广州市2016-2019年建筑废弃物产生量：{year}年合计{raw_value}m3。"
        rows.append(
            build_field_row(
                file_meta=file_meta,
                city="广州市",
                year=year,
                year_source="municipal_plan_table_2_4",
                indicator="cdw_generation_total",
                raw_value=value,
                raw_unit="立方米",
                page="10",
                evidence_text=evidence,
                extraction_method="guangzhou_municipal_plan_table_regex",
                labels=labels,
                field_source_detail="table_2_4_guangzhou_2016_2019_generation",
                needs_llm_review="0",
                needs_human_review="1",
                quality_flags="table_extracted;manual_audit_required",
            )
        )
    return rows


def year_from_sentence(sentence: str, fallback_year: str) -> tuple[str, str]:
    match = YEAR_RE.search(sentence[:80])
    if match:
        return match.group(1), "evidence_sentence"
    return fallback_year, "filename_or_document" if fallback_year else ""


def cities_for_sentence(sentence: str, fallback_city: str) -> list[str]:
    compact = compact_for_matching(sentence)
    cities = [city for city in GD21_CITIES if city in compact or city[:-1] in compact]
    if cities:
        return cities
    return [fallback_city] if fallback_city else []


def value_m3_if_applicable(value_standardized: float, unit_standardized: str, unit_family: str) -> tuple[str, str]:
    if unit_standardized == "m3":
        return format_number(value_standardized), "volume_unit_kept"
    if unit_standardized == "ton":
        return format_number(value_standardized / 1.5), "ton_to_m3_using_density_1.5_ton_per_m3"
    if unit_standardized == "m3_per_year":
        return format_number(value_standardized), "annual_volume_capacity_kept"
    if unit_standardized == "ton_per_year":
        return format_number(value_standardized / 1.5), "annual_mass_capacity_to_m3_per_year_using_density_1.5_ton_per_m3"
    if unit_family == "volume":
        return format_number(value_standardized), "volume_unit_kept"
    if unit_family == "mass":
        return format_number(value_standardized / 1.5), "mass_to_m3_using_density_1.5_ton_per_m3"
    return "", ""


def format_number(value: float) -> str:
    if abs(value - round(value)) < 1e-6:
        return str(int(round(value)))
    text = f"{value:.6f}".rstrip("0").rstrip(".")
    return text or "0"


def unit_standardization_applied(raw_value: str, raw_unit: str, std_value: float, std_unit: str) -> str:
    raw_numeric = float(raw_value)
    if raw_unit != std_unit:
        return "1"
    if abs(raw_numeric - std_value) > 1e-9:
        return "1"
    return "0"


def standardization_status(raw_unit: str, std_unit: str, m3_note: str) -> tuple[str, str]:
    if m3_note in {"ton_to_m3_using_density_1.5_ton_per_m3", "mass_to_m3_using_density_1.5_ton_per_m3"}:
        return "1", "mass_to_m3_standardized_using_1.5_ton_per_m3"
    if m3_note == "annual_mass_capacity_to_m3_per_year_using_density_1.5_ton_per_m3":
        return "1", "annual_mass_capacity_to_m3_per_year_standardized_using_1.5_ton_per_m3"
    if m3_note == "volume_unit_kept":
        return "1", "volume_standardized_to_m3_without_density_conversion"
    if m3_note == "annual_volume_capacity_kept":
        return "1", "annual_volume_capacity_standardized_to_m3_per_year_without_density_conversion"
    if std_unit in {"percent", "count"}:
        return "0", f"not_applicable_for_{std_unit}"
    return "0", "not_applicable_or_unknown_unit"


def build_field_row(
    file_meta: dict[str, str],
    city: str,
    year: str,
    year_source: str,
    indicator: str,
    raw_value: str,
    raw_unit: str,
    page: str,
    evidence_text: str,
    extraction_method: str,
    labels: dict[str, str],
    field_source_detail: str,
    needs_llm_review: str,
    needs_human_review: str,
    quality_flags: str,
) -> dict[str, object]:
    unit_rows = read_csv(config_path("unit_rules.csv"))
    value = float(raw_value)
    std_value, std_unit, unit_family = normalize_unit(value, raw_unit, unit_rows)
    m3_value, m3_note = value_m3_if_applicable(std_value, std_unit, unit_family)
    m3_applied, std_status = standardization_status(raw_unit, std_unit, m3_note)
    field_id = "FIELD_" + stable_id(
        file_meta.get("evidence_file_id", ""),
        city,
        year,
        indicator,
        raw_value,
        raw_unit,
        evidence_text,
        length=14,
    ).upper()
    return {
        "field_id": field_id,
        "evidence_file_id": file_meta.get("evidence_file_id", ""),
        "source_file": file_meta.get("source_file", ""),
        "source_file_name": file_meta.get("source_file_name", ""),
        "source_file_category": file_meta.get("source_file_category", ""),
        "source_url": file_meta.get("source_url", ""),
        "source_document_type": file_meta.get("source_document_type", ""),
        "field_source_level": file_meta.get("field_source_level", ""),
        "field_source_detail": field_source_detail,
        "city": city,
        "year": year,
        "year_source": year_source,
        "indicator_standard": indicator,
        "indicator_label": labels.get(indicator, indicator),
        "raw_value": raw_value,
        "raw_unit": raw_unit,
        "value_standardized": format_number(std_value),
        "unit_standardized": std_unit,
        "unit_family": unit_family,
        "unit_standardization_applied": unit_standardization_applied(raw_value, raw_unit, std_value, std_unit),
        "value_m3_if_applicable": m3_value,
        "m3_standardization_applied": m3_applied,
        "standardization_status": std_status,
        "m3_conversion_note": m3_note,
        "page": page,
        "evidence_text": evidence_text,
        "extraction_method": extraction_method,
        "needs_llm_review": needs_llm_review,
        "needs_human_review": needs_human_review,
        "quality_flags": quality_flags,
    }


def best_evidence_window(sentence: str, value: str) -> str:
    sentence = normalize_whitespace(sentence)
    if len(sentence) <= 320:
        return sentence
    at = sentence.find(value)
    if at == -1:
        return sentence[:320]
    return sentence[max(0, at - 150) : at + 170]


def extract_general_sentence_candidates(
    pages: list[dict[str, str]],
    file_meta: dict[str, str],
    inferred_city: str,
    inferred_year: str,
    labels: dict[str, str],
) -> list[dict[str, object]]:
    rows: list[dict[str, object]] = []
    for page in pages:
        page_no = page.get("page", "")
        page_text = page.get("text", "")
        sentence_candidates = split_sentences(page_text)
        joined_page_text = re.sub(r"\s*\n\s*", " ", page_text)
        if joined_page_text != page_text:
            sentence_candidates.extend(split_sentences(joined_page_text))
        seen_sentences: set[str] = set()
        for sentence in sentence_candidates:
            if sentence in seen_sentences:
                continue
            seen_sentences.add(sentence)
            if not any(term in sentence for term in CDW_OBJECT_TERMS):
                continue
            if any(term in sentence for term in NON_CDW_WASTE_TERMS) and not any(term in sentence for term in CDW_OBJECT_TERMS):
                continue
            cities = cities_for_sentence(sentence, inferred_city)
            if not cities:
                continue
            year, year_source = year_from_sentence(sentence, inferred_year)
            for match in VALUE_UNIT_RE.finditer(sentence):
                nearest_waste_term = _nearest_waste_term_before_value(sentence, match.start())
                if nearest_waste_term in NON_CDW_WASTE_TERMS:
                    continue
                raw_value = match.group("value")
                raw_unit = match.group("unit")
                unit_rows = read_csv(config_path("unit_rules.csv"))
                std_value, _std_unit, unit_family = normalize_unit(float(raw_value), raw_unit, unit_rows)
                indicator = _closest_indicator(sentence, match, "ambiguous", unit_family)
                if indicator == "ambiguous" and raw_unit in {"座", "处", "个", "家"}:
                    indicator = "facility_count"
                evidence = best_evidence_window(sentence, raw_value)
                if len(cities) > 1 and "全省" in sentence:
                    quality = "multi_city_sentence;manual_audit_required"
                else:
                    quality = "manual_audit_required"
                for city in cities:
                    rows.append(
                        build_field_row(
                            file_meta=file_meta,
                            city=city,
                            year=year,
                            year_source=year_source,
                            indicator=indicator,
                            raw_value=raw_value,
                            raw_unit=raw_unit,
                            page=page_no,
                            evidence_text=evidence,
                            extraction_method="cdw_sentence_regex",
                            labels=labels,
                            field_source_detail="sentence_context",
                            needs_llm_review="1" if indicator == "ambiguous" else "0",
                            needs_human_review="1",
                            quality_flags=quality,
                        )
                    )
    return rows


def build_file_meta(
    path: Path,
    root: Path,
    source_map: dict[str, dict[str, str]],
    manifest_map: dict[str, dict[str, str]],
) -> tuple[dict[str, str], list[dict[str, str]]]:
    pages, parse_note = parse_evidence_file(path)
    text = "\n".join(page.get("text", "") for page in pages)
    source_row = source_row_for_path(path, source_map)
    manifest_row = manifest_row_for_path(path, manifest_map)
    document_type = infer_document_type(path, text)
    inferred_year, _year_source = infer_year_from_name_or_text(path.name, text)
    inferred_year = manifest_row.get("year_hint_from_filename") or inferred_year
    source_folder = manifest_row.get("source_level_folder", "")
    inferred_city = (
        source_row.get("city")
        or (source_folder if source_folder in GD21_CITIES else "")
        or infer_city_from_text(path.name)
        or infer_city_from_text(text[:2500])
    )
    if "manual__" in path.name or "_manual__" in path.name:
        source_category = "manual_supplement"
    elif "sample" in path.name.lower():
        source_category = "manual_sample"
    else:
        source_category = "automated_crawl"
    source_url = (
        source_row.get("best_candidate_url")
        or source_row.get("province_search_best_url")
        or source_row.get("source_url")
        or ""
    )
    evidence_file_id = "EVID_" + stable_id(str(path), file_sha256(path), length=12).upper()
    meta = {
        "evidence_file_id": evidence_file_id,
        "source_file": str(path),
        "source_file_name": path.name,
        "source_file_category": source_category,
        "file_type": path.suffix.lower().lstrip("."),
        "file_size_bytes": str(path.stat().st_size),
        "file_sha256": file_sha256(path),
        "source_url": source_url,
        "source_document_type": document_type,
        "field_source_level": source_level_for_document_type(document_type),
        "inferred_city": inferred_city,
        "inferred_year": inferred_year,
        "parse_status": "parsed" if text.strip() else "not_parsed",
        "page_count": str(len(pages)),
        "text_char_count": str(len(text)),
        "parse_note": parse_note,
    }
    return meta, pages


def dedupe_fields(rows: list[dict[str, object]]) -> list[dict[str, object]]:
    seen: set[tuple[str, str, str, str, str, str, str, str]] = set()
    deduped: list[dict[str, object]] = []
    for row in rows:
        key = (
            str(row.get("source_file", "")),
            str(row.get("city", "")),
            str(row.get("year", "")),
            str(row.get("indicator_standard", "")),
            str(row.get("raw_value", "")),
            str(row.get("raw_unit", "")),
            str(row.get("page", "")),
            str(row.get("evidence_text", ""))[:200],
        )
        if key in seen:
            continue
        seen.add(key)
        deduped.append(row)
    return deduped


def main() -> None:
    args = parse_args()
    source_map = load_source_url_map(args.verification_report)
    manifest_map = load_manifest_map(args.manifest)
    labels = _indicator_label_map()

    inventory_rows: list[dict[str, str]] = []
    field_rows: list[dict[str, object]] = []
    manifest_rows = read_csv(args.manifest) if args.manifest.exists() else []
    if manifest_rows:
        step1_root = args.manifest.parent
        evidence_paths = [
            step1_root / row["relative_path"]
            for row in manifest_rows
            if row.get("relative_path")
        ]
    else:
        evidence_paths = [
            path
            for path in sorted(args.root.rglob("*"))
            if path.is_file() and not any(part.startswith("_") for part in path.relative_to(args.root).parts)
        ]
        evidence_paths.extend(path for path in sorted(args.root.parent.glob("*_sample*.*")) if path.is_file())
    evidence_paths.extend(path for path in args.extra_file if path.exists() and path.is_file())
    seen_paths: set[Path] = set()
    for path in evidence_paths:
        try:
            resolved = path.resolve()
        except OSError:
            resolved = path
        if resolved in seen_paths:
            continue
        seen_paths.add(resolved)
        if not path.is_file() or path.name.startswith("."):
            continue
        if path.suffix.lower() not in {".html", ".htm", ".pdf", ".doc", ".docx", ".wps", ".txt", ".xlsx"}:
            continue
        meta, pages = build_file_meta(path, args.root, source_map, manifest_map)
        inventory_rows.append(meta)
        text = "\n".join(page.get("text", "") for page in pages)
        if meta["source_document_type"] == "provincial_plan":
            field_rows.extend(extract_provincial_b1_generation(text, meta, labels))
        if meta["source_document_type"] == "municipal_plan":
            field_rows.extend(extract_guangzhou_municipal_generation_tables(text, meta, labels))
        field_rows.extend(
            extract_general_sentence_candidates(
                pages=pages,
                file_meta=meta,
                inferred_city=meta.get("inferred_city", ""),
                inferred_year=meta.get("inferred_year", ""),
                labels=labels,
            )
        )

    field_rows = dedupe_fields(field_rows)
    write_csv(args.inventory_output, inventory_rows, INVENTORY_FIELDS)
    write_csv(args.field_output, field_rows, FIELD_FIELDS)
    source_counts: dict[str, int] = {}
    for row in field_rows:
        level = str(row.get("field_source_level", ""))
        source_counts[level] = source_counts.get(level, 0) + 1
    print(f"Evidence files inventoried: {len(inventory_rows)} -> {args.inventory_output}")
    print(f"Candidate fields extracted: {len(field_rows)} -> {args.field_output}")
    print(f"Field source level counts: {source_counts}")


if __name__ == "__main__":
    main()
