#!/usr/bin/env python3
"""
Build a relaxed but controlled LLM review queue from BERT-scored candidates.

Rationale:
- A strict BERT threshold (0.50) is good for precision but may miss real
  generation values, especially disclosure-style 2024 records.
- A very loose threshold over all candidates creates too much noise.
- The recommended queue keeps high-BERT rows and also admits lower-BERT rows
  when rule-based extraction already marks them as generation-like.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import pandas as pd


DEFAULT_INPUT = Path(__file__).resolve().parents[1] / "data" / "bert_scored_all_candidates.csv"
DEFAULT_PANEL = (
    Path(__file__).resolve().parents[3]
    / "CDW_Public_Mining_GD21"
    / "因变量面板.xlsx"
)
DEFAULT_OUTPUT = Path(__file__).resolve().parents[1] / "data" / "bert_relaxed_llm_review_queue.csv"


def norm_city(value: object) -> str:
    if pd.isna(value):
        return ""
    text = str(value).strip()
    return text[:-1] if text.endswith("市") else text


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", type=Path, default=DEFAULT_INPUT)
    parser.add_argument("--panel", type=Path, default=DEFAULT_PANEL)
    parser.add_argument("--output", type=Path, default=DEFAULT_OUTPUT)
    parser.add_argument("--bert_general_threshold", type=float, default=0.20)
    parser.add_argument("--bert_generation_threshold", type=float, default=0.10)
    args = parser.parse_args()

    scored = pd.read_csv(args.input)
    scored["bert_accept_prob"] = pd.to_numeric(scored["bert_accept_prob"], errors="coerce")
    scored["year"] = pd.to_numeric(scored["year"], errors="coerce").astype("Int64")
    scored["district_norm"] = scored["city"].map(norm_city)
    scored["pair"] = scored["district_norm"] + "-" + scored["year"].astype(str)
    scored = scored[(scored["year"] >= 2016) & (scored["year"] <= 2024)].copy()

    is_generation_like = (
        scored["indicator_standard_rule"].eq("cdw_generation_total")
        | scored["weak_priority_label"].eq("high_priority_generation")
    )
    high_bert = scored["bert_accept_prob"].ge(args.bert_general_threshold)
    relaxed_generation = is_generation_like & scored["bert_accept_prob"].ge(args.bert_generation_threshold)
    queue = scored[high_bert | relaxed_generation].copy()

    def tier(row: pd.Series) -> str:
        p = row["bert_accept_prob"]
        gen = (
            row.get("indicator_standard_rule") == "cdw_generation_total"
            or row.get("weak_priority_label") == "high_priority_generation"
        )
        if p >= 0.50:
            return "A_high_bert_accept"
        if p >= args.bert_general_threshold and gen:
            return "B_relaxed_generation_candidate"
        if p >= args.bert_general_threshold:
            return "C_context_candidate"
        if gen and p >= args.bert_generation_threshold:
            return "D_low_bert_but_generation_rule"
        return "Z_other"

    queue["llm_review_tier"] = queue.apply(tier, axis=1)

    panel = pd.read_excel(args.panel)
    panel["district_norm"] = panel["district_name"].map(norm_city)
    panel["year"] = panel["year"].astype(int)
    panel = panel[(panel["year"] >= 2016) & (panel["year"] <= 2024)].copy()
    panel["pair"] = panel["district_norm"] + "-" + panel["year"].astype(str)
    panel_pairs = set(panel["pair"])
    queue["panel_pair_in_reference"] = queue["pair"].isin(panel_pairs)

    queue = queue.sort_values(
        ["llm_review_tier", "bert_accept_prob", "city", "year"],
        ascending=[True, False, True, True],
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    queue.to_csv(args.output, index=False, encoding="utf-8-sig")

    covered = panel_pairs & set(queue["pair"])
    missing_panel = panel[~panel["pair"].isin(covered)].copy()
    missing_path = args.output.with_name("bert_relaxed_llm_review_missing_panel_pairs.csv")
    missing_panel.to_csv(missing_path, index=False, encoding="utf-8-sig")

    summary = {
        "input": str(args.input),
        "panel": str(args.panel),
        "output": str(args.output),
        "missing_panel_pairs_output": str(missing_path),
        "bert_general_threshold": args.bert_general_threshold,
        "bert_generation_threshold": args.bert_generation_threshold,
        "queue_rows": int(len(queue)),
        "queue_city_year_pairs": int(queue["pair"].nunique()),
        "panel_pairs": int(len(panel_pairs)),
        "covered_panel_pairs": int(len(covered)),
        "missing_panel_pairs": int(len(panel_pairs - covered)),
        "tier_counts": {str(k): int(v) for k, v in queue["llm_review_tier"].value_counts().to_dict().items()},
        "missing_pairs": sorted(panel_pairs - covered),
    }
    summary_path = args.output.with_suffix(".summary.json")
    summary_path.write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
