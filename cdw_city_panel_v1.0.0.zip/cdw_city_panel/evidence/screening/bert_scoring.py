#!/usr/bin/env python3
"""
Score all Part0 BERT-ready candidates with the trained binary acceptance model.

The output is a prioritisation table. It should not be treated as the final
panel, because final inclusion still requires evidence-based audit and unit
harmonisation.
"""

from __future__ import annotations

import argparse
from pathlib import Path

import pandas as pd


DEFAULT_INPUT = (
    Path(__file__).resolve().parents[2]
    / "Step3A_BERT_ready"
    / "outputs"
    / "step3a_bert_ready_candidates.csv"
)
DEFAULT_MODEL = Path(__file__).resolve().parents[1] / "models" / "bert_binary_acceptance"
DEFAULT_OUTPUT = Path(__file__).resolve().parents[1] / "data" / "bert_scored_all_candidates.csv"


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", type=Path, default=DEFAULT_INPUT)
    parser.add_argument("--model_dir", type=Path, default=DEFAULT_MODEL)
    parser.add_argument("--output", type=Path, default=DEFAULT_OUTPUT)
    parser.add_argument("--batch_size", type=int, default=16)
    parser.add_argument("--max_length", type=int, default=256)
    args = parser.parse_args()

    try:
        import torch
        from transformers import AutoModelForSequenceClassification, AutoTokenizer
    except ImportError as exc:
        raise SystemExit("Missing torch/transformers dependencies.") from exc

    df = pd.read_csv(args.input)
    if "bert_input_text" not in df.columns:
        raise ValueError("Input file must contain bert_input_text.")

    device = torch.device("cuda" if torch.cuda.is_available() else "mps" if torch.backends.mps.is_available() else "cpu")
    tokenizer = AutoTokenizer.from_pretrained(args.model_dir, local_files_only=True)
    model = AutoModelForSequenceClassification.from_pretrained(args.model_dir, local_files_only=True).to(device)
    model.eval()

    probs: list[float] = []
    texts = df["bert_input_text"].fillna("").astype(str).tolist()
    with torch.no_grad():
        for start in range(0, len(texts), args.batch_size):
            batch_texts = texts[start : start + args.batch_size]
            enc = tokenizer(
                batch_texts,
                truncation=True,
                padding=True,
                max_length=args.max_length,
                return_tensors="pt",
            )
            enc = {k: v.to(device) for k, v in enc.items()}
            logits = model(**enc).logits
            batch_probs = torch.softmax(logits, dim=1)[:, 1].detach().cpu().tolist()
            probs.extend(float(x) for x in batch_probs)

    out = df.copy()
    out["bert_accept_prob"] = probs
    out["bert_pred_label"] = ["accept" if p >= 0.5 else "not_accept" for p in probs]
    out["bert_review_band"] = pd.cut(
        out["bert_accept_prob"],
        bins=[-0.001, 0.2, 0.5, 0.8, 1.001],
        labels=["low_accept_probability", "likely_not_accept", "likely_accept", "high_accept_probability"],
    ).astype(str)
    out = out.sort_values(["bert_accept_prob"], ascending=False)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    out.to_csv(args.output, index=False, encoding="utf-8-sig")

    summary = {
        "rows": int(len(out)),
        "output": str(args.output),
        "pred_label_counts": {str(k): int(v) for k, v in out["bert_pred_label"].value_counts().to_dict().items()},
        "review_band_counts": {str(k): int(v) for k, v in out["bert_review_band"].value_counts().to_dict().items()},
        "top_20_mean_accept_prob": float(out["bert_accept_prob"].head(20).mean()),
    }
    summary_path = args.output.with_suffix(".summary.json")
    summary_path.write_text(pd.Series(summary).to_json(force_ascii=False, indent=2), encoding="utf-8")
    print(pd.Series(summary).to_json(force_ascii=False, indent=2))


if __name__ == "__main__":
    main()
