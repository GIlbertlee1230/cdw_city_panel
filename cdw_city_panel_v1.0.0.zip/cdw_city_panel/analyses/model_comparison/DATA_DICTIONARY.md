# Data and metrics

All city labels are English exports preserving the historical experiment row order. The canonical observation key is `district_name` + `year`. Read archived numeric CSVs with `float_precision="round_trip"` for faithful numerical replay.

| Field | Definition |
|---|---|
| district_name | City name |
| year | Outcome observation year |
| GBA_dummy | 1 for GBA target cities; 0 for other Guangdong cities |
| C_DW_generation_m3 | Standardized annual C&DW generation in cubic metres |
| ln_cdw_m3 | Natural logarithm of C_DW_generation_m3; model target |
| L1_outcome | Natural log outcome for the same city in calendar year t−1 |
| L2_ntl | Natural log VIIRS night-light city measure at t−2 |
| L2_urban_rate | Urbanization rate at t−2, unlogged |
| L2_fai | Natural log fixed asset investment in 10,000 RMB at t−2 |
| L2_disp_income | Natural log disposable income in RMB at t−2 |

The original model panel has 131 rows. Requiring target plus all five original inputs leaves 112 complete rows, including 103 historical training observations and nine target observations. This common cohort is held fixed across S/D/DS.

## Result fields

| Field | Definition |
|---|---|
| candidate_id | Original candidate ID; S keeps the first ID after weight-dimension projection |
| params_json | Original parameters; S excludes the absent dynamic_weight |
| collapsed_original_ids | Original IDs mapping to one structural-only configuration |
| objective | Mean inner log-RMSE + 0.15 × population SD of inner log-RMSE |
| r2 / rmse / mae | R² / root mean squared error / mean absolute error in natural-log units |
| mape | Mean abs(exp(predicted log − actual log) − 1); multiply by 100 for percent |
| median_ape | Median of the same original-scale absolute percentage errors |
| residual_ln | Actual log outcome minus predicted log outcome |
| status / error / warnings_json | Fit outcome and unedited diagnostic messages |

The source exports carry their original measurement units. `verify_inputs()` in `src/comparison.py` reconstructs the target and L1/L2 inputs from the included outcome/covariate tables and checks them against the historical panel. It does not change any source value or perform a new authenticity audit.
