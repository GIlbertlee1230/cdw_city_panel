"""No training: verify frozen outputs and export the two comparison panels."""
from pathlib import Path
import json
import sys
import numpy as np
import pandas as pd
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from src.comparison import ROOT, sha, dump, utc

def main():
    out=ROOT/'results/main_run'
    protocol=json.loads((out/'protocol_frozen.json').read_text())
    for file, expected in protocol['source_hashes'].items():
        assert sha(ROOT/file)==expected, file
    frozen=json.loads((out/'selected_models_before_target.json').read_text())
    target_record=json.loads((out/'target_evaluation_record.json').read_text())
    assert frozen['frozen_at_utc'] < target_record['evaluated_at_utc']
    assert target_record['selected_file_sha256']==sha(out/'selected_models_before_target.json')
    verify=json.loads((out/'independent_refit_verification.json').read_text())
    assert verify['status']=='VERIFIED'
    counts={}
    for p, n in [('S',685),('D',2969)]:
        folds=pd.read_csv(out/f'{p}_inner_folds.csv',float_precision='round_trip')
        summary=pd.read_csv(out/f'{p}_candidate_summary.csv',float_precision='round_trip')
        assert len(folds)==3*n and len(summary)==n
        assert not folds.duplicated(['candidate_id','validation_year']).any()
        assert folds.status.eq('ok').all() and np.isfinite(folds[['r2','rmse','mae']]).all().all()
        warnings=folds.warnings_json.map(json.loads)
        warning_groups=folds.assign(warning_count=warnings.map(len)).groupby('algorithm').warning_count.sum()
        counts[p]=dict(candidates=n,fold_fits=len(folds),failed_fits=0,
                       warning_fits=int(warnings.map(bool).sum()),warning_messages=int(warnings.map(len).sum()),
                       warnings_by_algorithm={k:int(v) for k,v in warning_groups.items() if v})
        s=next(s for s in frozen['selections'] if s['profile']==p)
        assert int(summary.iloc[0].candidate_id)==s['spec']['candidate_id']
    scored=pd.read_csv(out/'target_comparison_2024.csv',float_precision='round_trip')
    predictions=pd.read_csv(out/'target_predictions_2024.csv',float_precision='round_trip')
    for record in scored.to_dict('records'):
        d=predictions[predictions.profile.eq(record['profile'])]
        assert len(d)==9
        y,p=d.ln_cdw_m3.to_numpy(),d.pred_ln_cdw_m3.to_numpy()
        residual=y-p
        manual=[1-np.sum(residual**2)/np.sum((y-y.mean())**2),np.sqrt(np.mean(residual**2)),
                np.mean(np.abs(residual)),np.mean(np.abs(np.expm1(p-y)))]
        np.testing.assert_allclose(manual,[record[k] for k in ['r2','rmse','mae','mape']],rtol=1e-12,atol=1e-12)
    assert len(predictions)==45
    a=pd.read_csv(ROOT/'historical_reference/partA_ridge_comparison_2024.csv',float_precision='round_trip')
    a['profile']=a.profile.map({'S_structural':'S','D_dynamic':'D','DS_combined':'DS'})
    a=a.rename(columns={'n_evaluate':'n_target'})
    a['algorithm']='Ridge';a['selection_source']='Work47: independently tuned original Ridge grid'
    cols=['profile','algorithm','n_train','n_target','r2','rmse','mae','mape','median_ape','selection_source']
    fixed=scored[scored.profile.isin(['naive_persistence','training_log_mean'])]
    pd.concat([fixed[cols],a[cols]],ignore_index=True).to_csv(out/'table4_A_matched_ridge.csv',index=False)
    scored[scored.profile.isin(['S','D','DS'])].to_csv(out/'table4_B_original_grid.csv',index=False)
    training=pd.read_csv(out/'common_panel.csv',float_precision='round_trip')
    mean=float(training[training.year.between(2016,2023)].ln_cdw_m3.mean())
    np.testing.assert_allclose(predictions[predictions.profile.eq('training_log_mean')].pred_ln_cdw_m3,mean,atol=1e-12)
    audit=dict(audited_at_utc=utc(),status='VERIFIED',new_search=counts,
               new_search_fold_fits=10962,preflight_fits=22,DS_archive_verification_fits=3,
               final_winner_fits=3,separate_process_refit_fits=9,total_main_and_verification_fits=10999,
               design_check_fits_separate=18,archived_DS_fold_fits_reused=8907,
               raw_source_hashes_unchanged=True,selection_before_target=True,manual_target_metrics_verified=True,
               target_predictions_per_selected_model=9,mean_baseline_training_log_value=mean,
               process_cleanup_note='Execution exited 0. ResourceTracker.__del__ printed ignored ChildProcessError messages after scoring; complete fold records and independent winner refits were verified. Original log retained; no search rerun.')
    dump(out/'final_audit.json',audit)
    print(json.dumps(audit,indent=2))

if __name__=='__main__':
    main()
