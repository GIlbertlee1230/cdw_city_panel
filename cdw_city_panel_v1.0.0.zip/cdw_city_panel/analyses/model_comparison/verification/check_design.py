"""Offline design checks, including a held-out-label perturbation check."""
import sys
from pathlib import Path
import numpy as np
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from src import comparison as c

def main():
    grids = c.projected_grids()
    assert {k: len(v) for k, v in grids.items()} == {'S': 685, 'D': 2969, 'DS': 2969}
    assert all('dynamic_weight' not in s['params'] for s in grids['S'])
    assert len({(s['algorithm'], s['params_json']) for s in grids['S']}) == 685
    panel = c.load_panel()
    assert len(panel) == 112
    assert len(panel[panel.year.between(2016, 2023)]) == 103
    altered = panel.copy()
    altered.loc[altered.year.eq(2024), c.original.TARGET] = -1e6
    for profile in ['S', 'D', 'DS']:
        for year, counts in zip([2021, 2022, 2023], [(42, 8), (61, 9), (82, 9)]):
            a, b = c.fold_data(panel, year)
            assert (len(a), len(b)) == counts
            assert a.year.max() < year and b.year.eq(year).all()
        spec = next(s for s in grids[profile] if s['algorithm'] == 'Ridge')
        before = c.fit_candidate(profile, spec, panel)
        after = c.fit_candidate(profile, spec, altered)
        assert np.array_equal([r['rmse'] for r in before], [r['rmse'] for r in after])
        model = c.estimator(profile, spec)
        assert len(model.named_steps['weight'].weights) == len(c.PROFILES[profile])
    print('PASS: grid projection; shared cohort; time folds; held-out-label perturbation; weight dimensions.')

if __name__ == '__main__':
    main()
