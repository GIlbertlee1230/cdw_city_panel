"""Original-grid comparison. No new algorithm or hyperparameter is introduced."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import platform
import time
import warnings
import numpy as np
import pandas as pd
import sklearn
from joblib import Parallel, delayed, parallel_config
from threadpoolctl import threadpool_limits
from . import original_search as original

ROOT = Path(__file__).resolve().parents[1]
PROFILES = {'S': original.FEATURES[1:], 'D': original.FEATURES[:1], 'DS': original.FEATURES[:]}
ORDER = ['objective', 'mean_inner_mae', 'complexity_order', 'candidate_id']

def utc():
    return datetime.now(timezone.utc).isoformat()

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def dump(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + '\n', encoding='utf-8')

def read(path):
    return pd.read_csv(ROOT / path, float_precision='round_trip')

def projected_grids():
    specs = original.candidate_specs()
    seen = {}
    for spec in specs:
        params = {k: v for k, v in spec['params'].items() if k != 'dynamic_weight'}
        encoded = json.dumps(params, sort_keys=True)
        key = (spec['algorithm'], encoded)
        if key not in seen:
            seen[key] = dict(candidate_id=spec['candidate_id'], algorithm=spec['algorithm'],
                             params=params, params_json=encoded, collapsed_original_ids=[])
        seen[key]['collapsed_original_ids'].append(spec['candidate_id'])
    return {'S': list(seen.values()), 'D': specs, 'DS': specs}

def load_panel():
    # Cohort is fixed by the original five-feature specification for ALL profiles.
    panel = read('data/model_panel_original.csv')
    return original.valid_rows(panel).copy()

def verify_inputs():
    saved = read('data/model_panel_original.csv')
    y, x = read('data/outcomes.csv'), read('data/covariates.csv')
    assert (len(saved), len(y), len(x)) == (131, 139, 252)
    assert not y.duplicated(['district_name', 'year']).any()
    assert not x.duplicated(['district_name', 'year']).any()
    yp = y.set_index(['district_name', 'year']).C_DW_generation_m3
    xp = x.set_index(['district_name', 'year'])
    differences = {}
    rebuilt = {'C_DW_generation_m3': [yp.loc[(c, int(t))] for c, t in zip(saved.district_name, saved.year)]}
    rebuilt['ln_cdw_m3'] = np.log(rebuilt['C_DW_generation_m3'])
    rebuilt['L1_outcome'] = [np.log(yp.get((c, int(t)-1), np.nan)) for c, t in zip(saved.district_name, saved.year)]
    for feat, col, log in [('L2_ntl','ntl_mean_dn',True), ('L2_urban_rate','urbanization_rate',False),
                           ('L2_fai','fixed_asset_investment_10k_rmb',True), ('L2_disp_income','disposable_income_rmb',True)]:
        values = np.array([xp.loc[(c, int(t)-2), col] for c,t in zip(saved.district_name, saved.year)], float)
        rebuilt[feat] = np.log(values) if log else values
    for col, values in rebuilt.items():
        np.testing.assert_allclose(values, saved[col], rtol=1e-12, atol=1e-12, equal_nan=True)
        differences[col] = float(np.nanmax(np.abs(np.array(values)-saved[col])))
    gba = [int(xp.loc[(c, int(t)-2), 'GBA_dummy']) for c,t in zip(saved.district_name, saved.year)]
    np.testing.assert_array_equal(gba, saved.GBA_dummy)
    return differences

def fold_data(panel, year):
    train = panel[panel.year.between(2016, year-1)].copy()
    validation = panel[panel.year.eq(year) & panel.GBA_dummy.eq(1)].copy()
    return train, validation

def estimator(profile, spec):
    # Only project the original five-dimensional weight vector to the input columns.
    # Original factory, preprocessing order, seeds, stopping rules and parameters stay intact.
    saved = original.weight_vector
    original.weight_vector = lambda w: ([1.0]*4 if profile == 'S' else [float(w)] if profile == 'D' else saved(w))
    try:
        model = original.estimator(spec)
    finally:
        original.weight_vector = saved
    if spec['algorithm'] in ['ExtraTrees', 'RandomForest']:
        model.set_params(model__n_jobs=1)  # candidate-level parallelism, unchanged estimator settings
    return model

def fit_candidate(profile, spec, panel):
    rows = []
    with threadpool_limits(limits=1):
        for year in original.INNER_VALIDATION_YEARS:
            train, validation = fold_data(panel, year)
            row = dict(profile=profile, candidate_id=spec['candidate_id'], algorithm=spec['algorithm'],
                       params_json=spec['params_json'], validation_year=year,
                       n_train=len(train), n_validation=len(validation))
            start = time.monotonic()
            with warnings.catch_warnings(record=True) as caught:
                warnings.simplefilter('always')
                try:
                    model = estimator(profile, spec)
                    model.fit(train[PROFILES[profile]], train[original.TARGET])
                    prediction = np.asarray(model.predict(validation[PROFILES[profile]]), float)
                    if not np.isfinite(prediction).all():
                        raise ValueError('Non-finite prediction')
                    row.update(original.metrics(validation[original.TARGET], prediction), status='ok', error='')
                except Exception as exc:
                    row.update(status='failed', error=f'{type(exc).__name__}: {exc}')
                row['warnings_json'] = json.dumps([f'{type(w.message).__name__}: {w.message}' for w in caught])
            row['seconds'] = time.monotonic() - start
            rows.append(row)
    return rows

def summarize(folds):
    if 'status' in folds:
        assert folds.status.eq('ok').all(), 'Failed fits retained; do not silently choose among surviving candidates.'
    summary = folds.groupby(['candidate_id','algorithm','params_json'], as_index=False).agg(
        folds=('validation_year','nunique'), min_train_n=('n_train','min'), min_validation_n=('n_validation','min'),
        mean_inner_r2=('r2','mean'), mean_inner_rmse=('rmse','mean'),
        std_inner_rmse=('rmse',lambda s:s.std(ddof=0)), mean_inner_mae=('mae','mean'))
    assert summary.folds.eq(3).all()
    summary['objective'] = summary.mean_inner_rmse + 0.15*summary.std_inner_rmse
    summary['complexity_order'] = summary.algorithm.map(original.COMPLEXITY_ORDER)
    return summary.sort_values(ORDER).reset_index(drop=True)

def archive_check(grids, panel):
    archived = read('historical_reference/combined_candidate_summary.csv')
    folds = read('historical_reference/combined_inner_folds.csv')
    assert len(archived) == 2969 and len(folds) == 8907
    assert not folds.duplicated(['candidate_id','validation_year']).any()
    byid = {s['candidate_id']: s for s in grids['DS']}
    for frame in [archived, folds]:
        for r in frame.to_dict('records'):
            spec = byid[int(r['candidate_id'])]
            assert r['algorithm'] == spec['algorithm']
            assert json.loads(r['params_json']) == json.loads(json.dumps(spec['params']))
    for year, nt, nv in [(2021,42,8),(2022,61,9),(2023,82,9)]:
        part = folds[folds.validation_year.eq(year)]
        assert len(part) == 2969 and part.n_train.eq(nt).all() and part.n_validation.eq(nv).all()
    recomputed = summarize(folds)
    a = archived.set_index('candidate_id').sort_index()
    b = recomputed.set_index('candidate_id').sort_index()
    numeric = ['folds','min_train_n','min_validation_n','mean_inner_r2','mean_inner_rmse','std_inner_rmse','mean_inner_mae','objective','complexity_order']
    np.testing.assert_allclose(a[numeric], b[numeric], rtol=1e-12, atol=1e-12)
    assert archived.sort_values(ORDER).candidate_id.tolist() == recomputed.candidate_id.tolist()
    assert int(recomputed.iloc[0].candidate_id) == 23
    repeated = pd.DataFrame(fit_candidate('DS', byid[23], panel))
    reference = folds[folds.candidate_id.eq(23)].sort_values('validation_year')
    np.testing.assert_allclose(repeated[['r2','rmse','mae']], reference[['r2','rmse','mae']], rtol=1e-10, atol=1e-10)
    return dict(candidates=2969, archived_fold_fits=8907, selected_id=23,
                archive_ranking_identical=True, archive_objectives_recomputed=True), repeated

def preflight(grids, panel):
    rows = []
    train, validation = fold_data(panel, 2021)
    for profile in ['S','D']:
        for algorithm in original.COMPLEXITY_ORDER:
            spec = next(s for s in grids[profile] if s['algorithm'] == algorithm)
            with warnings.catch_warnings(record=True) as caught, threadpool_limits(limits=1):
                warnings.simplefilter('always')
                model = estimator(profile, spec)
                model.fit(train[PROFILES[profile]], train[original.TARGET])
                pred = model.predict(validation[PROFILES[profile]])
                assert np.isfinite(pred).all()
                if 'scale' in model.named_steps:
                    np.testing.assert_allclose(model.named_steps['scale'].mean_, train[PROFILES[profile]].mean(), atol=1e-12)
                    assert model.named_steps['scale'].n_samples_seen_ == 42
                rows.append(dict(profile=profile, algorithm=algorithm, candidate_id=spec['candidate_id'],
                                 n_train=42, n_validation=8, scaler_training_only=True,
                                 warnings_json=json.dumps([str(w.message) for w in caught])))
    return pd.DataFrame(rows)

def freeze(out, grids, panel):
    assert not out.exists(), f'Refusing to overwrite: {out}'
    out.mkdir(parents=True)
    dump(out/'frozen_grids.json', grids)
    panel.to_csv(out/'common_panel.csv', index=False)
    rows = []
    for profile, specs in grids.items():
        for spec in specs:
            rows.append(dict(profile=profile, candidate_id=spec['candidate_id'], algorithm=spec['algorithm'],
                             params_json=spec['params_json'],
                             collapsed_original_ids=json.dumps(spec.get('collapsed_original_ids',[spec['candidate_id']]))))
    pd.DataFrame(rows).to_csv(out/'candidate_manifest.csv', index=False)
    counts = pd.DataFrame(rows).groupby(['profile','algorithm']).size().unstack(0).fillna(0).astype(int)
    counts.to_csv(out/'candidate_counts.csv')
    paths = sorted([*ROOT.glob('src/*.py'), ROOT/'main.py', ROOT/'verification/check_design.py',
                    *ROOT.glob('data/*.csv'), *ROOT.glob('historical_reference/*.csv')])
    dump(out/'protocol_frozen.json', dict(frozen_at_utc=utc(), objective='mean(log_RMSE) + 0.15 * population_SD(log_RMSE)',
         tiebreakers=ORDER[1:], seed=original.SEED, profiles=PROFILES, input_panel_rows=len(panel),
         n_train=103, n_target=9, inner_years=[2021,2022,2023], inner_train_n=[42,61,82], inner_validation_n=[8,9,9],
         source_hashes={str(p.relative_to(ROOT)):sha(p) for p in paths},
         scope='Retrospective revision analysis; original feature set and 2024 outcomes already known historically.',
         DS='Reuse the archived original search; refit selected model only.',
         allowed_adapters=['weight vector dimension','forest n_jobs=1 with candidate-level parallelism'],
         stop_rule='No grid expansion or winner substitution after target evaluation.',
         software=dict(python=platform.python_version(), numpy=np.__version__, pandas=pd.__version__, sklearn=sklearn.__version__)))

def search(profile, specs, panel, out, jobs):
    start = time.monotonic()
    collected = []
    with (out/f'{profile}_folds.jsonl').open('w',encoding='utf-8') as handle:
        with parallel_config(backend='loky', inner_max_num_threads=1):
            stream = Parallel(n_jobs=jobs, return_as='generator_unordered', batch_size=1,
                              timeout=3600)(delayed(fit_candidate)(profile,s,panel) for s in specs)
            for i, rows in enumerate(stream, 1):
                for row in rows:
                    handle.write(json.dumps(row, allow_nan=False)+'\n')
                handle.flush()
                collected.extend(rows)
                if i % 100 == 0 or i == len(specs):
                    print(f'{utc()} {profile}: {i}/{len(specs)} candidates, elapsed {time.monotonic()-start:.1f}s', flush=True)
    folds = pd.DataFrame(collected).sort_values(['candidate_id','validation_year']).reset_index(drop=True)
    folds.to_csv(out/f'{profile}_inner_folds.csv', index=False)
    summary = summarize(folds)
    summary.to_csv(out/f'{profile}_candidate_summary.csv', index=False)
    winner = next(s for s in specs if s['candidate_id'] == int(summary.iloc[0].candidate_id))
    return dict(profile=profile, spec=winner, selection=summary.iloc[0].to_dict(), source='new original-grid search')

def score_target(panel, selections, out):
    # This routine is called only after the winners file has been written.
    assert (out/'selected_models_before_target.json').exists()
    train = panel[panel.year.between(2016,2023)]
    target = panel[panel.year.eq(2024) & panel.GBA_dummy.eq(1)]
    assert (len(train), len(target)) == (103,9)
    scores, predictions, audit = [], [], []
    for selected in selections:
        profile, spec = selected['profile'], selected['spec']
        with warnings.catch_warnings(record=True) as caught, threadpool_limits(limits=1):
            warnings.simplefilter('always')
            model = estimator(profile,spec)
            model.fit(train[PROFILES[profile]],train[original.TARGET])
            pred = np.asarray(model.predict(target[PROFILES[profile]]),float)
        audit.append(dict(profile=profile, warnings_json=json.dumps([str(w.message) for w in caught])))
        if profile == 'DS':
            ref = read('historical_reference/combined_2024_predictions.csv')
            assert ref.district_name.tolist() == target.district_name.tolist()
            np.testing.assert_allclose(pred,ref.pred_ln_cdw_m3,rtol=1e-12,atol=1e-12)
        row, frame = target_metrics(profile,spec['algorithm'],spec['params_json'],target,pred)
        row.update(candidate_id=spec['candidate_id'], n_candidates=len(projected_grids()[profile]),
                   selection_source=selected['source'], objective=selected['selection']['objective'])
        scores.append(row); predictions.append(frame)
    fixed = [('training_log_mean', np.full(9,train[original.TARGET].mean())),
             ('naive_persistence', target.L1_outcome.to_numpy())]
    for name, pred in fixed:
        row, frame = target_metrics(name, 'untuned fixed baseline','{}',target,pred)
        row.update(selection_source='fixed baseline; no target selection')
        scores.append(row); predictions.append(frame)
    pd.DataFrame(scores).to_csv(out/'target_comparison_2024.csv',index=False)
    pd.concat(predictions,ignore_index=True).to_csv(out/'target_predictions_2024.csv',index=False)
    pd.DataFrame(audit).to_csv(out/'winner_fit_warnings.csv',index=False)
    dump(out/'target_evaluation_record.json',dict(evaluated_at_utc=utc(),
         selected_file_sha256=sha(out/'selected_models_before_target.json'), selected_models_scored=3,
         note='Only the three profile winners and two untuned baselines were scored; DS refit verifies archived predictions.'))

def target_metrics(profile, algorithm, params, target, pred):
    actual = target[original.TARGET].to_numpy()
    ape = np.abs(np.expm1(pred-actual))
    row = dict(profile=profile,algorithm=algorithm,params_json=params,n_train=103,n_target=9,
               **original.metrics(actual,pred),mape=float(ape.mean()),median_ape=float(np.median(ape)))
    frame = target[['district_name','year',original.TARGET]].copy()
    frame['profile']=profile; frame['pred_ln_cdw_m3']=pred
    frame['actual_m3']=np.exp(actual); frame['pred_m3']=np.exp(pred)
    frame['residual_ln']=actual-pred; frame['ape']=ape
    return row, frame

def run(out, jobs):
    grids, panel = projected_grids(), load_panel()
    assert {k:len(v) for k,v in grids.items()} == {'S':685,'D':2969,'DS':2969}
    assert len(panel)==112
    freeze(out,grids,panel)
    differences = verify_inputs()
    archive, repeated = archive_check(grids,panel)
    repeated.to_csv(out/'DS_archived_winner_fold_verification.csv',index=False)
    dump(out/'input_and_archive_verification.json',dict(input_max_absolute_differences=differences,**archive))
    preflight(grids,panel).to_csv(out/'preflight_22_fits.csv',index=False)
    print(f'{utc()} Original inputs, archive and 22 model preflight fits verified.',flush=True)
    selections = [search(profile,grids[profile],panel,out,jobs) for profile in ['S','D']]
    ds_summary = read('historical_reference/combined_candidate_summary.csv').sort_values(ORDER).iloc[0]
    selections.append(dict(profile='DS',spec=next(s for s in grids['DS'] if s['candidate_id']==23),
                           selection=ds_summary.to_dict(),source='reused original 2969-candidate search'))
    dump(out/'selected_models_before_target.json',dict(frozen_at_utc=utc(),selections=selections))
    print(f'{utc()} All three profile winners frozen. Beginning target evaluation.',flush=True)
    score_target(panel,selections,out)
    dump(out/'execution_complete.json',dict(completed_at_utc=utc(),new_search_candidates=3654,
         new_search_fold_fits=10962,preflight_fits=22,DS_archive_verification_fits=3,
         target_winner_fits=3,reused_DS_candidates=2969,reused_DS_fold_fits=8907,
         independent_refit_verification='Run main.py --verify separately.',status='search and target scoring complete'))

def verify(out):
    # Separate process: refit only the three frozen winners, never choose a new winner.
    frozen = json.loads((out/'selected_models_before_target.json').read_text())
    panel = load_panel()
    predictions = pd.read_csv(out/'target_predictions_2024.csv',float_precision='round_trip')
    rows=[]
    train=panel[panel.year.between(2016,2023)]
    target=panel[panel.year.eq(2024)&panel.GBA_dummy.eq(1)]
    for selected in frozen['selections']:
        p,s=selected['profile'],selected['spec']
        if 'hidden_layer_sizes' in s['params']:
            s['params']['hidden_layer_sizes']=tuple(s['params']['hidden_layer_sizes'])
        with threadpool_limits(limits=1):
            model=estimator(p,s)
            model.fit(train[PROFILES[p]],train[original.TARGET])
            pred=model.predict(target[PROFILES[p]])
        ref=predictions[predictions.profile.eq(p)]
        delta=float(np.max(np.abs(pred-ref.pred_ln_cdw_m3.to_numpy())))
        np.testing.assert_allclose(pred,ref.pred_ln_cdw_m3,rtol=1e-12,atol=1e-12)
        # DS folds already independently verified before search; verify S/D winner folds here.
        if p in ['S','D']:
            new=pd.DataFrame(fit_candidate(p,s,panel))
            old=pd.read_csv(out/f'{p}_inner_folds.csv',float_precision='round_trip')
            old=old[old.candidate_id.eq(s['candidate_id'])].sort_values('validation_year')
            np.testing.assert_allclose(new[['r2','rmse','mae']],old[['r2','rmse','mae']],rtol=1e-12,atol=1e-12)
        rows.append(dict(profile=p,max_target_prediction_difference=delta,status='verified'))
    dump(out/'independent_refit_verification.json',dict(verified_at_utc=utc(),fits=9,profiles=rows,
         selected_file_sha256=sha(out/'selected_models_before_target.json'),status='VERIFIED'))
    print(json.dumps(rows,indent=2),flush=True)
