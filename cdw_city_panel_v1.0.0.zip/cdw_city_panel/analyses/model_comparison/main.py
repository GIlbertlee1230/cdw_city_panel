"""PyCharm entry point: run the fixed original-grid comparison, or verify frozen winners."""
import os
for variable in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','VECLIB_MAXIMUM_THREADS','NUMEXPR_NUM_THREADS']:
    os.environ[variable]='1'
from pathlib import Path
import argparse
from datetime import datetime, timezone
from src.comparison import ROOT, run, verify

if __name__ == '__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--jobs',type=int,default=6)
    parser.add_argument('--out',type=Path)
    parser.add_argument('--verify',action='store_true')
    args=parser.parse_args()
    if args.verify:
        verify(args.out or ROOT/'results/main_run')
    else:
        output=args.out or ROOT/'results'/('rerun_'+datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ'))
        run(output.resolve(),max(1,args.jobs))
