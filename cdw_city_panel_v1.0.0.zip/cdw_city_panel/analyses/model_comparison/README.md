# Model comparison under the original search rule

Project the original 11-family parameter grid onto each input group. Structural-only has 685 configurations; dynamic-only has 2,969. The authenticated original combined search is reused. This supplies Part B.

## Contents

- `DATA_DICTIONARY.md`
- `data/`
- `docs/`
- `historical_reference/`
- `main.py`
- `requirements.txt`
- `results/`
- `src/`
- `verification/`

## Execution

Run from the project root in a separate Python process:

```bash
python analyses/model_comparison/main.py --jobs 6
```

This optional command fits the original S/D grids and writes a new timestamped directory under this module's `results/`. The original combined-model search is reused. It does not overwrite the archived run or expand the grid.

## Interpretation

Definitions and analysis-specific limitations are in `docs/supplementary_information.md` at the project root. Scientific input files, labels and frozen results are preserved. The directory name describes the analysis rather than a review stage or internal experiment number.
