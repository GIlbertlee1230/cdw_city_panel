# Screening sample definitions

Distinguish 118 pairwise screening records from 114 complete records used in the historical wider VIF pool. The displayed VIFs are not joint four-predictor VIFs.

## Contents

- `four_incomplete_wider_pool_rows.csv`
- `historical_displayed_vifs.csv`
- `summary.json`

## Interpretation

Definitions and analysis-specific limitations are in `docs/supplementary_information.md` at the project root. Scientific input files, labels and frozen results are preserved. The directory name describes the analysis rather than a review stage or internal experiment number.
