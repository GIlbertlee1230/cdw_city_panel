# Fixed-prediction density sensitivity

Count original-unit categories and replay two explicitly labelled density scenarios. Predictions remain fixed. The unknown-origin scenario is hypothetical.

## Contents

- `fixed_predictions_density_curve.csv`
- `main.py`
- `model112_unit_origins.csv`
- `summary.json`
- `target_unit_origins_and_fixed_predictions.csv`

## Execution

Run from the project root in a separate Python process:

```bash
python analyses/density_sensitivity/main.py
```

This command recalculates both fixed-prediction scenarios, checks them against the archived curve and writes to `outputs/density_sensitivity/`. It fits no model and makes no network request.

## Interpretation

Definitions and analysis-specific limitations are in `docs/supplementary_information.md` at the project root. Scientific input files, labels and frozen results are preserved. The directory name describes the analysis rather than a review stage or internal experiment number.
