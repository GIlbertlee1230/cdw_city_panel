"""Replay fixed-prediction density arithmetic. No model fit or network call."""
from pathlib import Path
import json
import numpy as np
import pandas as pd
ROOT=Path(__file__).resolve().parent
x=pd.read_csv(ROOT/'target_unit_origins_and_fixed_predictions.csv',float_precision='round_trip',keep_default_na=False)
ref=pd.read_csv(ROOT/'fixed_predictions_density_curve.csv',float_precision='round_trip')
rows=[]
for scenario in ['confirmed_mass_only','unknown_also_mass_hypothesis']:
    for density in np.round(np.linspace(1.3,1.8,501),3):
        mask=x.unit_origin.eq('MASS_TO_VOLUME')
        if scenario.endswith('hypothesis'):mask=mask|x.unit_origin.eq('')
        actual=x.C_DW_generation_m3.to_numpy(dtype=float).copy()
        actual[mask]*=1.5/density
        y=np.log(actual);pred=x.pred_ln_cdw_m3.to_numpy(dtype=float);e=y-pred
        rows.append(dict(scenario=scenario,density_ton_per_m3=float(density),varied_targets=int(mask.sum()),r2=float(1-np.sum(e**2)/np.sum((y-y.mean())**2)),log_rmse=float(np.sqrt(np.mean(e**2))),log_mae=float(np.mean(abs(e))),mape=float(np.mean(abs(np.expm1(-e))))))
new=pd.DataFrame(rows)
pd.testing.assert_frame_equal(ref,new,check_exact=True)
out=ROOT.parents[1]/'outputs/density_sensitivity';out.mkdir(parents=True,exist_ok=True)
new.to_csv(out/'fixed_predictions_density_curve.csv',index=False)
report=dict(status='PASS',curve_points=len(new),model_fits=0,llm_calls=0,network_calls=0,comparison='Exact replay of both501-point scenarios; unknown origin remains hypothetical.')
(out/'verification.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
