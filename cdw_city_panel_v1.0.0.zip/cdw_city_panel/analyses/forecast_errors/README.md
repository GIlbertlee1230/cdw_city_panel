# Original-scale forecast errors

Inspect city-level prediction errors and persistence comparisons. Log residuals and original-scale percentage errors use different scales.

## Contents

- `naive_persistence_by_year.csv`
- `original_scale_errors_2024.csv`

## Interpretation

Definitions and analysis-specific limitations are in `docs/supplementary_information.md` at the project root. Scientific input files, labels and frozen results are preserved. The directory name describes the analysis rather than a review stage or internal experiment number.
