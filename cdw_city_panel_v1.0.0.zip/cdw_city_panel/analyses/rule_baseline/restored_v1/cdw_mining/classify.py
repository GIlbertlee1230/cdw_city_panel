from __future__ import annotations

import json
from pathlib import Path

from .config import config_path, output_path
from .io_utils import read_csv, write_csv


CLASSIFICATION_FIELDS = [
    "chunk_id",
    "document_id",
    "city",
    "source_url",
    "text",
    "document_relevance_label",
    "chunk_candidate_label",
    "indicator_type_label",
    "confidence",
    "model_version",
]

TRAINING_FIELDS = [
    "chunk_id",
    "text",
    "weak_document_relevance_label",
    "weak_chunk_candidate_label",
    "weak_indicator_type_label",
]


def _load_indicator_aliases() -> dict[str, list[str]]:
    aliases: dict[str, list[str]] = {}
    for row in read_csv(config_path("indicator_ontology.csv")):
        parts = [row["cn_label"]] + [part for part in row.get("aliases", "").split("|") if part]
        aliases[row["indicator_standard"]] = parts
    return aliases


def classify_indicator(text: str) -> tuple[str, float]:
    aliases = _load_indicator_aliases()
    best_label = "other"
    best_score = 0
    for label, terms in aliases.items():
        score = sum(1 for term in terms if term and term in text)
        if score > best_score:
            best_label = label
            best_score = score
    if best_score == 0:
        return "other", 0.30
    confidence = min(0.95, 0.55 + best_score * 0.15)
    return best_label, confidence


def classify_chunk(row: dict[str, str]) -> dict[str, object]:
    text = row.get("text", "")
    keyword_count = len([kw for kw in row.get("keywords_found", "").split("|") if kw])
    has_number = any(ch.isdigit() for ch in text)
    indicator, indicator_conf = classify_indicator(text)
    if keyword_count == 0:
        relevance = "0"
        candidate = "0"
        confidence = 0.80
    elif has_number and indicator not in {"other", "ambiguous"}:
        relevance = "4"
        candidate = "1"
        confidence = max(indicator_conf, 0.82)
    elif has_number:
        relevance = "3"
        candidate = "1"
        confidence = 0.68
    else:
        relevance = "1"
        candidate = "0"
        confidence = 0.65
    return {
        "chunk_id": row.get("chunk_id", ""),
        "document_id": row.get("document_id", ""),
        "city": row.get("city", ""),
        "source_url": row.get("source_url", ""),
        "text": text,
        "document_relevance_label": relevance,
        "chunk_candidate_label": candidate,
        "indicator_type_label": indicator,
        "confidence": f"{confidence:.3f}",
        "model_version": "rule_fallback_v1",
    }


def prepare_training_data(chunks_csv: Path | None = None) -> list[dict[str, object]]:
    rows = read_csv(chunks_csv or output_path("text_chunks.csv"))
    out = []
    for row in rows:
        classified = classify_chunk(row)
        out.append(
            {
                "chunk_id": classified["chunk_id"],
                "text": classified["text"],
                "weak_document_relevance_label": classified["document_relevance_label"],
                "weak_chunk_candidate_label": classified["chunk_candidate_label"],
                "weak_indicator_type_label": classified["indicator_type_label"],
            }
        )
    return out


def classify_chunks(chunks_csv: Path | None = None) -> list[dict[str, object]]:
    rows = read_csv(chunks_csv or output_path("text_chunks.csv"))
    return [classify_chunk(row) for row in rows]


def write_model_manifest(path: Path, fallback: bool = True) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    manifest = {
        "model_version": "rule_fallback_v1" if fallback else "external_bert_placeholder",
        "model_type": "rule_fallback" if fallback else "bert",
        "status": "ready",
        "notes": "MVP runs without a downloaded BERT model. Replace with fine-tuned Chinese BERT later.",
    }
    path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")


def write_training_data(rows: list[dict[str, object]], output: Path) -> None:
    write_csv(output, rows, TRAINING_FIELDS)


def write_classifications(rows: list[dict[str, object]], output: Path) -> None:
    write_csv(output, rows, CLASSIFICATION_FIELDS)

