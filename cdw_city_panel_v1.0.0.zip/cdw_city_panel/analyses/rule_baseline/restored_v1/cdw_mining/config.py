from __future__ import annotations

from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parents[1]
CONFIG_DIR = PROJECT_ROOT / "config"
RAW_DIR = PROJECT_ROOT / "raw_documents"
TEXT_DIR = PROJECT_ROOT / "extracted_text"
OUTPUT_DIR = PROJECT_ROOT / "outputs"
SEED_DIR = PROJECT_ROOT / "seed_documents"
LOG_DIR = PROJECT_ROOT / "logs"


def ensure_dirs() -> None:
    for path in [CONFIG_DIR, RAW_DIR, TEXT_DIR, OUTPUT_DIR, SEED_DIR, LOG_DIR]:
        path.mkdir(parents=True, exist_ok=True)


def config_path(name: str) -> Path:
    return CONFIG_DIR / name


def output_path(name: str) -> Path:
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    return OUTPUT_DIR / name


def raw_path(name: str) -> Path:
    RAW_DIR.mkdir(parents=True, exist_ok=True)
    return RAW_DIR / name


def text_path(name: str) -> Path:
    TEXT_DIR.mkdir(parents=True, exist_ok=True)
    return TEXT_DIR / name

