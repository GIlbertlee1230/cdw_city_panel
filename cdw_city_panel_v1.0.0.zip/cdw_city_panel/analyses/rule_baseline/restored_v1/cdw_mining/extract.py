from __future__ import annotations

import re
from pathlib import Path

from .config import config_path, output_path
from .io_utils import read_csv, stable_id, write_csv
from .text_utils import normalize_unit, split_sentences


EXTRACTION_FIELDS = [
    "record_id",
    "document_id",
    "chunk_id",
    "province",
    "city",
    "year",
    "indicator_original",
    "indicator_standard",
    "value_original",
    "unit_original",
    "value_standardized",
    "unit_standardized",
    "unit_family",
    "evidence_text",
    "source_url",
    "page",
    "extraction_method",
    "bert_label",
    "bert_confidence",
    "needs_llm_review",
    "needs_human_review",
]


VALUE_UNIT_RE = re.compile(
    r"(?P<value>\d+(?:\.\d+)?)\s*(?P<unit>万立方米/年|万吨/年|立方米/日|吨/日|万立方米|亿立方米|立方米|万吨|千吨|吨|%|％|座|处|家|个)"
)
YEAR_RE = re.compile(r"(20\d{2})\s*年")


def _city_province_map() -> dict[str, str]:
    return {row["city"]: row["province"] for row in read_csv(config_path("gd21_city_codebook.csv"))}


def _indicator_label_map() -> dict[str, str]:
    rows = read_csv(config_path("indicator_ontology.csv"))
    labels = {}
    for row in rows:
        labels[row["indicator_standard"]] = row["cn_label"]
    return labels


def _year_from_text(text: str) -> str:
    match = YEAR_RE.search(text)
    return match.group(1) if match else ""


def _best_evidence_sentence(text: str, value: str) -> str:
    for sentence in split_sentences(text):
        if value in sentence:
            return sentence
    return text[:260]


def extract_from_classification(row: dict[str, str]) -> list[dict[str, object]]:
    if row.get("chunk_candidate_label") != "1":
        return []
    text = row.get("text", "")
    indicator = row.get("indicator_type_label", "ambiguous") or "ambiguous"
    labels = _indicator_label_map()
    unit_rows = read_csv(config_path("unit_rules.csv"))
    province_map = _city_province_map()
    year = _year_from_text(text)
    records: list[dict[str, object]] = []
    for match in VALUE_UNIT_RE.finditer(text):
        raw_value = match.group("value")
        raw_unit = match.group("unit")
        value = float(raw_value)
        std_value, std_unit, unit_family = normalize_unit(value, raw_unit, unit_rows)
        evidence = _best_evidence_sentence(text, raw_value)
        needs_llm = indicator in {"other", "ambiguous"} or float(row.get("confidence", "0") or 0) < 0.75
        records.append(
            {
                "record_id": stable_id(row.get("chunk_id", ""), raw_value, raw_unit, indicator),
                "document_id": row.get("document_id", ""),
                "chunk_id": row.get("chunk_id", ""),
                "province": province_map.get(row.get("city", ""), "广东省"),
                "city": row.get("city", ""),
                "year": year,
                "indicator_original": labels.get(indicator, indicator),
                "indicator_standard": indicator if indicator != "other" else "ambiguous",
                "value_original": raw_value,
                "unit_original": raw_unit,
                "value_standardized": f"{std_value:.6g}",
                "unit_standardized": std_unit,
                "unit_family": unit_family,
                "evidence_text": evidence,
                "source_url": row.get("source_url", ""),
                "page": "",
                "extraction_method": "rule_regex_v1",
                "bert_label": indicator,
                "bert_confidence": row.get("confidence", ""),
                "needs_llm_review": "1" if needs_llm else "0",
                "needs_human_review": "1" if needs_llm or unit_family == "unknown" else "0",
            }
        )
    return records


def extract_candidates(classifications_csv: Path | None = None) -> list[dict[str, object]]:
    rows = read_csv(classifications_csv or output_path("bert_classification_results.csv"))
    records: list[dict[str, object]] = []
    for row in rows:
        records.extend(extract_from_classification(row))
    return records


def write_extractions(rows: list[dict[str, object]], output: Path) -> None:
    write_csv(output, rows, EXTRACTION_FIELDS)

