from __future__ import annotations

import html
import re
from html.parser import HTMLParser
from pathlib import Path

from .io_utils import read_csv


class _HTMLTextParser(HTMLParser):
    def __init__(self) -> None:
        super().__init__()
        self.parts: list[str] = []

    def handle_data(self, data: str) -> None:
        cleaned = data.strip()
        if cleaned:
            self.parts.append(cleaned)


def strip_html(raw_html: str) -> str:
    parser = _HTMLTextParser()
    parser.feed(raw_html)
    text = "\n".join(parser.parts)
    return normalize_whitespace(html.unescape(text))


def normalize_whitespace(text: str) -> str:
    text = text.replace("\u3000", " ")
    text = re.sub(r"[ \t\r\f\v]+", " ", text)
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip()


def load_keywords(keyword_csv: Path) -> list[str]:
    rows = read_csv(keyword_csv)
    return [row["keyword"] for row in rows if row.get("keyword")]


def find_keywords(text: str, keywords: list[str]) -> list[str]:
    found = [kw for kw in keywords if kw and kw in text]
    return sorted(set(found), key=found.index)


def split_sentences(text: str) -> list[str]:
    parts = re.split(r"(?<=[。！？；;])\s*|\n+", text)
    return [part.strip() for part in parts if part.strip()]


def chunk_text(text: str, keywords: list[str], window: int = 1) -> list[dict[str, object]]:
    sentences = split_sentences(text)
    chunks: list[dict[str, object]] = []
    seen: set[str] = set()
    for idx, sentence in enumerate(sentences):
        found = find_keywords(sentence, keywords)
        if not found:
            continue
        start = max(0, idx - window)
        end = min(len(sentences), idx + window + 1)
        chunk = "。".join(sentences[start:end])
        key = f"{start}:{end}:{chunk}"
        if key in seen:
            continue
        seen.add(key)
        chunks.append(
            {
                "text": chunk,
                "keywords_found": "|".join(find_keywords(chunk, keywords)),
                "char_start": text.find(sentences[start]),
                "char_end": text.find(sentences[end - 1]) + len(sentences[end - 1]),
            }
        )
    return chunks


def normalize_unit(value: float, unit: str, unit_rows: list[dict[str, str]]) -> tuple[float, str, str]:
    clean_unit = unit.strip()
    for row in unit_rows:
        if row.get("unit_original") == clean_unit:
            multiplier = float(row.get("multiplier", "1") or "1")
            return value * multiplier, row.get("unit_standardized", clean_unit), row.get("unit_family", "")
    return value, clean_unit, "unknown"

