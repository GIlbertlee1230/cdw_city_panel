# Initial rule baseline

Evaluate the initial rule prototype and metadata-aligned field correctness against archived audit labels. This baseline is distinct from the refined rules.

## Contents

- `data/`
- `evaluation_common.py`
- `historical_code/`
- `input_manifest.json`
- `main.py`
- `restored_v1/`
- `results/`

## Execution

Run from the project root in a separate Python process:

```bash
python analyses/rule_baseline/main.py --output outputs/rule_baseline
```

This command evaluates deterministic extraction on the supplied evidence and archived labels. It writes to the requested output directory and makes no LLM call.

## Interpretation

Definitions and analysis-specific limitations are in `docs/supplementary_information.md` at the project root. Scientific input files, labels and frozen results are preserved. The directory name describes the analysis rather than a review stage or internal experiment number.
