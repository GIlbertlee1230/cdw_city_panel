from __future__ import annotations

import csv
import hashlib
import json
import re
from collections import Counter
from pathlib import Path


INPUT = Path("Conference/Part0/Step2/outputs/part0_step2_candidate_fields.csv")
OUTPUT_DIR = Path("Conference/Part0/Step3A_BERT_ready/outputs")

CDW_TERMS = (
    "建筑垃圾",
    "建筑废弃物",
    "建设废弃物",
    "工程渣土",
    "工程泥浆",
    "工程垃圾",
    "拆除垃圾",
    "装修垃圾",
)
GENERATION_TERMS = ("产生量", "产生总量", "总产生量", "新增核准排放量")
PLANNING_TERMS = ("规划", "目标", "预测", "预计", "近期", "远期", "至2030", "至2035", "至2045", "到2030", "到2035")
TARGET_START = 2016
TARGET_END = 2024

SUPPORTING_INDICATORS = {
    "cdw_recycled",
    "cdw_disposed",
    "cdw_recycling_rate",
    "facility_count",
    "facility_capacity",
    "excavation_spoil",
    "renovation_waste",
}

ANNOTATION_FIELDS = [
    "human_is_cdw_relevant",
    "human_indicator_label",
    "human_accept_for_panel",
    "human_final_value_m3",
    "human_value_year",
    "human_source_level_confirmed",
    "human_reject_reason",
    "human_notes",
]

OUTPUT_FIELDS = [
    "sample_id",
    "field_id",
    "city",
    "year",
    "target_window_flag",
    "planning_target_flag",
    "field_source_level",
    "field_source_detail",
    "source_document_type",
    "source_file_name",
    "source_url",
    "indicator_standard_rule",
    "indicator_label_rule",
    "raw_value",
    "raw_unit",
    "value_standardized",
    "unit_standardized",
    "value_m3_if_applicable",
    "standardization_status",
    "m3_conversion_note",
    "page",
    "evidence_text",
    "bert_input_text",
    "weak_is_cdw_relevant",
    "weak_indicator_label",
    "weak_priority_label",
    "weak_label_source",
    "needs_bert",
    "needs_llm_review",
    "needs_human_review",
    "quality_flags",
    "annotation_batch",
    *ANNOTATION_FIELDS,
]


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))


def write_csv(path: Path, rows: list[dict[str, object]], fields: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


def stable_id(*parts: str, length: int = 14) -> str:
    text = "||".join(str(part) for part in parts)
    return hashlib.sha1(text.encode("utf-8")).hexdigest()[:length].upper()


def clean_text(text: str) -> str:
    return re.sub(r"\s+", " ", text or "").strip()


def clip_text(text: str, limit: int = 900) -> str:
    text = clean_text(text)
    if len(text) <= limit:
        return text
    return text[: limit - 1] + "…"


def parse_year(year: str) -> int | None:
    if not year or not str(year).isdigit():
        return None
    value = int(year)
    return value if 1900 <= value <= 2100 else None


def has_any(text: str, terms: tuple[str, ...]) -> bool:
    return any(term in text for term in terms)


def is_target_window(year: str) -> bool:
    parsed = parse_year(year)
    return parsed is not None and TARGET_START <= parsed <= TARGET_END


def is_planning_target(row: dict[str, str]) -> bool:
    year = parse_year(row.get("year", ""))
    evidence = row.get("evidence_text", "")
    source_type = row.get("source_document_type", "")
    if year is not None and year > TARGET_END:
        return True
    if source_type in {"municipal_plan", "provincial_plan"} and has_any(evidence, PLANNING_TERMS):
        return True
    return False


def weak_is_cdw_relevant(row: dict[str, str]) -> str:
    evidence = row.get("evidence_text", "")
    if has_any(evidence, CDW_TERMS):
        return "1"
    if row.get("indicator_standard") in SUPPORTING_INDICATORS | {"cdw_generation_total", "cdw_collected"}:
        return "1"
    return "uncertain"


def weak_priority_label(row: dict[str, str]) -> str:
    indicator = row.get("indicator_standard", "")
    evidence = row.get("evidence_text", "")
    target = is_target_window(row.get("year", ""))
    planning = is_planning_target(row)
    if not target:
        return "exclude_outside_target_window"
    if planning:
        return "planning_target_review"
    if indicator == "cdw_generation_total":
        return "high_priority_generation"
    if indicator == "cdw_collected":
        return "ambiguous_collection_generation_review"
    if indicator == "ambiguous" and has_any(evidence, CDW_TERMS) and has_any(evidence, GENERATION_TERMS):
        return "ambiguous_generation_review"
    if indicator in SUPPORTING_INDICATORS:
        return "supporting_indicator"
    if indicator == "ambiguous":
        return "ambiguous_review"
    return "exclude_non_target_or_unclear"


def needs_bert(row: dict[str, str], priority: str) -> str:
    if row.get("indicator_standard") == "ambiguous":
        return "1"
    if priority in {"ambiguous_generation_review", "ambiguous_collection_generation_review", "planning_target_review"}:
        return "1"
    return "0"


def build_bert_input(row: dict[str, str]) -> str:
    parts = [
        f"城市：{row.get('city', '')}",
        f"年份：{row.get('year', '')}",
        f"来源层级：{row.get('field_source_level', '')}",
        f"来源类型：{row.get('source_document_type', '')}",
        f"规则候选指标：{row.get('indicator_standard', '')}",
        f"原始数值：{row.get('raw_value', '')}",
        f"原始单位：{row.get('raw_unit', '')}",
        f"标准化值：{row.get('value_standardized', '')}",
        f"标准化单位：{row.get('unit_standardized', '')}",
        f"折算立方米：{row.get('value_m3_if_applicable', '')}",
        f"证据文本：{clip_text(row.get('evidence_text', ''))}",
    ]
    return " [SEP] ".join(parts)


def annotation_batch(priority: str) -> str:
    if priority in {"high_priority_generation", "ambiguous_generation_review", "ambiguous_collection_generation_review"}:
        return "batch_1_target_generation_review"
    if priority == "planning_target_review":
        return "batch_2_planning_or_future_year_review"
    if priority == "supporting_indicator":
        return "batch_3_supporting_indicator_optional"
    return "batch_4_low_priority_or_exclusion_check"


def build_rows(rows: list[dict[str, str]]) -> list[dict[str, object]]:
    output: list[dict[str, object]] = []
    for row in rows:
        priority = weak_priority_label(row)
        target_flag = "1" if is_target_window(row.get("year", "")) else "0"
        planning_flag = "1" if is_planning_target(row) else "0"
        sample = {
            "sample_id": "BERT_" + stable_id(row.get("field_id", ""), row.get("evidence_text", "")),
            "field_id": row.get("field_id", ""),
            "city": row.get("city", ""),
            "year": row.get("year", ""),
            "target_window_flag": target_flag,
            "planning_target_flag": planning_flag,
            "field_source_level": row.get("field_source_level", ""),
            "field_source_detail": row.get("field_source_detail", ""),
            "source_document_type": row.get("source_document_type", ""),
            "source_file_name": row.get("source_file_name", ""),
            "source_url": row.get("source_url", ""),
            "indicator_standard_rule": row.get("indicator_standard", ""),
            "indicator_label_rule": row.get("indicator_label", ""),
            "raw_value": row.get("raw_value", ""),
            "raw_unit": row.get("raw_unit", ""),
            "value_standardized": row.get("value_standardized", ""),
            "unit_standardized": row.get("unit_standardized", ""),
            "value_m3_if_applicable": row.get("value_m3_if_applicable", ""),
            "standardization_status": row.get("standardization_status", ""),
            "m3_conversion_note": row.get("m3_conversion_note", ""),
            "page": row.get("page", ""),
            "evidence_text": clean_text(row.get("evidence_text", "")),
            "bert_input_text": build_bert_input(row),
            "weak_is_cdw_relevant": weak_is_cdw_relevant(row),
            "weak_indicator_label": row.get("indicator_standard", ""),
            "weak_priority_label": priority,
            "weak_label_source": "rule_based_weak_label_from_step2_candidate_fields",
            "needs_bert": needs_bert(row, priority),
            "needs_llm_review": row.get("needs_llm_review", ""),
            "needs_human_review": row.get("needs_human_review", ""),
            "quality_flags": row.get("quality_flags", ""),
            "annotation_batch": annotation_batch(priority),
        }
        for field in ANNOTATION_FIELDS:
            sample[field] = ""
        output.append(sample)
    return output


def build_annotation_queue(rows: list[dict[str, object]]) -> list[dict[str, object]]:
    priority_order = {
        "high_priority_generation": 1,
        "ambiguous_generation_review": 2,
        "ambiguous_collection_generation_review": 3,
        "planning_target_review": 4,
        "supporting_indicator": 5,
        "ambiguous_review": 6,
        "exclude_outside_target_window": 7,
        "exclude_non_target_or_unclear": 8,
    }
    queue = [
        row
        for row in rows
        if row["annotation_batch"] in {"batch_1_target_generation_review", "batch_2_planning_or_future_year_review"}
    ]
    seen: set[tuple[str, str, str, str, str, str]] = set()
    deduped: list[dict[str, object]] = []
    for row in sorted(
        queue,
        key=lambda r: (
            priority_order.get(str(r["weak_priority_label"]), 99),
            str(r["city"]),
            str(r["year"]),
            str(r["field_source_level"]),
            str(r["source_file_name"]),
        ),
    ):
        key = (
            str(row["city"]),
            str(row["year"]),
            str(row["indicator_standard_rule"]),
            str(row["raw_value"]),
            str(row["raw_unit"]),
            clean_text(str(row["evidence_text"]))[:160],
        )
        if key in seen:
            continue
        seen.add(key)
        deduped.append(row)
    return deduped


def main() -> None:
    rows = read_csv(INPUT)
    bert_rows = build_rows(rows)
    queue_rows = build_annotation_queue(bert_rows)
    write_csv(OUTPUT_DIR / "step3a_bert_ready_candidates.csv", bert_rows, OUTPUT_FIELDS)
    write_csv(OUTPUT_DIR / "step3a_manual_annotation_queue.csv", queue_rows, OUTPUT_FIELDS)

    summary = {
        "input_step2_candidate_rows": len(rows),
        "bert_ready_rows": len(bert_rows),
        "manual_annotation_queue_rows": len(queue_rows),
        "priority_counts": dict(Counter(str(row["weak_priority_label"]) for row in bert_rows)),
        "annotation_batch_counts": dict(Counter(str(row["annotation_batch"]) for row in bert_rows)),
        "human_gold_label_columns": ANNOTATION_FIELDS,
        "method_note": "Weak labels are generated from deterministic rules and are not treated as ground truth. Human annotation columns are intentionally blank.",
    }
    (OUTPUT_DIR / "step3a_bert_ready_summary.json").write_text(
        json.dumps(summary, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
