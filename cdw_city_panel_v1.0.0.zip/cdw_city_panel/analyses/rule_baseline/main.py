"""Compare a recovered historical prototype with preserved later references."""
from pathlib import Path
from datetime import datetime
from decimal import Decimal
from collections import Counter
import argparse
import hashlib
import importlib.util
import json
import sys

import evaluation_common as common

BASE = Path(__file__).resolve().parent


def select_record(records, raw):
    unique = {}
    for row in records:
        key = tuple(str(row.get(k, '')) for k in ['city', 'year', 'value_original', 'unit_original', 'indicator_standard'])
        unique.setdefault(key, row)
    records = list(unique.values())
    matching = [r for r in records if common.numeric_equal(r['value_original'], raw.get('raw_value', ''))
                and ''.join(r['unit_original'].split()) == ''.join(raw.get('raw_unit', '').split())]
    if len(matching) == 1:
        return matching[0], 'matching_existing_candidate_hint'
    if len(matching) > 1:
        return None, 'ambiguous_matching_records'
    quantities = [r for r in records if r.get('unit_family') in ['mass', 'volume']]
    if len(quantities) == 1:
        return quantities[0], 'single_quantity_fallback'
    if len(quantities) > 1:
        return None, 'ambiguous_multiple_quantities'
    return None, 'no_quantity_record'


def load_early_modules():
    sys.path.insert(0, str(BASE / 'restored_v1'))
    from cdw_mining import classify, extract, text_utils
    return classify, extract, text_utils


def early_prediction(raw, modules, keywords):
    classify, extract, utils = modules
    text = raw['evidence_text']
    row = dict(text=text, city=raw['city'], source_url=raw['source_url'],
               chunk_id=raw['field_id'], document_id=raw['source_file_name'],
               keywords_found='|'.join(utils.find_keywords(text, keywords)))
    classified = classify.classify_chunk(row)
    records = extract.extract_from_classification(dict(classified, text=text))
    chosen, reason = select_record(records, raw)
    pred = dict(positive=False, priority=classified['indicator_type_label'],
                city='', year='', raw_value='', raw_unit='', indicator='')
    if chosen is not None:
        year = chosen.get('year') or raw['year']
        city = chosen.get('city') or raw['city']
        valid_year = common.numeric_equal(year, int(Decimal(year))) and 2016 <= int(Decimal(year)) <= 2024
        pred.update(city=city, year=year, raw_value=chosen['value_original'],
                    raw_unit=chosen['unit_original'], indicator=chosen['indicator_standard'],
                    positive=chosen['indicator_standard'] == 'cdw_generation_total'
                    and chosen['unit_family'] in ['mass', 'volume'] and valid_year)
    return pred, records, classified, reason


def align_existing_metadata(prediction, raw):
    result = dict(prediction)
    if result['raw_value']:
        result['city'] = raw['city']
        result['year'] = raw['year']
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    output = args.output or BASE / 'runs' / datetime.now().strftime('%Y%m%d_%H%M%S_%f')
    output.mkdir(parents=True, exist_ok=False)
    for name, item in json.loads((BASE / 'input_manifest.json').read_text()).items():
        assert hashlib.sha256((BASE / name).read_bytes()).hexdigest() == item['sha256'], name
    modules = load_early_modules()
    keywords = modules[2].load_keywords(BASE / 'restored_v1/config/keyword_dictionary.csv')
    raw_map = common.index(common.read(BASE / 'data/extraction_candidates.csv'), 'field_id')
    gold = common.read(BASE / 'data/audit_labels_and_llm_outputs.csv')
    spec = importlib.util.spec_from_file_location('later_priority', BASE / 'historical_code/baseline_extractor.py')
    later = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(later)
    predictions, early_outputs = [], []
    for reference in gold:
        raw = raw_map[reference['field_id']]
        early, records, classified, reason = early_prediction(raw, modules, keywords)
        for number, record in enumerate(records, 1):
            early_outputs.append(dict(benchmark_id=reference['benchmark_id'], output_number=number,
                                      city=record['city'], year=record['year'],
                                      raw_value=record['value_original'], raw_unit=record['unit_original'],
                                      indicator=record['indicator_standard'], unit_family=record['unit_family'],
                                      evidence_text=record['evidence_text'], extraction_method=record['extraction_method']))
        methods = [('recovered_initial_rule_v1', early),
                   ('initial_v1_shared_metadata_sensitivity', align_existing_metadata(early, raw)),
                   ('historical_rule_policy', common.rule_prediction(raw, later)),
                   ('archived_deepseek', common.archived_llm_prediction(reference))]
        for method, pred in methods:
            predictions.append(dict(benchmark_id=reference['benchmark_id'], field_id=reference['field_id'],
                                    stratum=reference['benchmark_stratum'], method=method,
                                    passage_cluster=hashlib.sha256(common.passage_key(raw).encode()).hexdigest()[:16],
                                    predicted_city=pred['city'], predicted_year=pred['year'],
                                    predicted_raw_value=pred['raw_value'], predicted_raw_unit=pred['raw_unit'],
                                    predicted_indicator=pred['indicator'],
                                    initial_text_label=classified['indicator_type_label'] if method in ['recovered_initial_rule_v1', 'initial_v1_shared_metadata_sensitivity'] else '',
                                    initial_output_count=len(records) if method in ['recovered_initial_rule_v1', 'initial_v1_shared_metadata_sensitivity'] else '',
                                    adapter_reason=reason if method in ['recovered_initial_rule_v1', 'initial_v1_shared_metadata_sensitivity'] else '',
                                    **common.score(pred, reference)))
    common.write(output / 'all_predictions_and_field_checks.csv', predictions)
    common.write(output / 'initial_v1_all_extracted_records.csv', early_outputs)
    summaries = []
    for method in ['recovered_initial_rule_v1', 'initial_v1_shared_metadata_sensitivity', 'historical_rule_policy', 'archived_deepseek']:
        subset = [r for r in predictions if r['method'] == method]
        summaries.append(common.metrics(subset, method, 'all120'))
        for stratum in sorted({r['stratum'] for r in subset}):
            summaries.append(common.metrics([r for r in subset if r['stratum'] == stratum], method, stratum))
    common.write(output / 'comparison.csv', summaries)
    errors = [r for r in predictions if r['human_positive'] != r['predicted_positive'] or r['human_positive'] and not r['joint_record_correct']]
    common.write(output / 'all_errors.csv', errors, list(predictions[0]))
    previous = common.read(BASE / 'data/reference_metrics.csv')
    for row in summaries:
        if row['method'] in ['recovered_initial_rule_v1', 'initial_v1_shared_metadata_sensitivity']:
            continue
        saved = next(r for r in previous if r['method'] == row['method'] and r['scope'] == row['scope'])
        for field in ['n', 'tp', 'fp', 'fn', 'tn', 'precision', 'recall', 'f1', 'accuracy',
                      'normalized_joint_correct', 'normalized_joint_recall', 'normalized_joint_precision']:
            assert common.numeric_equal(row[field], saved[field]) or row[field] == saved[field] == '', (field, row, saved)
    prototype = [r for r in predictions if r['method'] == 'recovered_initial_rule_v1']
    receipt = dict(status='complete_retrospective_historical_prototype_comparison',
                   n_audited_candidates=len(gold), original_prototype_extracted_records=len(early_outputs),
                   comparison=[r for r in summaries if r['scope'] == 'all120'],
                   adapter_counts=dict(Counter(r['adapter_reason'] for r in prototype)),
                   experiment37_reference_metrics_unchanged=True,
                   restored_code_unmodified=True, new_llm_calls=0, new_predictive_fits=0,
                   new_human_labels=0, new_blind_test=False, original_deployed_baseline=False,
                   whole_document_extraction_evaluated=False)
    (output / 'receipt.json').write_text(json.dumps(receipt, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps(receipt, ensure_ascii=False))


if __name__ == '__main__':
    main()
