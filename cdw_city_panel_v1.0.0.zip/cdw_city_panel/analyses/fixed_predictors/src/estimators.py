"""Actual 2026-06-09 candidate grid and estimators, extracted without algorithm changes.
I/O is supplied by run_reproduction.py; this module has no import-time writes.
"""
import itertools

import json

import math

import platform

import sys

from pathlib import Path

import numpy as np

import pandas as pd

import sklearn

from sklearn.base import BaseEstimator, TransformerMixin

from sklearn.ensemble import ExtraTreesRegressor, GradientBoostingRegressor, RandomForestRegressor

from sklearn.gaussian_process import GaussianProcessRegressor

from sklearn.gaussian_process.kernels import ConstantKernel, RBF

from sklearn.impute import SimpleImputer

from sklearn.kernel_ridge import KernelRidge

from sklearn.linear_model import ElasticNet, HuberRegressor, Ridge

from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

from sklearn.neural_network import MLPRegressor

from sklearn.pipeline import Pipeline

from sklearn.preprocessing import PolynomialFeatures, StandardScaler

from sklearn.svm import SVR

SEED = 20260609

TARGET = "ln_cdw_m3"

HOLDOUT_YEAR = 2024

TRAIN_START = 2016

TRAIN_END = 2023

INNER_VALIDATION_YEARS = [2021, 2022, 2023]

FEATURES = ["L1_outcome", "L2_ntl", "L2_urban_rate", "L2_fai", "L2_disp_income"]

COMPLEXITY_ORDER = {
    "Ridge": 0,
    "ElasticNet": 1,
    "Huber": 2,
    "SVR": 3,
    "KRR": 4,
    "PolynomialRidge": 5,
    "GPR": 6,
    "ExtraTrees": 7,
    "RandomForest": 8,
    "GradientBoosting": 9,
    "MLP": 10,
}

class ColumnWeighter(BaseEstimator, TransformerMixin):
    def __init__(self, weights=None):
        self.weights = weights

    def fit(self, x, y=None):
        return self

    def transform(self, x):
        if self.weights is None:
            return x
        return np.asarray(x, dtype=float) * np.asarray(self.weights, dtype=float)

def metrics(actual, prediction):
    actual = np.asarray(actual, dtype=float)
    prediction = np.asarray(prediction, dtype=float)
    return {
        "r2": float(r2_score(actual, prediction)),
        "rmse": float(math.sqrt(mean_squared_error(actual, prediction))),
        "mae": float(mean_absolute_error(actual, prediction)),
    }

def valid_rows(frame):
    return frame.dropna(subset=[TARGET, *FEATURES]).copy()

def weight_vector(dynamic_weight, n_features=5):
    return [float(dynamic_weight)] + [1.0] * (n_features - 1)

def candidate_specs():
    specs = []
    dynamic_weights = [1.0, 1.5, 2.0, 3.0, 5.0]

    for dynamic_weight, alpha in itertools.product(dynamic_weights, [0.001, 0.01, 0.1, 1.0, 10.0, 100.0]):
        specs.append(("Ridge", {"alpha": alpha, "dynamic_weight": dynamic_weight}))

    for dynamic_weight, alpha, l1_ratio in itertools.product(
        dynamic_weights, [0.0005, 0.001, 0.005, 0.01, 0.05, 0.1], [0.15, 0.3, 0.5, 0.7, 0.9]
    ):
        specs.append(("ElasticNet", {"alpha": alpha, "l1_ratio": l1_ratio, "dynamic_weight": dynamic_weight}))

    for dynamic_weight, epsilon in itertools.product(dynamic_weights, [1.1, 1.35]):
        specs.append(("Huber", {"epsilon": epsilon, "dynamic_weight": dynamic_weight}))

    for dynamic_weight, c, epsilon, gamma in itertools.product(
        dynamic_weights,
        [0.5, 1.0, 2.0, 4.0, 8.0, 16.0, 32.0, 64.0],
        [0.01, 0.03, 0.05, 0.08, 0.10, 0.15],
        [0.005, 0.01, 0.02, 0.03, 0.05, 0.08, 0.10, 0.20, "scale"],
    ):
        specs.append(("SVR", {"C": c, "epsilon": epsilon, "gamma": gamma, "dynamic_weight": dynamic_weight}))

    for dynamic_weight, alpha, gamma in itertools.product(
        dynamic_weights, [0.001, 0.003, 0.01, 0.03, 0.1, 0.3, 1.0, 3.0], [0.005, 0.01, 0.02, 0.03, 0.05, 0.08, 0.10, 0.20]
    ):
        specs.append(("KRR", {"alpha": alpha, "gamma": gamma, "dynamic_weight": dynamic_weight}))

    for dynamic_weight, degree, alpha in itertools.product(dynamic_weights, [2], [0.01, 0.1, 1.0, 10.0, 100.0]):
        specs.append(("PolynomialRidge", {"degree": degree, "alpha": alpha, "dynamic_weight": dynamic_weight}))

    for dynamic_weight, length_scale, alpha in itertools.product(dynamic_weights, [0.3, 0.7, 1.0, 2.0, 4.0], [0.005, 0.01, 0.03, 0.1]):
        specs.append(("GPR", {"length_scale": length_scale, "alpha": alpha, "dynamic_weight": dynamic_weight}))

    for leaf, max_features in itertools.product([1, 2, 3, 4, 6], [0.6, 0.8, 1.0]):
        specs.append(("ExtraTrees", {"min_samples_leaf": leaf, "max_features": max_features}))
        specs.append(("RandomForest", {"min_samples_leaf": leaf, "max_features": max_features}))

    for n_estimators, learning_rate, max_depth, subsample in itertools.product(
        [80, 150, 250], [0.02, 0.03, 0.05, 0.07], [1, 2, 3], [0.7, 1.0]
    ):
        specs.append(
            (
                "GradientBoosting",
                {
                    "n_estimators": n_estimators,
                    "learning_rate": learning_rate,
                    "max_depth": max_depth,
                    "subsample": subsample,
                },
            )
        )

    for dynamic_weight, hidden_layer_sizes, alpha, learning_rate_init in itertools.product(
        [1.0, 2.0, 3.0],
        [(3,), (5,), (8,), (5, 3)],
        [0.001, 0.01, 0.1],
        [0.001, 0.003],
    ):
        specs.append(
            (
                "MLP",
                {
                    "hidden_layer_sizes": hidden_layer_sizes,
                    "alpha": alpha,
                    "learning_rate_init": learning_rate_init,
                    "dynamic_weight": dynamic_weight,
                },
            )
        )

    return [
        {
            "candidate_id": index,
            "algorithm": algorithm,
            "params": params,
            "params_json": json.dumps(params, sort_keys=True),
        }
        for index, (algorithm, params) in enumerate(specs)
    ]

def estimator(spec, n_features=5):
    algorithm = spec["algorithm"]
    params = dict(spec["params"])
    dynamic_weight = params.pop("dynamic_weight", 1.0)
    weighted_steps = [
        ("imputer", SimpleImputer(strategy="median")),
        ("scale", StandardScaler()),
        ("weight", ColumnWeighter(weight_vector(dynamic_weight, n_features))),
    ]

    if algorithm == "Ridge":
        return Pipeline([*weighted_steps, ("model", Ridge(**params))])
    if algorithm == "ElasticNet":
        return Pipeline(
            [*weighted_steps, ("model", ElasticNet(max_iter=50000, random_state=SEED, **params))]
        )
    if algorithm == "Huber":
        return Pipeline([*weighted_steps, ("model", HuberRegressor(max_iter=5000, **params))])
    if algorithm == "SVR":
        return Pipeline([*weighted_steps, ("model", SVR(kernel="rbf", **params))])
    if algorithm == "KRR":
        return Pipeline([*weighted_steps, ("model", KernelRidge(kernel="rbf", **params))])
    if algorithm == "PolynomialRidge":
        degree = params.pop("degree")
        alpha = params.pop("alpha")
        return Pipeline(
            [
                *weighted_steps,
                ("poly", PolynomialFeatures(degree=degree, include_bias=False)),
                ("model", Ridge(alpha=alpha)),
            ]
        )
    if algorithm == "GPR":
        length_scale = params.pop("length_scale")
        alpha = params.pop("alpha")
        kernel = ConstantKernel(1.0, constant_value_bounds="fixed") * RBF(
            length_scale=length_scale, length_scale_bounds="fixed"
        )
        return Pipeline(
            [
                *weighted_steps,
                ("model", GaussianProcessRegressor(kernel=kernel, alpha=alpha, normalize_y=True, random_state=SEED)),
            ]
        )
    if algorithm == "ExtraTrees":
        return Pipeline(
            [
                ("imputer", SimpleImputer(strategy="median")),
                ("model", ExtraTreesRegressor(n_estimators=600, random_state=SEED, n_jobs=-1, **params)),
            ]
        )
    if algorithm == "RandomForest":
        return Pipeline(
            [
                ("imputer", SimpleImputer(strategy="median")),
                ("model", RandomForestRegressor(n_estimators=600, random_state=SEED, n_jobs=-1, **params)),
            ]
        )
    if algorithm == "GradientBoosting":
        return Pipeline(
            [
                ("imputer", SimpleImputer(strategy="median")),
                ("model", GradientBoostingRegressor(random_state=SEED, **params)),
            ]
        )
    if algorithm == "MLP":
        return Pipeline(
            [
                *weighted_steps,
                (
                    "model",
                    MLPRegressor(
                        max_iter=3000,
                        early_stopping=True,
                        validation_fraction=0.25,
                        random_state=SEED,
                        **params,
                    ),
                ),
            ]
        )
    raise ValueError(algorithm)

