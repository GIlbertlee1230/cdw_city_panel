# Training-fold checks of fixed predictors

Recheck the historically informed four-predictor specification using only each training window. This confirms admissibility conditional on the fixed inputs, not independent variable discovery.

## Contents

- `data/`
- `input_lineage.json`
- `main.py`
- `original_code/`
- `protocol.json`
- `requirements.txt`
- `results/`
- `src/`

## Execution

Run from the project root in a separate Python process:

```bash
python analyses/fixed_predictors/main.py --mode ridge
```

This fitting command uses the distributed inputs and the recorded analysis protocol. Generated runs are separate from the archived results; this analysis does not replace the primary selected model.

## Interpretation

Definitions and analysis-specific limitations are in `docs/supplementary_information.md` at the project root. Scientific input files, labels and frozen results are preserved. The directory name describes the analysis rather than a review stage or internal experiment number.
