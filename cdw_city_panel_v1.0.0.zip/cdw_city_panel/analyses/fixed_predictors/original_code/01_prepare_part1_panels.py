from pathlib import Path
import warnings

import numpy as np
import pandas as pd
from scipy.stats import pearsonr


ROOT = Path("[local-workspace]/Desktop/毕业论文/Conference/迁移学习/Part1_rerun_20260609")
CONFERENCE = ROOT.parents[1]
DATA = ROOT / "data"
OUTPUTS = ROOT / "outputs"
DATA.mkdir(parents=True, exist_ok=True)
OUTPUTS.mkdir(parents=True, exist_ok=True)

# 面板数据现位于 迁移学习/面板数据/（用户已将三份 xlsx 移入该处）。
PANEL_DIR = ROOT.parents[0] / "面板数据"
INPUTS = {
    "L1": PANEL_DIR / "面板数据_滞后一期.xlsx",
    "L2": PANEL_DIR / "面板数据_滞后两期.xlsx",
}
# 仅供滞后对齐审计的原始自变量文件；若不存在则在 main() 中跳过审计。
RAW_X = CONFERENCE / "自变量" / "21市自变量集合.xlsx"

GBA_CITIES = {"广州", "深圳", "珠海", "佛山", "惠州", "东莞", "中山", "江门", "肇庆"}

# source, safe name, Chinese label, module, transform, expected sign, GMM candidate
CANDIDATES = [
    ("建筑企业总产值_亿元", "ln_conout", "建筑企业总产值", "construction_activity", "log", 1, True),
    ("房屋建筑施工面积_万平方米", "ln_conarea", "房屋建筑施工面积", "construction_pipeline", "log", 1, True),
    ("城镇化率", "urban_rate_raw", "城镇化率", "urban_social", "level", 1, True),
    ("常住人口_万人", "ln_pop_10k", "常住人口", "population", "log", 1, True),
    ("固定资产投资", "ln_fai", "固定资产投资", "investment", "log", 1, True),
    ("house_invest_百万", "ln_house_invest", "房地产投资", "real_estate", "log", 1, True),
    ("地区生产总值_万元", "ln_gdp", "地区生产总值", "economy", "log", 1, True),
    ("行政区域土地面积_平方公里", "ln_land_area", "行政区域土地面积", "scale_control", "log", 0, False),
    ("第三产业增加值_万元", "ln_tertiary_value", "第三产业增加值", "economy", "log", 1, True),
    ("dnvalue", "ln_ntl", "夜间灯光", "urban_vitality", "log", 1, True),
    ("新开工面积_万平方米", "ln_new_start", "新开工面积", "construction_pipeline", "log", 1, True),
    ("建筑企业利润总额_亿", "ln_con_profit", "建筑企业利润总额", "industry_condition", "log", 1, True),
    ("人均可支配收入_元", "ln_disp_income", "人均可支配收入", "socioeconomic", "log", 1, True),
    ("消费支出_元", "ln_consumption", "消费支出", "socioeconomic", "log", 1, True),
    ("单位GDP能耗增长速度", "energy_growth_raw", "单位GDP能耗增长速度", "energy", "level", -1, True),
    ("第三产业增加值占比", "ln_tertiary_share", "第三产业增加值占比", "economic_structure", "log", 0, True),
    ("建筑业增加值_亿元", "ln_construction_va", "建筑业增加值", "construction_activity", "log", 1, True),
    ("房地产业增加值_亿元", "ln_realestate_va", "房地产业增加值", "real_estate", "log", 1, True),
    ("房价年均值（元/m2）", "ln_price", "房价年均值", "real_estate", "log", 1, True),
]

SAMPLES = {
    "primary_2018_2023": (2018, 2023, None),
    "sensitivity_2016_2023": (2016, 2023, None),
    "sensitivity_GBA_2018_2023": (2018, 2023, 1),
    "sensitivity_nonGBA_2018_2023": (2018, 2023, 0),
}


def norm_city(value):
    text = str(value).strip()
    return text[:-1] if text.endswith("市") else text


def safe_log(series):
    values = pd.to_numeric(series, errors="coerce")
    return pd.Series(np.where(values > 0, np.log(values), np.nan), index=series.index)


def corr_with_p(x, y):
    pair = pd.concat([pd.to_numeric(x, errors="coerce"), pd.to_numeric(y, errors="coerce")], axis=1).dropna()
    if len(pair) < 3 or pair.iloc[:, 0].nunique() < 2 or pair.iloc[:, 1].nunique() < 2:
        return np.nan, np.nan, len(pair)
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        result = pearsonr(pair.iloc[:, 0], pair.iloc[:, 1])
    return float(result.statistic), float(result.pvalue), len(pair)


def sample_frame(frame, sample):
    start, end, gba = SAMPLES[sample]
    out = frame[frame["year"].between(start, end)].copy()
    if gba is not None:
        out = out[out["GBA_dummy"] == gba].copy()
    return out


def calculate_vif(frame, variables):
    complete = frame[variables].dropna().astype(float)
    if len(complete) <= len(variables) + 1 or len(variables) < 2:
        return {}, len(complete)
    scores = {}
    for variable in variables:
        try:
            y = complete[variable].to_numpy(dtype=float)
            others = [v for v in variables if v != variable]
            x = complete[others].to_numpy(dtype=float)
            x = np.column_stack([np.ones(len(x)), x])
            beta, *_ = np.linalg.lstsq(x, y, rcond=None)
            fitted = x @ beta
            ss_res = float(np.sum((y - fitted) ** 2))
            ss_tot = float(np.sum((y - y.mean()) ** 2))
            r2 = 1.0 - ss_res / ss_tot if ss_tot > 0 else 1.0
            scores[variable] = float(1.0 / (1.0 - r2)) if r2 < 1 else np.inf
        except Exception:
            scores[variable] = np.inf
    return scores, len(complete)


def residualize_y_on_lag(frame):
    data = frame[["ln_cdw_m3", "L1_ln_cdw_m3"]].dropna()
    residual = pd.Series(np.nan, index=frame.index, dtype=float)
    if len(data) < 5:
        return residual
    y = data["ln_cdw_m3"].to_numpy(dtype=float)
    x = np.column_stack([np.ones(len(data)), data["L1_ln_cdw_m3"].to_numpy(dtype=float)])
    beta, *_ = np.linalg.lstsq(x, y, rcond=None)
    residual.loc[data.index] = y - (x @ beta)
    return residual


def reduced_vif(frame, variables, threshold=10.0):
    remaining = list(variables)
    removed = []
    while len(remaining) > 2:
        scores, n_complete = calculate_vif(frame, remaining)
        finite_scores = {k: v for k, v in scores.items() if pd.notna(v)}
        if not finite_scores:
            break
        worst = max(finite_scores, key=finite_scores.get)
        if finite_scores[worst] < threshold:
            break
        removed.append((worst, finite_scores[worst], n_complete))
        remaining.remove(worst)
    scores, n_complete = calculate_vif(frame, remaining)
    return remaining, scores, removed, n_complete


def main():
    if RAW_X.exists():
        raw_x = pd.read_excel(RAW_X)
        raw_x["district_name"] = raw_x["district_name"].map(norm_city)
        raw_x["year"] = pd.to_numeric(raw_x["year"], errors="raise").astype(int)
    else:
        raw_x = None
        warnings.warn(f"RAW_X not found ({RAW_X}); lag-alignment audit will be skipped.")

    panels = {}
    source_audit = []
    log_warnings = []
    lag_alignment = []
    city_year_audit = []
    variable_coverage = []
    pearson_outputs = {}
    vif_outputs = {}

    variable_map = pd.DataFrame(
        [
            {
                "source_column": source,
                "stata_name": safe,
                "cn_name": label,
                "category": module,
                "transform": transform,
                "expected_sign": sign,
                "gmm_candidate": int(gmm),
            }
            for source, safe, label, module, transform, sign, gmm in CANDIDATES
        ]
    )

    for window, path in INPUTS.items():
        df = pd.read_excel(path)
        df["district_name"] = df["district_name"].map(norm_city)
        df["year"] = pd.to_numeric(df["year"], errors="raise").astype(int)
        duplicate_count = int(df.duplicated(["district_name", "year"]).sum())
        if duplicate_count:
            raise ValueError(f"{window} has duplicate city-year rows: {duplicate_count}")
        df["GBA_dummy"] = df["district_name"].isin(GBA_CITIES).astype(int)
        df["city_id"] = pd.Categorical(df["district_name"], categories=sorted(df["district_name"].unique())).codes + 1
        df["ln_cdw_m3"] = safe_log(df["C_DW_generation_m3"])
        df = df.sort_values(["city_id", "year"]).reset_index(drop=True)
        prior_year = df.groupby("city_id")["year"].shift(1)
        prior_outcome = df.groupby("city_id")["ln_cdw_m3"].shift(1)
        consecutive = df["year"].sub(prior_year).eq(1)
        df["L1_ln_cdw_m3"] = prior_outcome.where(consecutive)
        df["delta_ln_cdw_m3"] = df["ln_cdw_m3"] - df["L1_ln_cdw_m3"]

        for source, safe, _label, _module, transform, _sign, _gmm in CANDIDATES:
            raw = pd.to_numeric(df[source], errors="coerce")
            nonpositive = int(((raw <= 0) & raw.notna()).sum())
            if transform == "log":
                df[safe] = safe_log(raw)
                if nonpositive:
                    log_warnings.append(
                        {
                            "window": window,
                            "source_column": source,
                            "stata_name": safe,
                            "nonpositive_count": nonpositive,
                            "action": "set_missing_before_log",
                        }
                    )
            else:
                df[safe] = raw

        source_audit.append(
            {
                "window": window,
                "input_file": str(path),
                "rows": len(df),
                "cities": df["district_name"].nunique(),
                "year_min": df["year"].min(),
                "year_max": df["year"].max(),
                "duplicate_city_year": duplicate_count,
                "positive_outcome_rows": int(df["ln_cdw_m3"].notna().sum()),
            }
        )

        for year, group in df.groupby("year"):
            city_year_audit.append(
                {
                    "window": window,
                    "year": int(year),
                    "rows": len(group),
                    "cities": group["district_name"].nunique(),
                    "outcome_non_missing": int(group["ln_cdw_m3"].notna().sum()),
                    "GBA_cities": int(group.loc[group["GBA_dummy"] == 1, "district_name"].nunique()),
                    "nonGBA_cities": int(group.loc[group["GBA_dummy"] == 0, "district_name"].nunique()),
                }
            )

        lag = 1 if window == "L1" else 2
        if raw_x is not None:
            raw_match = raw_x.copy()
            raw_match["year"] = raw_match["year"] + lag
            check = df.merge(
                raw_match,
                on=["district_name", "year"],
                how="left",
                suffixes=("_panel", "_raw"),
                validate="one_to_one",
            )
            for source, *_ in CANDIDATES:
                panel_col = f"{source}_panel"
                raw_col = f"{source}_raw"
                left = pd.to_numeric(check[panel_col], errors="coerce")
                right = pd.to_numeric(check[raw_col], errors="coerce")
                comparable = left.notna() & right.notna()
                mismatch = comparable & ~np.isclose(left, right, rtol=1e-9, atol=1e-8)
                lag_alignment.append(
                    {
                        "window": window,
                        "source_column": source,
                        "lag_years": lag,
                        "comparable_rows": int(comparable.sum()),
                        "mismatch_count": int(mismatch.sum()),
                    }
                )

        keep = [
            "district_name",
            "city_id",
            "year",
            "GBA_dummy",
            "C_DW_generation_m3",
            "ln_cdw_m3",
            "L1_ln_cdw_m3",
            "delta_ln_cdw_m3",
        ] + variable_map["stata_name"].tolist()
        model = df[keep].copy()
        panels[window] = model
        model.to_csv(DATA / f"part1_panel_{window}_2018_2023.csv", index=False, encoding="utf-8-sig")
        model.to_stata(DATA / f"part1_panel_{window}_2018_2023.dta", write_index=False, version=118)
        vm = variable_map.copy()
        vm.insert(0, "window", window)
        vm.to_csv(DATA / f"variable_map_{window}.csv", index=False, encoding="utf-8-sig")

        pearson_rows = []
        for sample in SAMPLES:
            sdf = sample_frame(model, sample)
            outcome_n = int(sdf["ln_cdw_m3"].notna().sum())
            delta_n = int(sdf["delta_ln_cdw_m3"].notna().sum())
            residual = residualize_y_on_lag(sdf)

            for row in variable_map.itertuples(index=False):
                x = row.stata_name
                pooled_r, pooled_p, pair_n = corr_with_p(sdf["ln_cdw_m3"], sdf[x])
                pair = sdf[["city_id", "ln_cdw_m3", x]].dropna()
                if len(pair) >= 3:
                    y_dm = pair["ln_cdw_m3"] - pair.groupby("city_id")["ln_cdw_m3"].transform("mean")
                    x_dm = pair[x] - pair.groupby("city_id")[x].transform("mean")
                    within_r, within_p, _ = corr_with_p(y_dm, x_dm)
                else:
                    within_r, within_p = np.nan, np.nan
                delta_r, delta_p, delta_pair_n = corr_with_p(sdf["delta_ln_cdw_m3"], sdf[x])
                resid_r, resid_p, resid_pair_n = corr_with_p(residual, sdf[x])
                city_coverage = int(sdf.loc[sdf["ln_cdw_m3"].notna() & sdf[x].notna(), "city_id"].nunique())
                pearson_rows.append(
                    {
                        "sample": sample,
                        "window": window,
                        "variable": x,
                        "cn_name": row.cn_name,
                        "category": row.category,
                        "gmm_candidate": row.gmm_candidate,
                        "outcome_n": outcome_n,
                        "pair_n_y": pair_n,
                        "coverage_y": pair_n / outcome_n if outcome_n else np.nan,
                        "city_coverage": city_coverage,
                        "pearson_pooled": pooled_r,
                        "pearson_pooled_p": pooled_p,
                        "pearson_within": within_r,
                        "pearson_within_p": within_p,
                        "delta_n": delta_n,
                        "pair_n_delta": delta_pair_n,
                        "coverage_delta": delta_pair_n / delta_n if delta_n else np.nan,
                        "delta_corr": delta_r,
                        "delta_p": delta_p,
                        "persistence_resid_pair_n": resid_pair_n,
                        "persistence_resid_corr": resid_r,
                        "persistence_resid_p": resid_p,
                        "coverage_pass": bool(outcome_n and pair_n / outcome_n >= 0.85 and city_coverage >= (15 if "GBA" not in sample else 7)),
                        "pearson_pass": bool(pd.notna(pooled_r) and abs(pooled_r) >= 0.50),
                    }
                )
                variable_coverage.append(
                    {
                        "sample": sample,
                        "window": window,
                        "variable": x,
                        "cn_name": row.cn_name,
                        "non_missing": int(sdf[x].notna().sum()),
                        "nonpositive_source_count": 0,
                        "outcome_non_missing": outcome_n,
                        "pair_n_y": pair_n,
                        "coverage_y": pair_n / outcome_n if outcome_n else np.nan,
                        "city_coverage": city_coverage,
                    }
                )

        pearson = pd.DataFrame(pearson_rows)
        pearson.to_csv(OUTPUTS / f"pearson_{window}.csv", index=False, encoding="utf-8-sig")
        pearson_outputs[window] = pearson
        pearson[
            [
                "sample",
                "window",
                "variable",
                "cn_name",
                "delta_corr",
                "delta_p",
                "persistence_resid_corr",
                "persistence_resid_p",
                "coverage_delta",
            ]
        ].to_csv(OUTPUTS / f"change_support_{window}.csv", index=False, encoding="utf-8-sig")

        primary_screen = pearson[
            (pearson["sample"] == "primary_2018_2023")
            & pearson["coverage_pass"]
            & pearson["gmm_candidate"].eq(1)
        ]
        vif_vars = primary_screen["variable"].tolist()
        primary_df = sample_frame(model, "primary_2018_2023")
        full_scores, full_n = calculate_vif(primary_df, vif_vars)
        remaining, reduced_scores, removed, reduced_n = reduced_vif(primary_df, vif_vars)
        vif_rows = []
        removed_order = {var: idx + 1 for idx, (var, _score, _n) in enumerate(removed)}
        for var in vif_vars:
            vif_rows.append(
                {
                    "window": window,
                    "group": "full",
                    "variable": var,
                    "vif": full_scores.get(var, np.nan),
                    "n_complete": full_n,
                    "included_final": int(var in remaining),
                    "removal_order": removed_order.get(var, np.nan),
                }
            )
        for var in remaining:
            vif_rows.append(
                {
                    "window": window,
                    "group": "reduced",
                    "variable": var,
                    "vif": reduced_scores.get(var, np.nan),
                    "n_complete": reduced_n,
                    "included_final": 1,
                    "removal_order": np.nan,
                }
            )
        vif = pd.DataFrame(vif_rows)
        vif.to_csv(OUTPUTS / f"vif_{window}.csv", index=False, encoding="utf-8-sig")
        vif_outputs[window] = vif

    # L1/L2 must carry exactly the same dependent-variable observations.
    y1 = panels["L1"][["district_name", "year", "C_DW_generation_m3"]]
    y2 = panels["L2"][["district_name", "year", "C_DW_generation_m3"]]
    if not y1.equals(y2):
        raise ValueError("L1 and L2 files do not contain identical dependent-variable rows.")

    pd.DataFrame(source_audit).to_csv(OUTPUTS / "data_audit_sources.csv", index=False, encoding="utf-8-sig")
    pd.DataFrame(city_year_audit).to_csv(
        OUTPUTS / "data_audit_city_year_coverage.csv", index=False, encoding="utf-8-sig"
    )
    pd.DataFrame(variable_coverage).to_csv(
        OUTPUTS / "data_audit_variable_coverage.csv", index=False, encoding="utf-8-sig"
    )
    pd.DataFrame(
        log_warnings,
        columns=["window", "source_column", "stata_name", "nonpositive_count", "action"],
    ).to_csv(
        OUTPUTS / "data_audit_log_transform_warnings.csv", index=False, encoding="utf-8-sig"
    )
    lag_df = pd.DataFrame(lag_alignment)
    lag_df.to_csv(OUTPUTS / "data_audit_lag_alignment.csv", index=False, encoding="utf-8-sig")
    if not lag_df.empty and int(lag_df["mismatch_count"].sum()) != 0:
        raise ValueError("Lag alignment audit found mismatches; input panels may be shifted incorrectly.")

    print("Prepared L1/L2 panels.")
    print("Rows:", {k: len(v) for k, v in panels.items()})
    print("Lag alignment mismatches:", int(lag_df["mismatch_count"].sum()) if not lag_df.empty else "skipped (no RAW_X)")
    print("Log warnings:", len(log_warnings))


if __name__ == "__main__":
    main()
