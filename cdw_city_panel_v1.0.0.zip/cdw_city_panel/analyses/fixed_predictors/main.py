"""Post-review fixed conceptual specification, training-fold gates and original search."""
import argparse,ast,hashlib,json,platform,sys,warnings,time
from pathlib import Path
from datetime import datetime,timezone
import numpy as np
import pandas as pd
import scipy,sklearn
from scipy.stats import pearsonr
from src.estimators import candidate_specs,estimator,metrics,COMPLEXITY_ORDER
ROOT=Path(__file__).resolve().parent
PROTOCOL=json.loads((ROOT/'protocol.json').read_text())
ROLES=PROTOCOL['roles']
SPEC_FEATURES=['L1_outcome']+[r['model_feature'] for r in ROLES]

def functions():
    p=ROOT/'original_code/01_prepare_part1_panels.py';tree=ast.parse(p.read_text())
    names={'corr_with_p','calculate_vif'}
    nodes=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in names]
    ns=dict(np=np,pd=pd,warnings=warnings,pearsonr=pearsonr)
    exec(compile(ast.Module(body=nodes,type_ignores=[]),str(p),'exec'),ns)
    return ns
ORIGINAL=functions()

def save_json(path,value):
    Path(path).write_text(json.dumps(value,indent=2,allow_nan=False,default=str)+'\n')

def load_panel():
    # Round-trip parsing preserves original serialized float values. Re-exported
    # decimal CSVs can perturb optimization/tree tie-breaking at machine precision.
    panel=pd.read_csv(ROOT/'data/archived_model_panel.csv',float_precision='round_trip')
    mapping=pd.read_csv(ROOT/'data/city_mapping.csv').set_index('workbook_city_normalized').city.to_dict()
    panel['district_name']=panel.district_name.map(mapping)
    if panel.district_name.isna().any():raise ValueError('Unknown city in original model panel')
    reference=pd.read_csv(ROOT/'data/model_panel.csv')
    assert panel[['district_name','year']].equals(reference[['district_name','year']])
    np.testing.assert_allclose(panel[['ln_cdw_m3']+SPEC_FEATURES],reference[['ln_cdw_m3']+SPEC_FEATURES],rtol=1e-12,atol=1e-12,equal_nan=True)
    return panel

def screen_compact(panel,cutoff):
    frame=panel[panel.year.between(2018,cutoff)]
    features=[r['screen_variable'] for r in ROLES]
    vifs,n=ORIGINAL['calculate_vif'](frame,features);rows=[]
    for role in ROLES:
        x=role['screen_variable'];r,p,pairs=ORIGINAL['corr_with_p'](frame.ln_cdw_m3,frame[x])
        cities=int(frame.loc[frame.ln_cdw_m3.notna()&frame[x].notna(),'city_id'].nunique())
        coverage=pairs/int(frame.ln_cdw_m3.notna().sum())
        passed=bool(coverage>=.85 and cities>=15 and np.isfinite(r) and abs(r)>=.5 and np.isfinite(vifs.get(x,np.nan)) and vifs[x]<10)
        rows.append(dict(**role,screen_start=2018,screen_end=cutoff,n_pairs=pairs,city_count=cities,coverage=coverage,
            pearson_r=r,pearson_p=p,vif=vifs.get(x,np.nan),vif_complete_rows=n,passed=passed,
            design_role='historically informed fixed representative; not full-pool discovery'))
    result=pd.DataFrame(rows)
    if not result.passed.all():raise ValueError('Compact-specification gate failed; no representative is silently forced or replaced')
    return result

def fit_predict(spec,train,valid):
    fitted=estimator(spec,len(SPEC_FEATURES));fitted.fit(train[SPEC_FEATURES],train.ln_cdw_m3)
    pred=np.asarray(fitted.predict(valid[SPEC_FEATURES]),dtype=float)
    if not np.isfinite(pred).all():raise ValueError('Non-finite prediction')
    return fitted,pred

def verify_handoff(screen,model):
    mapping=pd.read_csv(ROOT/'data/city_mapping.csv').set_index('workbook_city_normalized').city.to_dict()
    renamed=screen.copy();renamed['district_name']=renamed.district_name.map(mapping)
    rename={'L1_ln_cdw_m3':'L1_outcome',**{r['screen_variable']:r['model_feature'] for r in ROLES}}
    renamed=renamed.rename(columns=rename)
    cols=['ln_cdw_m3']+SPEC_FEATURES
    keys=['district_name','year']
    a=model[model.year<=2023].sort_values(keys).set_index(keys)
    b=renamed.sort_values(keys).set_index(keys)
    assert a.index.equals(b.index)
    # The original Part1 panel starts at2016, so its first dynamic lag is missing.
    # The original forecast panel can use2015 outcomes for Guangzhou/Shenzhen.
    static=['ln_cdw_m3']+[r['model_feature'] for r in ROLES]
    np.testing.assert_allclose(a[static],b[static],rtol=1e-12,atol=1e-12,equal_nan=True)
    lag_match=np.isclose(a.L1_outcome,b.L1_outcome,rtol=1e-12,atol=1e-12,equal_nan=True)
    assert set(a.index[~lag_match])=={('Guangzhou',2016),('Shenzhen',2016)}
    assert b.loc[~lag_match,'L1_outcome'].isna().all()
    raw=pd.read_csv(ROOT/'data/original_outcomes.csv').set_index(['district_name','year']).C_DW_generation_m3
    expected=np.array([np.log(raw.get((city,year-1),np.nan)) for city,year in a.index])
    np.testing.assert_allclose(a.L1_outcome,expected,rtol=1e-12,atol=1e-12,equal_nan=True)

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--mode',choices=['ridge','full'],default='ridge')
    args=parser.parse_args();out=ROOT/'runs'/datetime.now().strftime('%Y%m%d_%H%M%S_%f');out.mkdir(parents=True)
    for row in json.loads((ROOT/'input_lineage.json').read_text()):
        assert hashlib.sha256((ROOT/row['package_path']).read_bytes()).hexdigest()==row['sha256']
    save_json(out/'run_configuration.json',dict(protocol=PROTOCOL,mode=args.mode,started_utc=datetime.now(timezone.utc).isoformat(),
        source_hashes={str(f.relative_to(ROOT)):hashlib.sha256(f.read_bytes()).hexdigest() for f in [Path(__file__),ROOT/'protocol.json',ROOT/'src/estimators.py']},
        environment=dict(python=sys.version,numpy=np.__version__,pandas=pd.__version__,scipy=scipy.__version__,sklearn=sklearn.__version__,platform=platform.platform())))
    screening=pd.read_csv(ROOT/'data/screening_panel.csv');panel=load_panel();verify_handoff(screening,panel)
    gates=[];folds={};members=[];foldinfo=[]
    oldp=pd.read_csv(ROOT/'data/archived_pearson.csv').query("sample=='primary_2018_2023'").set_index('variable')
    for year in [2021,2022,2023,2024]:
        g=screen_compact(screening,year-1);gates.append(g.assign(validation_year=year))
        if year==2024:
            for row in g.itertuples():
                np.testing.assert_allclose([row.pearson_r,row.pearson_p],[oldp.loc[row.screen_variable,'pearson_pooled'],oldp.loc[row.screen_variable,'pearson_pooled_p']],rtol=1e-10,atol=1e-12)
        else:
            altered=screening.copy();cc=[c for c in screening.select_dtypes('number') if c!='year'];altered.loc[altered.year>=year,cc]=999999.
            pd.testing.assert_frame_equal(g,screen_compact(altered,year-1),check_exact=True)
        tr=panel[panel.year.between(2016,year-1)].dropna(subset=['ln_cdw_m3']+SPEC_FEATURES)
        # Preserve historical row order and sample definition, without passing evaluation labels to gates or fit.
        va=panel[panel.year.eq(year)&panel.GBA_dummy.eq(1)].dropna(subset=['ln_cdw_m3']+SPEC_FEATURES)
        assert (len(tr),len(va))=={2021:(42,8),2022:(61,9),2023:(82,9),2024:(103,9)}[year]
        folds[year]=(tr,va);foldinfo.append(dict(year=year,n_train=len(tr),n_validation=len(va),features='|'.join(SPEC_FEATURES),screen_end=year-1,max_vif=g.vif.max()))
        for role,frame in [('train',tr),('evaluate',va)]:
            members.extend(dict(validation_year=year,role=role,district_name=r.district_name,year=int(r.year)) for r in frame.itertuples())
    pd.concat(gates,ignore_index=True).to_csv(out/'fold_screening_checks.csv',index=False)
    pd.DataFrame(foldinfo).to_csv(out/'fold_design.csv',index=False);pd.DataFrame(members).to_csv(out/'sample_membership.csv',index=False)
    specs=candidate_specs();assert len(specs)==2969
    if args.mode=='ridge':specs=[s for s in specs if s['algorithm']=='Ridge']
    pd.DataFrame([{k:s[k] for k in ['candidate_id','algorithm','params_json']} for s in specs]).to_csv(out/'candidate_grid.csv',index=False)
    rows=[];failures=[];notes=[];start=time.monotonic()
    for index,spec in enumerate(specs):
        for year in [2021,2022,2023]:
            tr,va=folds[year]
            with warnings.catch_warnings(record=True) as caught:
                warnings.simplefilter('always')
                try:
                    _,pred=fit_predict(spec,tr,va)
                    rows.append(dict(candidate_id=spec['candidate_id'],algorithm=spec['algorithm'],params_json=spec['params_json'],
                        validation_year=year,n_train=len(tr),n_validation=len(va),**metrics(va.ln_cdw_m3,pred)))
                except Exception as e:failures.append(dict(candidate_id=spec['candidate_id'],year=year,error=type(e).__name__,message=str(e)))
                notes.extend(dict(candidate_id=spec['candidate_id'],year=year,category=w.category.__name__,message=str(w.message)) for w in caught)
        if (index+1)%100==0 or index+1==len(specs):print(f'{index+1}/{len(specs)} candidates; elapsed={time.monotonic()-start:.1f}s; failed={len(failures)}',flush=True)
    scores=pd.DataFrame(rows);scores.to_csv(out/'inner_fold_results.csv',index=False)
    pd.DataFrame(failures,columns=['candidate_id','year','error','message']).to_csv(out/'failed_fits.csv',index=False)
    pd.DataFrame(notes,columns=['candidate_id','year','category','message']).to_csv(out/'fit_warnings.csv',index=False)
    summary=scores.groupby(['candidate_id','algorithm','params_json'],as_index=False).agg(folds=('validation_year','nunique'),
        mean_inner_r2=('r2','mean'),mean_inner_rmse=('rmse','mean'),std_inner_rmse=('rmse',lambda x:x.std(ddof=0)),mean_inner_mae=('mae','mean'))
    summary=summary[summary.folds.eq(3)].copy();summary['objective']=summary.mean_inner_rmse+.15*summary.std_inner_rmse
    summary['complexity_order']=summary.algorithm.map(COMPLEXITY_ORDER)
    summary=summary.sort_values(['objective','mean_inner_mae','complexity_order','candidate_id'])
    summary.to_csv(out/'inner_candidate_summary.csv',index=False);winner=int(summary.iloc[0].candidate_id)
    spec=next(s for s in specs if s['candidate_id']==winner)
    save_json(out/'selection_before_target_evaluation.json',dict(spec=spec,features=SPEC_FEATURES,chosen_from='2021–2023 scores only',saved_utc=datetime.now(timezone.utc).isoformat()))
    tr,va=folds[2024];fit,pred=fit_predict(spec,tr,va)
    predictions=va[['district_name','year','ln_cdw_m3']+SPEC_FEATURES].copy();predictions['prediction_ln']=pred
    predictions.to_csv(out/'target_predictions.csv',index=False)
    result=metrics(va.ln_cdw_m3,pred);save_json(out/'target_metrics.json',result)
    validation=[]
    for year in [2021,2022,2023]:
        tr1,va1=folds[year];_,pr=fit_predict(spec,tr1,va1)
        ff=va1[['district_name','year','ln_cdw_m3']].copy();ff['prediction_ln']=pr;validation.append(ff)
    pd.concat(validation,ignore_index=True).to_csv(out/'selected_validation_predictions.csv',index=False)
    # Original archives are read for comparison only after current selection and predictions are frozen.
    archived=pd.read_csv(ROOT/'data/archived_inner_scores.csv')
    comparison=scores.merge(archived,on=['candidate_id','algorithm','params_json','validation_year'],suffixes=('_new','_archived'),validate='one_to_one')
    differences={c:float((comparison[c+'_new']-comparison[c+'_archived']).abs().max()) for c in ['r2','rmse','mae']}
    comparison.to_csv(out/'archived_score_comparison.csv',index=False)
    oldtarget=pd.read_csv(ROOT/'data/archived_2024_predictions.csv')
    mapping=pd.read_csv(ROOT/'data/city_mapping.csv').set_index('workbook_city_normalized').city.to_dict()
    oldtarget['district_name']=oldtarget.district_name.map(mapping)
    targetcomparison=predictions.merge(oldtarget[['district_name','year','pred_ln_cdw_m3']],on=['district_name','year'],validate='one_to_one')
    targetcomparison['prediction_difference']=targetcomparison.prediction_ln-targetcomparison.pred_ln_cdw_m3
    targetcomparison.to_csv(out/'target_prediction_comparison.csv',index=False)
    audit=dict(status='complete',mode=args.mode,successful_inner_fits=len(scores),expected_inner_fits=len(specs)*3,failed_fits=len(failures),fit_warnings=len(notes),
        winner=spec,metrics=result,all_four_pass_all_folds=True,future_numeric_mutation_invariance=True,archived_outcomes_and_structural_handoff_match=True,known_dynamic_scope_difference="Guangzhou/Shenzhen2016 use2015 outcome only in forecasting panel; all forecast L1 values verified against original raw outcomes",
        maximum_archived_inner_score_differences=differences,maximum_target_prediction_difference=float(targetcomparison.prediction_difference.abs().max()),
        statistical_window_isolation=True,conceptual_representatives_historically_informed=True,new_independent_feature_discovery=False,new_blind_test=False)
    save_json(out/'receipt.json',audit)
    (ROOT/'LATEST_RUN.txt').write_text(str(out.relative_to(ROOT))+'\n')
    print(json.dumps(audit,indent=2),flush=True);print('Saved:',out,flush=True)
if __name__=='__main__':main()
