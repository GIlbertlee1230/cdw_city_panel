"""Retrospective candidate-stage audit; standard library only, no model/API calls."""
from pathlib import Path
from collections import Counter, defaultdict
from decimal import Decimal, InvalidOperation
from datetime import datetime
import argparse
import csv
import hashlib
import importlib.util
import json
import random

BASE = Path(__file__).resolve().parent


def read(path):
    with Path(path).open(encoding='utf-8-sig', newline='') as stream:
        return list(csv.DictReader(stream))


def write(path, rows, fields=None):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('w', encoding='utf-8-sig', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=fields or list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def index(rows, key):
    result = {r[key]: r for r in rows}
    assert len(result) == len(rows), f'Duplicate {key}'
    return result


def normalized_city(value):
    return str(value).strip().removesuffix('市')


def passage_key(row):
    text = row.get('evidence_text', '')
    # Collapse HTML, readable HTML and TXT copies of the same city/year/text.
    year = str(Decimal(row['year']).normalize())
    return normalized_city(row['city']) + '|' + year + '|' + ''.join(text.split())


def numeric_equal(a, b):
    try:
        da, db = Decimal(str(a).strip()), Decimal(str(b).strip())
        return da.is_finite() and db.is_finite() and da == db
    except InvalidOperation:
        return False


def rule_prediction(raw, original):
    priority = original.weak_priority_label(raw)
    return {'positive': priority == 'high_priority_generation', 'priority': priority,
            'city': raw['city'], 'year': raw['year'], 'raw_value': raw['raw_value'],
            'raw_unit': raw['raw_unit'], 'indicator': raw['indicator_standard']}


def archived_llm_prediction(row):
    return {'positive': row['decision'] == 'accept', 'priority': '',
            'city': row['llm_city'], 'year': row['llm_data_year'],
            'raw_value': row['llm_raw_value'], 'raw_unit': row['llm_raw_unit'],
            'indicator': row['indicator_type']}


def score(pred, gold):
    human = gold['human_positive'].lower() == 'true'
    field_matches = {
        'city_match': normalized_city(pred['city']) == normalized_city(gold['human_city']),
        'year_match': numeric_equal(pred['year'], gold['human_data_year']),
        'raw_value_match': numeric_equal(pred['raw_value'], gold['human_raw_value']),
        'raw_unit_match': ''.join(pred['raw_unit'].split()) == ''.join(gold['human_raw_unit'].split()),
        'indicator_match': pred['indicator'] == gold['human_indicator_type'],
    }
    return {'human_positive': human, 'predicted_positive': pred['positive'], **field_matches,
            'joint_record_correct': human and pred['positive'] and all(field_matches.values())}


def metrics(rows, method, scope):
    tp = sum(r['human_positive'] and r['predicted_positive'] for r in rows)
    fp = sum(not r['human_positive'] and r['predicted_positive'] for r in rows)
    fn = sum(r['human_positive'] and not r['predicted_positive'] for r in rows)
    tn = len(rows) - tp - fp - fn
    joint = sum(r['joint_record_correct'] for r in rows)
    div = lambda a, b: a / b if b else ''
    return dict(method=method, scope=scope, n=len(rows), tp=tp, fp=fp, fn=fn, tn=tn,
                precision=div(tp, tp + fp), recall=div(tp, tp + fn),
                f1=div(2 * tp, 2 * tp + fp + fn), accuracy=div(tp + tn, len(rows)),
                normalized_joint_correct=joint,
                normalized_joint_recall=div(joint, tp + fn),
                normalized_joint_precision=div(joint, tp + fp))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    output = args.output or BASE / 'runs' / datetime.now().strftime('%Y%m%d_%H%M%S_%f')
    output.mkdir(parents=True, exist_ok=False)
    manifest = json.loads((BASE / 'input_manifest.json').read_text())
    for name, info in manifest.items():
        assert hashlib.sha256((BASE / name).read_bytes()).hexdigest() == info['sha256'], name
    human150 = read(BASE / 'data/historical_audit_labels.csv')
    scored = read(BASE / 'data/scored_candidates.csv')
    scored_map = index(scored, 'sample_id')
    queue = read(BASE / 'data/extraction_queue.csv')
    queue_ids = set(index(queue, 'sample_id'))
    human_map = index(human150, 'sample_id')
    split_map = {}
    for split in ['train', 'dev', 'test']:
        for row in read(BASE / f'data/bert_{split}.csv'):
            assert row['sample_id'] not in split_map
            split_map[row['sample_id']] = split
    assert set(split_map) == set(human_map)
    recreated_queue = set()
    for row in scored:
        if not numeric_equal(row['year'], int(Decimal(row['year']))):
            raise ValueError('Non-integer candidate year')
        year, probability = int(Decimal(row['year'])), Decimal(row['bert_accept_prob'])
        generation = row['indicator_standard_rule'] == 'cdw_generation_total' or row['weak_priority_label'] == 'high_priority_generation'
        if 2016 <= year <= 2024 and (probability >= Decimal('.20') or generation and probability >= Decimal('.10')):
            recreated_queue.add(row['sample_id'])
    assert recreated_queue == queue_ids, 'Historical queue rules do not reproduce archived queue'
    membership = []
    for row in human150:
        item = dict(row)
        item.update(in_final344=row['sample_id'] in queue_ids,
                    bert_split=split_map[row['sample_id']],
                    archived_bert_probability=scored_map[row['sample_id']]['bert_accept_prob'])
        membership.append(item)
    excluded = [r for r in membership if not r['in_final344']]
    write(output / 'historical150_queue_membership.csv', membership)
    write(output / 'historically_annotated_excluded87.csv', excluded)
    write(output / 'existing_excluded_test13.csv', [r for r in excluded if r['bert_split'] == 'test'])
    counts = Counter((r['in_final344'], r['bert_split'], r['human_accept_for_panel']) for r in membership)
    write(output / 'historical150_membership_counts.csv', [dict(in_final344=k[0], bert_split=k[1], human_decision=k[2], n=n) for k, n in sorted(counts.items())])

    spec = importlib.util.spec_from_file_location('historical_step3a', BASE / 'historical_code/baseline_extractor.py')
    original = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(original)
    gold120 = read(BASE / 'data/audit_labels_and_llm_outputs.csv')
    raw_map = index(read(BASE / 'data/extraction_candidates.csv'), 'field_id')
    scored_field_map = index(scored, 'field_id')
    predictions = []
    # Predict using source fields only, then score against frozen human labels.
    for gold in gold120:
        raw = raw_map[gold['field_id']]
        prediction = rule_prediction(raw, original)
        assert prediction['priority'] == scored_field_map[gold['field_id']]['weak_priority_label']
        for method, pred in [('historical_rule_policy', prediction), ('archived_deepseek', archived_llm_prediction(gold))]:
            predictions.append(dict(benchmark_id=gold['benchmark_id'], field_id=gold['field_id'],
                                    passage_cluster=hashlib.sha256(passage_key(gold).encode()).hexdigest()[:16],
                                    stratum=gold['benchmark_stratum'], method=method,
                                    predicted_city=pred['city'], predicted_year=pred['year'],
                                    predicted_raw_value=pred['raw_value'], predicted_raw_unit=pred['raw_unit'],
                                    predicted_indicator=pred['indicator'], rule_priority=pred['priority'],
                                    **score(pred, gold)))
    write(output / 'matched120_predictions_and_field_checks.csv', predictions)
    summaries = []
    for method in ['historical_rule_policy', 'archived_deepseek']:
        subset = [r for r in predictions if r['method'] == method]
        summaries.append(metrics(subset, method, 'all120'))
        for stratum in sorted({r['stratum'] for r in subset}):
            summaries.append(metrics([r for r in subset if r['stratum'] == stratum], method, stratum))
    write(output / 'candidate_stage_comparison.csv', summaries)
    write(output / 'matched120_errors.csv', [r for r in predictions if r['human_positive'] != r['predicted_positive'] or r['human_positive'] and not r['joint_record_correct']], list(predictions[0]))
    rule_results = {r['benchmark_id']: r for r in predictions if r['method'] == 'historical_rule_policy'}
    llm_results = {r['benchmark_id']: r for r in predictions if r['method'] == 'archived_deepseek'}
    paired = Counter((r['human_positive'] == r['predicted_positive'],
                      llm_results[key]['human_positive'] == llm_results[key]['predicted_positive'])
                     for key, r in rule_results.items())
    write(output / 'paired_candidate_decision_outcomes.csv', [dict(rule_correct=a, llm_correct=b, n=n) for (a, b), n in sorted(paired.items())])

    new_pool = []
    audited_fields = {r['field_id'] for r in gold120}
    for row in scored:
        if row['sample_id'] in queue_ids or row['sample_id'] in human_map or row['field_id'] in audited_fields:
            continue
        if not 2016 <= int(Decimal(row['year'])) <= 2024:
            continue
        if row['indicator_standard_rule'] == 'cdw_generation_total' or row['weak_priority_label'] == 'high_priority_generation':
            group = 'generation_like'
        elif row['indicator_standard_rule'] in ['ambiguous', 'cdw_collected']:
            group = 'ambiguous_or_collection'
        else:
            group = 'other'
        new_pool.append(dict(row, audit_stratum=group))
    # Annotation is passage-based. Collapse repeated candidate fields in the same
    # archived city-year passage, including identical text in different source
    # formats, before sampling; keep every member in the private key.
    by_passage = defaultdict(list)
    for row in sorted(new_pool, key=lambda r: r['sample_id']):
        by_passage[passage_key(row)].append(row)
    by_group = defaultdict(list)
    group_rank = {'generation_like': 0, 'ambiguous_or_collection': 1, 'other': 2}
    for members in by_passage.values():
        representative = min(members, key=lambda r: (group_rank[r['audit_stratum']], r['sample_id']))
        representative = dict(representative, member_sample_ids=json.dumps([r['sample_id'] for r in members]))
        by_group[representative['audit_stratum']].append(representative)
    rng = random.Random(20261101)
    selected = []
    sampling = []
    for group in ['generation_like', 'ambiguous_or_collection', 'other']:
        pool = by_group[group]
        sample = rng.sample(pool, min(20, len(pool)))
        selected.extend(sample)
        sampling.append(dict(stratum=group, population_n=len(pool), sample_n=len(sample),
                             inclusion_fraction=len(sample) / len(pool) if pool else ''))
    blind = []
    private = []
    for number, row in enumerate(selected, 1):
        audit_id = f'EXC-{number:03d}'
        blind.append(dict(audit_id=audit_id, source_file=row['source_file_name'], source_url=row['source_url'],
                          page=row['page'], city_hint=row['city'], year_hint=row['year'],
                          evidence_text=row['evidence_text'], human_decision='', human_indicator_type='',
                          human_city='', human_data_year='', human_raw_value='', human_raw_unit='',
                          human_evidence_quote='', human_rationale='', reviewer_id='', review_date=''))
        private.append(dict(audit_id=audit_id, sample_id=row['sample_id'], field_id=row['field_id'],
                            member_sample_ids=row['member_sample_ids'],
                            audit_stratum=row['audit_stratum'], bert_probability=row['bert_accept_prob'],
                            rule_indicator=row['indicator_standard_rule'], weak_priority=row['weak_priority_label']))
    write(output / 'new_excluded_manual_review_blank.csv', blind)
    write(output / 'private_after_annotation/sampling_key.csv', private)
    write(output / 'excluded_sampling_manifest.csv', sampling)
    assert not ({r['sample_id'] for r in selected} & (queue_ids | set(human_map)))
    receipt = dict(status='completed_retrospective_analysis_new_manual_review_pending',
                   historical150=len(human150), final_queue=len(queue_ids), scored_candidates=len(scored),
                   historical_excluded=len(excluded), excluded_decisions=dict(Counter(r['human_accept_for_panel'] for r in excluded)),
                   excluded_test_decisions=dict(Counter(r['human_accept_for_panel'] for r in excluded if r['bert_split'] == 'test')),
                   archived_queue_recreated_exactly=True, rule_priority_recreated_exactly=True,
                   all120_comparison=[r for r in summaries if r['scope'] == 'all120'],
                   rule_false_negative_unique_passages=len({r['passage_cluster'] for r in predictions if r['method'] == 'historical_rule_policy' and r['human_positive'] and not r['predicted_positive']}),
                   new_excluded_candidate_pool=len(new_pool), new_excluded_passage_pool=len(by_passage), new_manual_review_rows=len(blind),
                   new_manual_labels=0, new_llm_calls=0, new_predictive_model_fits=0,
                   end_to_end_recall_estimated=False, rules_independent_from_source_candidate_generation=False,
                   new_blind_model_evaluation=False)
    (output / 'receipt.json').write_text(json.dumps(receipt, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps(receipt, ensure_ascii=False))


if __name__ == '__main__':
    main()
