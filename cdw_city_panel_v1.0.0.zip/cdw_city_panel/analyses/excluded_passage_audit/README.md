# Excluded-passage audit

Inspect the stratified 60-passage human check, including five positives, 53 negatives and two uncertain cases. Uncertainty is retained. This does not estimate full-document recall.

## Contents

- `archived_receipt.json`
- `decision_change_log.csv`
- `excluded_sampling_manifest.csv`
- `five_positive_followup.csv`
- `historical_sampling_and_scoring.py`
- `human_decisions.csv`
- `positive_passages.csv`
- `sampling_inputs/`
- `sampling_key.csv`
- `stratum_summary.csv`
- `uncertain_passages.csv`

## Interpretation

Definitions and analysis-specific limitations are in `docs/supplementary_information.md` at the project root. Scientific input files, labels and frozen results are preserved. The directory name describes the analysis rather than a review stage or internal experiment number.
