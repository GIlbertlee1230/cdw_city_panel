from __future__ import annotations

import re
from pathlib import Path

from .config import config_path, output_path
from .io_utils import read_csv, stable_id, write_csv
from .text_utils import normalize_unit, split_sentences


EXTRACTION_FIELDS = [
    "record_id",
    "document_id",
    "chunk_id",
    "province",
    "city",
    "year",
    "indicator_original",
    "indicator_standard",
    "value_original",
    "unit_original",
    "value_standardized",
    "unit_standardized",
    "unit_family",
    "evidence_text",
    "source_url",
    "page",
    "extraction_method",
    "bert_label",
    "bert_confidence",
    "needs_llm_review",
    "needs_human_review",
]


VALUE_UNIT_RE = re.compile(
    r"(?P<value>\d+(?:\.\d+)?)[\s\u200e\u200f\u202a-\u202e]*(?P<unit>万立方米/年|万吨/年|立方米/日|吨/日|万立方米|亿立方米|立方米|万吨|千吨|吨|%|％|座|处|家|个)"
)
YEAR_RE = re.compile(r"(20\d{2})\s*年")
CDW_OBJECT_TERMS = ("建筑垃圾", "建筑废弃物", "建设废弃物", "工程渣土", "工程泥浆", "工程垃圾", "拆除垃圾", "装修垃圾")
NON_CDW_WASTE_TERMS = (
    "一般工业固体废物",
    "工业固体废物",
    "危险废物",
    "医疗废物",
    "生活垃圾",
    "厨余垃圾",
    "可回收物",
    "有害垃圾",
    "其他垃圾",
    "农业固体废物",
    "农作物秸秆",
    "城镇污水处理厂污泥",
    "污泥",
)


def _city_province_map() -> dict[str, str]:
    return {row["city"]: row["province"] for row in read_csv(config_path("gd21_city_codebook.csv"))}


def _indicator_label_map() -> dict[str, str]:
    rows = read_csv(config_path("indicator_ontology.csv"))
    labels = {}
    for row in rows:
        labels[row["indicator_standard"]] = row["cn_label"]
    return labels


def _indicator_alias_map() -> dict[str, list[str]]:
    aliases: dict[str, list[str]] = {}
    for row in read_csv(config_path("indicator_ontology.csv")):
        terms = [row["cn_label"]]
        terms.extend(part for part in row.get("aliases", "").split("|") if part)
        aliases[row["indicator_standard"]] = sorted(set(terms), key=len, reverse=True)
    return aliases


def _year_from_text(text: str) -> str:
    match = YEAR_RE.search(text)
    return match.group(1) if match else ""


def _best_evidence_sentence(text: str, value: str) -> str:
    for sentence in split_sentences(text):
        if value in sentence:
            return sentence
    return text[:260]


def _closest_indicator(sentence: str, match: re.Match[str], fallback: str, unit_family: str) -> str:
    value_start, value_end = match.span()
    window_start = max(0, value_start - 45)
    window_end = min(len(sentence), value_end + 30)
    window = sentence[window_start:window_end]
    local_prefix = sentence[max(0, value_start - 24):value_start]

    # Units carry strong semantics in C&DW disclosures: percentages usually
    # report rates, and count units usually report facilities rather than waste.
    if unit_family == "percent" and any(term in window for term in ("利用率", "综合利用率", "回收利用率", "率")):
        return "cdw_recycling_rate"
    if unit_family == "count" and any(term in window for term in ("设施", "处置场", "消纳场", "资源化利用厂", "处理厂", "单位开展")):
        return "facility_count"
    if unit_family in {"mass_per_year", "volume_per_year", "mass_per_day", "volume_per_day"} and any(
        term in window for term in ("处理能力", "处置能力", "设计处理能力", "年处理能力", "资源化利用能力")
    ):
        return "facility_capacity"
    if any(term in local_prefix for term in ("工程渣土", "工程泥浆")):
        return "excavation_spoil"
    if any(term in local_prefix for term in ("工程垃圾", "拆除垃圾", "装修垃圾")):
        return "renovation_waste"
    if any(term in local_prefix for term in ("资源利用量", "资源化利用量", "资源化处理量", "资源化处理", "综合利用量")):
        return "cdw_recycled"
    if any(term in local_prefix for term in ("填埋量", "填埋", "消纳量", "处置量")):
        return "cdw_disposed"
    if any(term in local_prefix for term in ("产生量", "总产生量", "新增核准排放量")):
        return "cdw_generation_total"
    if any(term in local_prefix for term in ("清运量", "收运量", "运输量")):
        return "cdw_collected"

    best_label = ""
    best_distance = 10_000
    for label, terms in _indicator_alias_map().items():
        if label == "ambiguous":
            continue
        for term in terms:
            search_start = 0
            while True:
                term_at = sentence.find(term, search_start)
                if term_at == -1:
                    break
                term_end = term_at + len(term)
                if term_end <= value_start:
                    distance = value_start - term_end
                elif term_at >= value_end:
                    distance = term_at - value_end + 8
                else:
                    distance = 0
                if distance < best_distance:
                    best_label = label
                    best_distance = distance
                search_start = term_at + 1
    if best_label and best_distance <= 45:
        return best_label
    return fallback if fallback != "other" else "ambiguous"


def _nearest_waste_term_before_value(sentence: str, value_start: int) -> str:
    prefix = sentence[:value_start]
    nearest_term = ""
    nearest_at = -1
    for term in CDW_OBJECT_TERMS + NON_CDW_WASTE_TERMS:
        term_at = prefix.rfind(term)
        if term_at > nearest_at:
            nearest_term = term
            nearest_at = term_at
    return nearest_term


def extract_from_classification(row: dict[str, str]) -> list[dict[str, object]]:
    if row.get("chunk_candidate_label") != "1":
        return []
    text = row.get("text", "")
    fallback_indicator = row.get("indicator_type_label", "ambiguous") or "ambiguous"
    labels = _indicator_label_map()
    unit_rows = read_csv(config_path("unit_rules.csv"))
    province_map = _city_province_map()
    year = _year_from_text(text)
    records: list[dict[str, object]] = []
    for sentence in split_sentences(text):
        has_cdw_object = any(term in sentence for term in CDW_OBJECT_TERMS)
        has_non_cdw_waste = any(term in sentence for term in NON_CDW_WASTE_TERMS)
        if has_non_cdw_waste and not has_cdw_object:
            continue
        sentence_year = _year_from_text(sentence) or year
        for match in VALUE_UNIT_RE.finditer(sentence):
            nearest_waste_term = _nearest_waste_term_before_value(sentence, match.start())
            if nearest_waste_term in NON_CDW_WASTE_TERMS:
                continue
            raw_value = match.group("value")
            raw_unit = match.group("unit")
            value = float(raw_value)
            std_value, std_unit, unit_family = normalize_unit(value, raw_unit, unit_rows)
            indicator = _closest_indicator(sentence, match, fallback_indicator, unit_family)
            needs_llm = indicator in {"other", "ambiguous"} or float(row.get("confidence", "0") or 0) < 0.75
            records.append(
                {
                    "record_id": stable_id(row.get("chunk_id", ""), raw_value, raw_unit, indicator),
                    "document_id": row.get("document_id", ""),
                    "chunk_id": row.get("chunk_id", ""),
                    "province": province_map.get(row.get("city", ""), "广东省"),
                    "city": row.get("city", ""),
                    "year": sentence_year,
                    "indicator_original": labels.get(indicator, indicator),
                    "indicator_standard": indicator if indicator != "other" else "ambiguous",
                    "value_original": raw_value,
                    "unit_original": raw_unit,
                    "value_standardized": f"{std_value:.6g}",
                    "unit_standardized": std_unit,
                    "unit_family": unit_family,
                    "evidence_text": sentence,
                    "source_url": row.get("source_url", ""),
                    "page": "",
                    "extraction_method": "rule_regex_v2",
                    "bert_label": fallback_indicator,
                    "bert_confidence": row.get("confidence", ""),
                    "needs_llm_review": "1" if needs_llm else "0",
                    "needs_human_review": "1" if needs_llm or unit_family == "unknown" else "0",
                }
            )
    return records


def extract_candidates(classifications_csv: Path | None = None) -> list[dict[str, object]]:
    rows = read_csv(classifications_csv or output_path("bert_classification_results.csv"))
    records: list[dict[str, object]] = []
    seen: set[tuple[str, str, str, str, str, str, str]] = set()
    for row in rows:
        for record in extract_from_classification(row):
            key = (
                str(record.get("city", "")),
                str(record.get("year", "")),
                str(record.get("indicator_standard", "")),
                str(record.get("value_standardized", "")),
                str(record.get("unit_standardized", "")),
                str(record.get("evidence_text", "")),
                str(record.get("source_url", "")),
            )
            if key in seen:
                continue
            seen.add(key)
            records.append(record)
    return records


def write_extractions(rows: list[dict[str, object]], output: Path) -> None:
    write_csv(output, rows, EXTRACTION_FIELDS)
