# Rules-only extraction comparison

Compare the refined deterministic extractor with archived LLM outputs on the same 120 audited candidates. The rule system was developed using these labels; the comparison is retrospective.

## Contents

- `data/`
- `evaluation_common.py`
- `historical_code/`
- `input_manifest.json`
- `main.py`
- `results/`
- `rule_engine/`

## Execution

Run from the project root in a separate Python process:

```bash
python analyses/rule_comparison/main.py --output outputs/rule_comparison
```

This command evaluates deterministic extraction on the supplied evidence and archived labels. It writes to the requested output directory and makes no LLM call.

## Interpretation

Definitions and analysis-specific limitations are in `docs/supplementary_information.md` at the project root. Scientific input files, labels and frozen results are preserved. The directory name describes the analysis rather than a review stage or internal experiment number.
