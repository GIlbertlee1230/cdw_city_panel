"""Matched-input extraction replay with unchanged historical local rules."""
from pathlib import Path
from datetime import datetime
from collections import Counter, defaultdict
from decimal import Decimal
import argparse
import hashlib
import importlib.util
import json
import sys

import evaluation_common as common

BASE = Path(__file__).resolve().parent
VISIBLE = {'field_id', 'city', 'year', 'rule_source_level', 'source_file_name',
           'source_url', 'rule_raw_value', 'rule_raw_unit', 'evidence_text'}


def load_engine():
    sys.path.insert(0, str(BASE / 'rule_engine'))
    from cdw_mining import classify, extract, text_utils
    spec = importlib.util.spec_from_file_location('prior_stage3a', BASE / 'historical_code/baseline_extractor.py')
    prior = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(prior)
    return classify, extract, text_utils, prior


def choose_target(records, payload):
    targets = {}
    for row in records:
        if row['indicator_standard'] != 'cdw_generation_total' or row['unit_family'] not in ['mass', 'volume']:
            continue
        key = (Decimal(row['value_original']).normalize(), ''.join(row['unit_original'].split()))
        targets.setdefault(key, row)
    if len(targets) == 1:
        return next(iter(targets.values())), 'unique_locally_classified_total'
    matches = [r for r in targets.values()
               if common.numeric_equal(r['value_original'], payload['rule_raw_value'])
               and ''.join(r['unit_original'].split()) == ''.join(payload['rule_raw_unit'].split())]
    if len(matches) == 1:
        return matches[0], 'multiple_totals_existing_hint_matches_one'
    return None, 'multiple_unresolved_totals' if targets else 'no_total_record'


def rule_prediction(payload, engine, keywords):
    assert set(payload) == VISIBLE
    classify, extract, utils, prior = engine
    text = payload['evidence_text']
    row = dict(chunk_id=payload['field_id'], document_id=payload['source_file_name'],
               text=text, city=payload['city'], source_url=payload['source_url'],
               keywords_found='|'.join(utils.find_keywords(text, keywords)))
    classification = classify.classify_chunk(row)
    records = extract.extract_from_classification(classification)
    source_kind = {'省级计划': 'provincial_plan', '市级计划': 'municipal_plan', '每年披露': 'annual_disclosure'}.get(payload['rule_source_level'], '')
    planning = prior.is_planning_target(dict(year=str(payload['year']), evidence_text=text, source_document_type=source_kind))
    chosen, reason = choose_target(records, payload)
    valid_year = 2016 <= int(payload['year']) <= 2024
    if not valid_year or planning:
        decision = 'reject'
        reason = 'outside_year_window' if not valid_year else 'historical_planning_flag'
    elif chosen is not None:
        decision = 'accept'
    elif reason == 'multiple_unresolved_totals' or not records or any(r['indicator_standard'] == 'ambiguous' for r in records):
        decision = 'needs_review'
    else:
        decision = 'reject'
    prediction = dict(positive=decision == 'accept', priority=classification['indicator_type_label'],
                      city=payload['city'], year=str(payload['year']),
                      raw_value=chosen['value_original'] if chosen else '',
                      raw_unit=chosen['unit_original'] if chosen else '',
                      indicator=chosen['indicator_standard'] if chosen else '')
    return prediction, records, decision, reason


def complexity(payload, extract):
    text = payload['evidence_text']
    if text.startswith('B1.'):
        return 'structured_provincial_table'
    categories = [
        ('产生量', '产生总量', '总产生量', '排放量'), ('处置', '填埋', '消纳'),
        ('清运', '收运', '运输'), ('资源化', '回收', '综合利用'), ('能力', '容量'),
        ('工程渣土', '工程泥浆', '装修垃圾', '拆除垃圾'), ('规划', '目标', '预测', '预计'),
    ]
    count = sum(any(term in text for term in group) for group in categories)
    return 'complex_narrative' if len(list(extract.VALUE_UNIT_RE.finditer(text))) >= 2 or count >= 2 else 'simple_narrative'


def label_signature(gold):
    positive = gold['human_positive'].lower() == 'true'
    if not positive:
        return (False,)
    return (True, common.normalized_city(gold['human_city']),
            Decimal(gold['human_data_year']).normalize(), Decimal(gold['human_raw_value']).normalize(),
            ''.join(gold['human_raw_unit'].split()), gold['human_indicator_type'])


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    output = args.output or BASE / 'runs' / datetime.now().strftime('%Y%m%d_%H%M%S_%f')
    output.mkdir(parents=True, exist_ok=False)
    for name, item in json.loads((BASE / 'input_manifest.json').read_text()).items():
        assert hashlib.sha256((BASE / name).read_bytes()).hexdigest() == item['sha256'], name
    payloads = [json.loads(line) for line in (BASE / 'data/visible_payloads.jsonl').read_text().splitlines()]
    assert all(set(r) == VISIBLE for r in payloads)
    payload_map = common.index(payloads, 'field_id')
    gold = common.read(BASE / 'data/audit_labels_and_llm_outputs.csv')
    engine = load_engine()
    keywords = engine[2].load_keywords(BASE / 'rule_engine/config/keyword_dictionary.csv')
    predictions, all_records = [], []
    groups = defaultdict(list)
    for g in sorted(gold, key=lambda r: r['benchmark_id']):
        p = payload_map[g['field_id']]
        key = common.passage_key(p)
        groups[key].append(g)
        cluster = hashlib.sha256(key.encode()).hexdigest()[:16]
        difficulty = complexity(p, engine[1])
        pred, records, decision, reason = rule_prediction(p, engine, keywords)
        for n, row in enumerate(records, 1):
            all_records.append(dict(benchmark_id=g['benchmark_id'], output_number=n,
                                    city=row['city'], year=row['year'], raw_value=row['value_original'],
                                    raw_unit=row['unit_original'], indicator=row['indicator_standard'],
                                    unit_family=row['unit_family'], evidence_text=row['evidence_text']))
        methods = [('matched_input_local_rule', pred, decision, reason),
                   ('archived_deepseek', common.archived_llm_prediction(g), g['decision'], '')]
        for method, prediction, action, why in methods:
            predictions.append(dict(benchmark_id=g['benchmark_id'], field_id=g['field_id'],
                                    stratum=g['benchmark_stratum'], complexity=difficulty,
                                    cluster=cluster, method=method, decision=action, reason=why,
                                    predicted_city=prediction['city'], predicted_year=prediction['year'],
                                    predicted_raw_value=prediction['raw_value'], predicted_raw_unit=prediction['raw_unit'],
                                    predicted_indicator=prediction['indicator'],
                                    archived_validation_errors=g['validation_error_codes'] if method == 'archived_deepseek' else '',
                                    **common.score(prediction, g)))
    common.write(output / 'all_predictions.csv', predictions)
    common.write(output / 'rule_all_extracted_records.csv', all_records)
    members, representatives = [], set()
    for key, items in groups.items():
        assert len({label_signature(g) for g in items}) == 1, ('Conflicting passage labels', [g['benchmark_id'] for g in items])
        first = items[0]['benchmark_id']
        representatives.add(first)
        for g in items:
            members.append(dict(cluster=hashlib.sha256(key.encode()).hexdigest()[:16],
                                benchmark_id=g['benchmark_id'], representative=first,
                                cluster_size=len(items), selected_representative=g['benchmark_id'] == first))
    common.write(output / 'passage_membership.csv', members)
    metrics = []
    for view, selected in [('all120', predictions), ('deduplicated_passages', [r for r in predictions if r['benchmark_id'] in representatives])]:
        for method in ['matched_input_local_rule', 'archived_deepseek']:
            subset = [r for r in selected if r['method'] == method]
            scopes = [('overall', subset)]
            scopes += [('source:' + s, [r for r in subset if r['stratum'] == s]) for s in sorted({r['stratum'] for r in subset})]
            scopes += [('complexity:' + c, [r for r in subset if r['complexity'] == c]) for c in sorted({r['complexity'] for r in subset})]
            for scope, rows in scopes:
                record = common.metrics(rows, method, scope)
                record.update(view=view, needs_review=sum(r['decision'] in ['needs_review', 'hold'] for r in rows))
                metrics.append(record)
    common.write(output / 'matched_comparison_by_scope.csv', metrics)
    errors = [r for r in predictions if r['human_positive'] != r['predicted_positive'] or r['human_positive'] and not r['joint_record_correct']]
    common.write(output / 'all_errors.csv', errors, list(predictions[0]))
    receipt = dict(status='complete_retrospective_matched_input_audit', n_candidates=len(gold),
                   n_unique_passages=len(groups), original_rule_code_unchanged=True,
                   visible_field_names=sorted(VISIBLE), upstream_indicator_label_provided=False,
                   new_llm_calls=0, new_human_labels=0, new_predictive_fits=0,
                   new_blind_test=False, overall=[r for r in metrics if r['scope'] == 'overall'])
    (output / 'receipt.json').write_text(json.dumps(receipt, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps(receipt, ensure_ascii=False))


if __name__ == '__main__':
    main()
