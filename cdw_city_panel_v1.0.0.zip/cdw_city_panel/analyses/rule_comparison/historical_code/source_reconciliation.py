#!/usr/bin/env python3
from __future__ import annotations

import argparse
import getpass
import json
import os
import sys
import urllib.request
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "src"))

from models import ExtractionResponse
from release import freeze_release_inputs
from validation import AttemptRecord, run_with_bounded_retries
from workbooks import (
    export_human_audit_workbook,
    make_heldout_gold_split,
    reconcile_panels,
)


DEEPSEEK_URL = "https://api.deepseek.com/chat/completions"


def load_config() -> dict:
    return json.loads((ROOT / "config" / "closure_config.json").read_text(encoding="utf-8"))


def run_dir(run_id: str) -> Path:
    return ROOT / "runs" / run_id


def assert_run_ready(directory: Path) -> None:
    required = ["manifest.json", "frozen_queue.csv", "prompt.txt", "schema.json"]
    missing = [name for name in required if not (directory / name).is_file()]
    if missing:
        raise SystemExit(f"Refusing API run; missing frozen artifacts: {', '.join(missing)}")


def load_gold_queue(gold_split_path: Path) -> pd.DataFrame:
    split = pd.read_csv(gold_split_path)
    return split.loc[split["split"] == "gold"].copy()


def _write_schema() -> Path:
    path = ROOT / "config" / "canonical_schema.json"
    path.write_text(json.dumps(ExtractionResponse.model_json_schema(), ensure_ascii=False, indent=2), encoding="utf-8")
    return path


def prepare_release(run_id: str, gold_minimum: int, gold_maximum: int, gold_target: int, seed: int) -> Path:
    config = load_config()
    schema_path = _write_schema()
    fixed_inputs = {
        "candidate_queue": Path(config["candidate_queue"]),
        "step1_lock_summary": Path(config["step1_lock_summary"]),
        "step2_candidates": Path(config["step2_candidates"]),
        "bert_training_all": Path(config["bert_training_all"]),
        "schema": schema_path,
        "prompt": ROOT / "config" / "prompt.txt",
        "code": Path(__file__),
    }
    directory = run_dir(run_id)
    freeze_release_inputs(
        run_dir=directory,
        release_id=run_id,
        fixed_inputs=fixed_inputs,
        density_ton_per_m3=float(config["density_ton_per_m3"]),
        maximum_total_attempts=int(config["maximum_total_attempts"]),
    )
    step2_candidates = pd.read_csv(config["step2_candidates"])
    step2_candidates = step2_candidates.loc[step2_candidates["year"].between(2016, 2024)].copy()
    bert_documents = set(pd.read_csv(config["bert_training_all"])["source_file_name"].dropna().astype(str))
    split = make_heldout_gold_split(
        records=step2_candidates,
        bert_document_names=bert_documents,
        minimum_candidates=gold_minimum,
        maximum_candidates=gold_maximum,
        target_candidates=gold_target,
        seed=seed,
    )
    split.to_csv(directory / "gold_split.csv", index=False, encoding="utf-8-sig")
    gold_queue = split.loc[split["split"] == "gold"].copy()
    gold_queue.to_csv(directory / "gold_candidates.csv", index=False, encoding="utf-8-sig")
    export_human_audit_workbook(
        gold_queue, directory / "gold_annotation_queue.xlsx"
    )
    return directory


def _candidate_prompt(candidate: dict, prompt: str, schema: dict, prior_errors: list[str]) -> str:
    return "\n".join(
        [
            prompt,
            "Canonical JSON Schema:",
            json.dumps(schema, ensure_ascii=False),
            "Candidate metadata and evidence:",
            json.dumps(candidate, ensure_ascii=False),
            "Prior deterministic errors (empty on first attempt):",
            json.dumps(prior_errors, ensure_ascii=False),
        ]
    )


def _call_deepseek(api_key: str, model: str, prompt: str) -> str:
    payload = {
        "model": model,
        "messages": [{"role": "user", "content": prompt}],
        "temperature": 0,
        "stream": False,
        "response_format": {"type": "json_object"},
        "max_tokens": 800,
    }
    request = urllib.request.Request(
        DEEPSEEK_URL,
        data=json.dumps(payload, ensure_ascii=False).encode("utf-8"),
        headers={"Content-Type": "application/json", "Authorization": f"Bearer {api_key}"},
        method="POST",
    )
    with urllib.request.urlopen(request, timeout=60) as response:
        body = json.loads(response.read().decode("utf-8"))
    return body["choices"][0]["message"]["content"]


def _candidate_from_row(row: pd.Series) -> dict:
    return {
        "field_id": str(row.get("field_id", "")),
        "city": str(row.get("city", "")),
        "year": int(row["year"]) if pd.notna(row.get("year")) else None,
        "rule_source_level": str(row.get("field_source_level", "")),
        "source_file_name": str(row.get("source_file_name", "")),
        "source_url": str(row.get("source_url", "")),
        "rule_raw_value": str(row.get("raw_value", "")),
        "rule_raw_unit": str(row.get("raw_unit", "")),
        "evidence_text": str(row.get("evidence_text", "")),
    }


def _attempt_rows(row: pd.Series, attempts: list[AttemptRecord], mode: str, model: str) -> list[dict]:
    records: list[dict] = []
    for attempt in attempts:
        response = attempt.response
        record = row.to_dict()
        record.update(
            {
                "mode": mode,
                "model": model,
                "attempt_number": attempt.attempt_number,
                "format_recovered": attempt.format_recovered,
                "raw_response": attempt.raw_content,
                "validation_error_codes": ";".join(attempt.error_codes),
                "decision": response.decision if response else "hold",
                "indicator_type": response.indicator_type if response else "uncertain",
                "llm_city": response.city if response else "",
                "llm_data_year": response.data_year if response else "",
                "llm_raw_value": response.raw_value if response else "",
                "llm_raw_unit": response.raw_unit if response else "",
                "llm_evidence_quote": response.evidence_quote if response else "",
                "llm_rationale": response.rationale if response else "",
                "llm_confidence": response.confidence if response else "",
                "source_level_confirmed": "",
                "evidence_complete": False,
                "final_decision": "",
            }
        )
        records.append(record)
    return records


def execute_model_run(
    directory: Path,
    model: str,
    api_key: str | None,
    limit: int,
    dry_run: bool,
    queue_path: Path | None = None,
    output_label: str | None = None,
) -> Path:
    assert_run_ready(directory)
    manifest = json.loads((directory / "manifest.json").read_text(encoding="utf-8"))
    queue = pd.read_csv(queue_path or (directory / "frozen_queue.csv"))
    if limit:
        queue = queue.head(limit).copy()
    prompt = (directory / "prompt.txt").read_text(encoding="utf-8")
    schema = json.loads((directory / "schema.json").read_text(encoding="utf-8"))
    all_records: list[dict] = []
    for _, row in queue.iterrows():
        candidate = _candidate_from_row(row)
        if dry_run:
            def local_stub(_candidate: dict, _prior: list[str]) -> str:
                return json.dumps(
                    {
                        "decision": "hold",
                        "indicator_type": "uncertain",
                        "city": None,
                        "data_year": None,
                        "raw_value": None,
                        "raw_unit": None,
                        "evidence_quote": None,
                        "rationale": "Local dry run only; no API call was made.",
                        "confidence": 0,
                    },
                    ensure_ascii=False,
                )
            attempts = run_with_bounded_retries(local_stub, candidate, int(manifest["maximum_total_attempts"]))
        else:
            if not api_key:
                raise SystemExit("DeepSeek API key is required for `run` and is never written to disk.")
            def api_call(item: dict, prior: list[str]) -> str:
                return _call_deepseek(api_key, model, _candidate_prompt(item, prompt, schema, prior))
            attempts = run_with_bounded_retries(api_call, candidate, int(manifest["maximum_total_attempts"]))
        all_records.extend(_attempt_rows(row, attempts, "dry_run" if dry_run else "api_run", model))

    label = output_label or ("dry_run" if dry_run else "api")
    attempts_path = directory / f"{label}_attempts.jsonl"
    with attempts_path.open("w", encoding="utf-8") as handle:
        for record in all_records:
            handle.write(json.dumps(record, ensure_ascii=False) + "\n")
    audit = pd.DataFrame(all_records)
    audit_path = directory / f"{label}_audit.csv"
    audit.to_csv(audit_path, index=False, encoding="utf-8-sig")
    workbook_name = "human_audit_workbook.xlsx" if label == "api" else f"{label}_audit.xlsx"
    export_human_audit_workbook(audit, directory / workbook_name)
    return audit_path


def export_audit_workbook(directory: Path, audit_csv: Path) -> Path:
    audit = pd.read_csv(audit_csv)
    output = directory / "human_audit_workbook.xlsx"
    export_human_audit_workbook(audit, output)
    return output


def reconcile(directory: Path, provisional_panel: Path) -> Path:
    config = load_config()
    authority = pd.read_excel(config["authoritative_panel"])
    provisional = pd.read_csv(provisional_panel)
    report = reconcile_panels(authority, provisional)
    for name in ["exact_matches", "value_differences", "authority_only", "provisional_only"]:
        report[name].to_csv(directory / f"reconciliation_{name}.csv", index=False, encoding="utf-8-sig")
    output = directory / "reconciliation_summary.json"
    output.write_text(json.dumps(report["summary"], ensure_ascii=False, indent=2), encoding="utf-8")
    return output


def main() -> None:
    parser = argparse.ArgumentParser(description="ICCBEI DeepSeek Part0 closure pipeline")
    subparsers = parser.add_subparsers(dest="command", required=True)
    prepare = subparsers.add_parser("prepare")
    prepare.add_argument("--run-id", default=load_config()["release_id"])
    prepare.add_argument("--gold-minimum", type=int, default=100)
    prepare.add_argument("--gold-maximum", type=int, default=150)
    prepare.add_argument("--gold-target", type=int, default=120)
    prepare.add_argument("--seed", type=int, default=20260715)
    dry = subparsers.add_parser("dry-run")
    dry.add_argument("--run-id", default=load_config()["release_id"])
    dry.add_argument("--limit", type=int, default=5)
    run = subparsers.add_parser("run")
    run.add_argument("--run-id", default=load_config()["release_id"])
    run.add_argument("--model", default=load_config()["default_model"])
    run.add_argument("--limit", type=int, default=0)
    run.add_argument("--api-key", default="")
    gold = subparsers.add_parser("run-gold")
    gold.add_argument("--run-id", default=load_config()["release_id"])
    gold.add_argument("--model", default=load_config()["default_model"])
    gold.add_argument("--api-key", default="")
    audit = subparsers.add_parser("audit-export")
    audit.add_argument("--run-id", default=load_config()["release_id"])
    audit.add_argument("--audit-csv", required=True)
    rec = subparsers.add_parser("reconcile")
    rec.add_argument("--run-id", default=load_config()["release_id"])
    rec.add_argument("--provisional-panel", required=True)
    args = parser.parse_args()

    if args.command == "prepare":
        print(prepare_release(args.run_id, args.gold_minimum, args.gold_maximum, args.gold_target, args.seed))
    elif args.command == "dry-run":
        print(execute_model_run(run_dir(args.run_id), "local_dry_run", None, args.limit, True))
    elif args.command == "run":
        key = args.api_key or os.environ.get("DEEPSEEK_API_KEY", "").strip() or getpass.getpass("Paste DeepSeek API key: ").strip()
        print(execute_model_run(run_dir(args.run_id), args.model, key, args.limit, False))
    elif args.command == "run-gold":
        key = args.api_key or os.environ.get("DEEPSEEK_API_KEY", "").strip() or getpass.getpass("Paste DeepSeek API key: ").strip()
        directory = run_dir(args.run_id)
        gold_queue = load_gold_queue(directory / "gold_split.csv")
        gold_queue.to_csv(directory / "gold_candidates.csv", index=False, encoding="utf-8-sig")
        print(execute_model_run(directory, args.model, key, 0, False, directory / "gold_candidates.csv", "gold_api"))
    elif args.command == "audit-export":
        print(export_audit_workbook(run_dir(args.run_id), Path(args.audit_csv)))
    elif args.command == "reconcile":
        print(reconcile(run_dir(args.run_id), Path(args.provisional_panel)))


if __name__ == "__main__":
    main()
