"""Matched S/D/DS Ridge diagnostic. Run in PyCharm or with python main.py."""
from pathlib import Path
from datetime import datetime, timezone
import argparse
import hashlib
import importlib.util
import json
import sys
import warnings
import numpy as np
import pandas as pd
import sklearn

ROOT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('historical_estimators', ROOT / 'original_code/estimators.py')
historical = importlib.util.module_from_spec(spec)
spec.loader.exec_module(historical)
PROFILES = {
    'S_structural': ['L2_ntl', 'L2_urban_rate', 'L2_fai', 'L2_disp_income'],
    'D_dynamic': ['L1_outcome'],
    'DS_combined': ['L1_outcome', 'L2_ntl', 'L2_urban_rate', 'L2_fai', 'L2_disp_income'],
}
YEARS = [2021, 2022, 2023]


def read(name):
    return pd.read_csv(ROOT / 'data' / name, float_precision='round_trip')


def dump(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False, default=str) + '\n')


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def scores(actual, prediction):
    result = historical.metrics(actual, prediction)
    error = np.exp(np.asarray(prediction) - np.asarray(actual)) - 1
    result.update(mape=float(np.mean(np.abs(error))), median_ape=float(np.median(np.abs(error))))
    return result


def split(panel, year):
    train = panel[panel.year.between(2016, year - 1)].copy()
    evaluation = panel[panel.year.eq(year) & panel.GBA_dummy.eq(1)].copy()
    assert train.year.max() < evaluation.year.min()
    assert not set(zip(train.district_name, train.year)) & set(zip(evaluation.district_name, evaluation.year))
    return train, evaluation


def summary(folds):
    frame = pd.DataFrame(folds)
    out = frame.groupby(['profile', 'candidate_id', 'params_json'], as_index=False).agg(
        folds=('validation_year', 'nunique'), mean_rmse=('rmse', 'mean'),
        sd_rmse=('rmse', lambda x: x.std(ddof=0)), mean_mae=('mae', 'mean'), mean_r2=('r2', 'mean'))
    assert out.folds.eq(3).all()
    out['objective'] = out.mean_rmse + .15 * out.sd_rmse
    return out.sort_values(['objective', 'mean_mae', 'candidate_id']).reset_index(drop=True)


def spec_from_row(row):
    return dict(candidate_id=int(row.candidate_id), algorithm='Ridge', params=json.loads(row.params_json), params_json=row.params_json)


def prediction_rows(profile, candidate, frame, predictions, phase):
    out = frame[['district_name', 'year', 'C_DW_generation_m3', 'ln_cdw_m3']].copy()
    out.insert(0, 'profile', profile)
    out['candidate_id'] = candidate['candidate_id']
    out['phase'] = phase
    out['prediction_ln'] = predictions
    out['prediction_m3'] = np.exp(predictions)
    out['residual_ln'] = out.ln_cdw_m3 - predictions
    out['squared_log_error'] = out.residual_ln ** 2
    out['absolute_log_error'] = out.residual_ln.abs()
    out['relative_error'] = np.exp(predictions - out.ln_cdw_m3) - 1
    return out


def paired(predictions):
    dynamic = predictions[predictions.profile.eq('D_dynamic')].set_index(['district_name', 'year'])
    combined = predictions[predictions.profile.eq('DS_combined')].set_index(['district_name', 'year'])
    assert dynamic.index.equals(combined.index)
    out = dynamic[['ln_cdw_m3']].copy()
    out['dynamic_abs_log_error'] = dynamic.absolute_log_error
    out['combined_abs_log_error'] = combined.absolute_log_error
    out['dynamic_squared_log_error'] = dynamic.squared_log_error
    out['combined_squared_log_error'] = combined.squared_log_error
    out['squared_error_reduction_with_structure'] = dynamic.squared_log_error - combined.squared_log_error
    out['absolute_error_reduction_with_structure'] = dynamic.absolute_log_error - combined.absolute_log_error
    out['structure_reduced_error'] = out.squared_error_reduction_with_structure > 0
    return out.reset_index()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, help='New output directory, relative to this package or absolute.')
    args = parser.parse_args()
    output = args.output or Path('runs') / datetime.now().strftime('%Y%m%d_%H%M%S_%f')
    if not output.is_absolute():
        output = ROOT / output
    output.mkdir(parents=True, exist_ok=True)
    if any(output.iterdir()):
        raise FileExistsError('Output must be empty. Existing results are never overwritten.')
    for row in pd.read_csv(ROOT / 'input_lineage.csv').itertuples():
        assert digest(ROOT / row.package_path) == row.sha256, row.package_path
    static = [ROOT / 'main.py', ROOT / 'protocol.json', ROOT / 'input_lineage.csv']
    static += list((ROOT / 'data').glob('*.csv')) + list((ROOT / 'original_code').glob('*.py'))
    hashes = {str(p.relative_to(ROOT)): digest(p) for p in sorted(static)}
    dump(output / 'run_configuration.json', dict(started_utc=datetime.now(timezone.utc).isoformat(),
        protocol=json.loads((ROOT / 'protocol.json').read_text()), static_sha256=hashes,
        versions=dict(python=sys.version, numpy=np.__version__, pandas=pd.__version__, sklearn=sklearn.__version__)))

    raw = read('model_panel.csv')
    assert len(raw) == 131 and not raw.duplicated(['district_name', 'year']).any()
    panel = raw.dropna(subset=['ln_cdw_m3', *PROFILES['DS_combined']]).copy()
    assert len(panel) == 112
    np.testing.assert_allclose(panel.ln_cdw_m3, np.log(panel.C_DW_generation_m3), atol=1e-12, rtol=0)
    panel.to_csv(output / 'common_complete_case_panel.csv', index=False)
    cohorts = []
    for year, nt, nv in [(2021,42,8),(2022,61,9),(2023,82,9),(2024,103,9)]:
        train, evaluation = split(panel, year)
        assert (len(train), len(evaluation)) == (nt, nv)
        for label, rows in [('train', train), ('evaluate', evaluation)]:
            cohorts.extend(dict(origin=year, role=label, district_name=r.district_name, year=int(r.year)) for r in rows.itertuples())
    pd.DataFrame(cohorts).to_csv(output / 'sample_membership.csv', index=False)

    fits, notes, fit_count = [], [], 0
    def fit_once(profile, candidate, train, evaluation, phase):
        nonlocal fit_count
        features = PROFILES[profile]
        assert train[features].notna().all().all()
        if profile == 'S_structural':
            assert candidate['params']['dynamic_weight'] == 1
        fitted = historical.estimator(candidate, len(features))
        fit_count += 1
        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter('always')
            try:
                fitted.fit(train[features], train.ln_cdw_m3)
                prediction = fitted.predict(evaluation[features])
                if not np.isfinite(prediction).all():
                    raise ValueError('Non-finite predictions')
            except Exception as exc:
                dump(output / 'failure.json', dict(profile=profile, candidate=candidate, phase=phase,
                     error_type=type(exc).__name__, message=str(exc), fit_count=fit_count))
                raise
        fits.append(dict(profile=profile, candidate_id=candidate['candidate_id'], phase=phase,
            n_train=len(train), n_evaluate=len(evaluation), max_training_year=int(train.year.max()),
            evaluation_year=int(evaluation.year.iloc[0])))
        notes.extend(dict(profile=profile, candidate_id=candidate['candidate_id'], phase=phase,
                     category=w.category.__name__, message=str(w.message)) for w in caught)
        return fitted, prediction

    # S-only has no dynamic state. Use six unique alphas, with unit weights.
    structural_specs = [s for s in historical.candidate_specs()
                        if s['algorithm'] == 'Ridge' and s['params']['dynamic_weight'] == 1]
    assert len(structural_specs) == 6
    s_folds, cache = [], {}
    for candidate in structural_specs:
        for year in YEARS:
            train, evaluation = split(panel, year)
            _, prediction = fit_once('S_structural', candidate, train, evaluation, 'inner_search')
            cache[candidate['candidate_id'], year] = prediction
            s_folds.append(dict(profile='S_structural', candidate_id=candidate['candidate_id'],
                params_json=candidate['params_json'], validation_year=year, n_train=len(train),
                n_validation=len(evaluation), **historical.metrics(evaluation.ln_cdw_m3, prediction)))
    s_summary = summary(s_folds)
    s_summary.to_csv(output / 'structural_candidate_summary.csv', index=False)
    pd.DataFrame(s_folds).to_csv(output / 'structural_all_inner_folds.csv', index=False)

    dynamic = read('archived_dynamic_candidates.csv').query("profile == 'A_dynamic'").copy()
    combined = read('archived_combined_candidates.csv').query("algorithm == 'Ridge'").copy()
    combined = combined.rename(columns={'mean_inner_rmse':'mean_rmse','std_inner_rmse':'sd_rmse',
        'mean_inner_mae':'mean_mae','mean_inner_r2':'mean_r2'})
    historical_specs = {s['candidate_id']:s for s in historical.candidate_specs() if s['algorithm']=='Ridge'}
    for frame in [dynamic, combined]:
        assert len(frame) == 30 and set(frame.candidate_id) == set(historical_specs)
        assert frame.folds.eq(3).all()
        for row in frame.itertuples():
            assert json.loads(row.params_json) == historical_specs[row.candidate_id]['params']
        np.testing.assert_allclose(frame.objective, frame.mean_rmse + .15*frame.sd_rmse, atol=1e-12, rtol=0)
    winners = {
        'S_structural': s_summary.iloc[0],
        'D_dynamic': dynamic.sort_values(['objective','mean_mae','candidate_id']).iloc[0],
        'DS_combined': combined.sort_values(['objective','mean_mae','candidate_id']).iloc[0],
    }
    chosen = {name: spec_from_row(row) for name,row in winners.items()}
    assert chosen['D_dynamic']['candidate_id'] == chosen['DS_combined']['candidate_id'] == 23
    # Save every parameter choice before any 2024 model fit or scoring.
    dump(output / 'selection_before_2024_evaluation.json', dict(saved_utc=datetime.now(timezone.utc).isoformat(),
        selected_specs=chosen, selection_years=YEARS, chosen_using_2024=False,
        archived_D_DS_grids_reused=True, this_is_post_review_historically_informed=True))
    tuning = []
    for profile,row in winners.items():
        tuning.append(dict(profile=profile, candidate_id=int(row.candidate_id),params_json=row.params_json,
            mean_log_rmse=float(row.mean_rmse),sd_log_rmse=float(row.sd_rmse),mean_log_mae=float(row.mean_mae),
            mean_log_r2=float(row.mean_r2),objective=float(row.objective),
            unique_grid_settings=6 if profile=='S_structural' else 30,
            grid_source='new_structural_search' if profile=='S_structural' else 'reused_archived_grid'))
    pd.DataFrame(tuning).to_csv(output / 'selected_tuning_comparison.csv', index=False)
    print('Selected specifications saved before 2024 evaluation:',json.dumps(chosen),flush=True)

    inner_predictions, selected_folds = [], []
    for profile,candidate in chosen.items():
        for year in YEARS:
            train,evaluation=split(panel,year)
            if profile == 'S_structural':
                prediction=cache[candidate['candidate_id'],year]
            else:
                _,prediction=fit_once(profile,candidate,train,evaluation,'selected_inner_replay')
                old=read('archived_dynamic_folds.csv') if profile=='D_dynamic' else read('archived_combined_folds.csv')
                if profile=='D_dynamic':
                    old=old[old.profile.eq('A_dynamic')]
                expected=old[old.candidate_id.eq(candidate['candidate_id']) & old.validation_year.eq(year)].iloc[0]
                np.testing.assert_allclose([historical.metrics(evaluation.ln_cdw_m3,prediction)[m] for m in ['r2','rmse','mae']],
                    [expected[m] for m in ['r2','rmse','mae']],atol=1e-10,rtol=0)
            selected_folds.append(dict(profile=profile,year=year,n_train=len(train),n_evaluate=len(evaluation),
                **scores(evaluation.ln_cdw_m3,prediction)))
            inner_predictions.append(prediction_rows(profile,candidate,evaluation,prediction,'inner_tuning'))
    pd.DataFrame(selected_folds).to_csv(output / 'selected_inner_fold_metrics.csv',index=False)
    inner=pd.concat(inner_predictions,ignore_index=True)
    inner.to_csv(output / 'selected_inner_predictions.csv',index=False)
    paired(inner).to_csv(output / 'paired_inner_error_changes.csv',index=False)

    target_metrics, target_predictions, pipelines = [], [], {}
    train,target=split(panel,2024)
    for profile,candidate in chosen.items():
        fitted,prediction=fit_once(profile,candidate,train,target,'final_target')
        target_metrics.append(dict(profile=profile,candidate_id=candidate['candidate_id'],
            alpha=candidate['params']['alpha'],dynamic_weight=candidate['params']['dynamic_weight'] if profile!='S_structural' else None,
            n_train=len(train),n_evaluate=len(target),**scores(target.ln_cdw_m3,prediction)))
        target_predictions.append(prediction_rows(profile,candidate,target,prediction,'target_2024'))
        pipe=fitted.named_steps
        pipelines[profile]=dict(features=PROFILES[profile],alpha=candidate['params']['alpha'],
            medians=pipe['imputer'].statistics_.tolist(),means=pipe['scale'].mean_.tolist(),scales=pipe['scale'].scale_.tolist(),
            weights=pipe['weight'].weights,coefficients=pipe['model'].coef_.tolist(),intercept=float(pipe['model'].intercept_))
        if profile!='S_structural':
            old=read('archived_dynamic_2024.csv') if profile=='D_dynamic' else read('archived_combined_2024.csv')
            expected=old.set_index(['district_name','year']).loc[list(zip(target.district_name,target.year))]
            np.testing.assert_allclose(prediction,expected.pred_ln_cdw_m3,atol=1e-10,rtol=0)
    targets=pd.DataFrame(target_metrics)
    targets.to_csv(output / 'comparison_2024.csv',index=False)
    target_predictions=pd.concat(target_predictions,ignore_index=True)
    target_predictions.to_csv(output / 'predictions_2024.csv',index=False)
    changes=paired(target_predictions)
    changes.to_csv(output / 'paired_2024_error_changes.csv',index=False)
    yearly=paired(inner).groupby('year',as_index=False).agg(n=('district_name','size'),
        mean_squared_error_reduction=('squared_error_reduction_with_structure','mean'),
        cities_with_reduced_error=('structure_reduced_error','sum'))
    pd.concat([yearly,pd.DataFrame([dict(year=2024,n=9,
        mean_squared_error_reduction=changes.squared_error_reduction_with_structure.mean(),
        cities_with_reduced_error=int(changes.structure_reduced_error.sum()))])],ignore_index=True).to_csv(output / 'paired_by_year.csv',index=False)
    dump(output / 'final_preprocessing.json',pipelines)
    pd.DataFrame(fits).to_csv(output / 'fit_log.csv',index=False)
    pd.DataFrame(notes,columns=['profile','candidate_id','phase','category','message']).to_csv(output / 'fit_warnings.csv',index=False)
    assert fit_count==27
    assert all(digest(ROOT/name)==value for name,value in hashes.items())
    combined_result=targets[targets.profile.eq('DS_combined')].iloc[0]
    np.testing.assert_allclose([combined_result.r2,combined_result.rmse,combined_result.mae],
        [.9237854554663211,.2903509815876514,.2439864821763559],atol=1e-10,rtol=0)
    dump(output / 'receipt.json',dict(status='completed',successful_model_fits=fit_count,failed_model_fits=0,
        fit_warning_count=len(notes),S_search_fits=18,selected_D_DS_inner_replay_fits=6,final_fits=3,
        archived_D_and_DS_grids_reused=True,archived_D_and_DS_predictions_reproduced=True,
        common_target_city_years=9,common_inner_city_years=26,
        cities_with_reduced_2024_error=int(changes.structure_reduced_error.sum()),
        mean_2024_squared_error_reduction=float(changes.squared_error_reduction_with_structure.mean()),
        original_primary_model_unchanged=True,input_files_unchanged=True,
        no_target_based_selection=True,not_a_new_blind_test=True,no_llm_calls=True))
    print(targets.to_string(index=False),flush=True)
    print('Completed27 small Ridge fits; archived references and inputs unchanged.',flush=True)


if __name__=='__main__':
    main()
