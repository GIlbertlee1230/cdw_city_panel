# Matched Ridge predictor comparison

Compare structural-only, dynamic-only and combined inputs on the same cohort using the original Ridge tuning rule. This supplies Part A of the manuscript comparison.

## Contents

- `data/`
- `input_lineage.csv`
- `main.py`
- `original_code/`
- `protocol.json`
- `requirements.txt`
- `results/`

## Execution

Run from the project root in a separate Python process:

```bash
python analyses/ridge_ablation/main.py --output outputs/ridge_ablation
```

This fitting command uses the distributed inputs and the recorded analysis protocol. Generated runs are separate from the archived results; this analysis does not replace the primary selected model.

## Interpretation

Definitions and analysis-specific limitations are in `docs/supplementary_information.md` at the project root. Scientific input files, labels and frozen results are preserved. The directory name describes the analysis rather than a review stage or internal experiment number.
