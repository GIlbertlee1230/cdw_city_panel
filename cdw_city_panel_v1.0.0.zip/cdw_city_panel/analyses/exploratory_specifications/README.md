# Exploratory specification records

Retain the archived group-penalty and temporal residual-correction protocols and outputs. These were not adopted as the primary forecast.

## Contents

- `group_penalty/`
- `temporal_residual_correction/`

## Interpretation

Definitions and analysis-specific limitations are in `docs/supplementary_information.md` at the project root. Scientific input files, labels and frozen results are preserved. The directory name describes the analysis rather than a review stage or internal experiment number.
