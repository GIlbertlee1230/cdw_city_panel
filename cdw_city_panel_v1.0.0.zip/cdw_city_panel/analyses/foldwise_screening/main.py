"""PyCharm: Run this file for the complete 3-profile, 30-setting Ridge comparison."""
from src.experiment import main
if __name__=='__main__': main()
