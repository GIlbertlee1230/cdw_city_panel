"""Post-review A/B/C Ridge comparison on identical temporal cohorts."""
import argparse
import hashlib
import json
import platform
import sys
import warnings
from datetime import datetime, timezone
from pathlib import Path
import numpy as np
import pandas as pd
import scipy
import sklearn
from .screening import build_panel, select_features, VARIABLES, BASELINE_FEATURES
from .estimators import candidate_specs, estimator, metrics

ROOT=Path(__file__).resolve().parents[1]
PROFILES=['A_dynamic','B_filtered','C_wide']
YEARS=[2021,2022,2023]


def write_json(path,value):
    Path(path).write_text(json.dumps(value,indent=2,allow_nan=False,default=str)+'\n',encoding='utf8')


def ridge_specs():
    return [s for s in candidate_specs() if s['algorithm']=='Ridge']


def choose_from_diagnostics(table,profile):
    if profile=='A_dynamic': return []
    keep=table.eligible & table.coverage_pass
    if profile=='B_filtered': keep=keep & table.pearson_pass & table.low_vif_subset
    elif profile!='C_wide': raise ValueError(profile)
    return table.loc[keep,'feature'].tolist()


def select_predictors(panel,cutoff,profile,diagnostics=None):
    _,table,_=select_features(panel,cutoff) if diagnostics is None else diagnostics
    table=table.copy().rename(columns={'selected':'strict_old_rule_selected','decision_reason':'strict_old_rule_reason'})
    initial=choose_from_diagnostics(table,profile)
    # Availability/screening diagnostics never inspect the validation year.
    train=panel[panel.year.between(2016,cutoff)].dropna(subset=['ln_cdw_m3','L1_outcome'])
    train_unique={r.feature:int(train[r.feature].nunique(dropna=True)) for r in table.itertuples()}
    table['training_unique_values']=table.feature.map(train_unique)
    table['removed_constant_or_empty']=table.feature.isin(initial) & table.training_unique_values.lt(2)
    structural=[f for f in initial if train_unique[f]>=2]
    table['profile']=profile
    table['selected']=table.feature.isin(structural)
    table['residual_significance_is_gate']=False
    table['selection_reason']=table.apply(lambda r:'selected' if r.selected else
        'dynamic_only_profile' if profile=='A_dynamic' else
        'excluded_control' if not r.eligible else 'coverage_failed' if not r.coverage_pass else
        'constant_or_empty_training_column' if r.removed_constant_or_empty else
        'pooled_pearson_failed' if profile=='B_filtered' and not r.pearson_pass else 'removed_by_vif',axis=1)
    if profile=='B_filtered' and not table.vif_estimable.all():
        raise ValueError(f'VIF not estimable for cutoff {cutoff}; cannot silently use an unverified subset')
    return ['L1_outcome']+structural,table


def prepare_folds(panel,output=None,years=None):
    folds={};design=[]
    for year in YEARS if years is None else years:
        cutoff=year-1
        train=panel[panel.year.between(2016,cutoff)].dropna(subset=['ln_cdw_m3','L1_outcome']).copy()
        valid=panel[(panel.year==year)&panel.GBA_dummy.eq(1)].dropna(subset=['ln_cdw_m3','L1_outcome']).copy()
        if len(train)<12 or len(valid)<8: raise ValueError(f'Insufficient common cohort: {year}')
        diagnostics=select_features(panel,cutoff)
        profiles={}
        directory=None
        if output is not None:
            directory=Path(output)/f'fold_{year}';directory.mkdir()
            train.to_csv(directory/'common_training_panel.csv',index=False)
            valid.to_csv(directory/'common_evaluation_panel.csv',index=False)
            diagnostics[2].to_csv(directory/'vif_removals.csv',index=False)
        for profile in PROFILES:
            features,table=select_predictors(panel,cutoff,profile,diagnostics)
            profiles[profile]=(train,valid,features)
            design.append(dict(validation_year=year,profile=profile,screen_start=2018,screen_end=cutoff,
                fit_start=2016,fit_end=cutoff,n_train=len(train),n_validation=len(valid),
                structural_count=len(features)-1,features='|'.join(features),
                missing_train_cells=int(train[features].isna().sum().sum()),
                missing_validation_cells=int(valid[features].isna().sum().sum())))
            if directory is not None:
                table.to_csv(directory/f'{profile}_screening.csv',index=False)
                write_json(directory/f'{profile}_features.json',features)
        folds[year]=profiles
    if output is not None:
        path=Path(output)/'fold_design.csv';frame=pd.DataFrame(design)
        if path.exists(): frame=pd.concat([pd.read_csv(path),frame],ignore_index=True)
        frame.to_csv(path,index=False)
    return folds


def fit_predict(spec,train,valid,features):
    if train[features].isna().all().any(): raise ValueError('All-empty training feature')
    fitted=estimator(spec,len(features))
    fitted.fit(train[features],train.ln_cdw_m3)
    pred=np.asarray(fitted.predict(valid[features]),dtype=float)
    if not np.isfinite(pred).all(): raise ValueError('Non-finite predictions')
    return fitted,pred


def run_selection(folds,output,quiet=False):
    output=Path(output);output.mkdir(exist_ok=True,parents=True)
    rows=[];predictions=[];errors=[];notes=[]
    for profile in PROFILES:
        for spec in ridge_specs():
            for year in YEARS:
                train,valid,features=folds[year][profile]
                with warnings.catch_warnings(record=True) as caught:
                    warnings.simplefilter('always')
                    try:
                        _,pr=fit_predict(spec,train,valid,features)
                        rows.append(dict(profile=profile,candidate_id=spec['candidate_id'],params_json=spec['params_json'],
                            validation_year=year,n_train=len(train),n_validation=len(valid),
                            features='|'.join(features),**metrics(valid.ln_cdw_m3,pr)))
                        for city,actual,pred in zip(valid.district_name,valid.ln_cdw_m3,pr):
                            predictions.append(dict(profile=profile,candidate_id=spec['candidate_id'],year=year,
                                district_name=city,actual_ln=actual,prediction_ln=pred,residual_ln=actual-pred))
                    except Exception as exc:
                        errors.append(dict(profile=profile,candidate_id=spec['candidate_id'],year=year,
                            error_type=type(exc).__name__,message=str(exc)))
                    notes.extend(dict(profile=profile,candidate_id=spec['candidate_id'],year=year,
                        category=w.category.__name__,message=str(w.message)) for w in caught)
        if not quiet: print(f'{profile}: 30 configurations x 3 years evaluated',flush=True)
    pd.DataFrame(errors,columns=['profile','candidate_id','year','error_type','message']).to_csv(output/'failed_candidates.csv',index=False)
    pd.DataFrame(notes,columns=['profile','candidate_id','year','category','message']).drop_duplicates().to_csv(output/'fit_warnings.csv',index=False)
    pd.DataFrame(predictions).to_csv(output/'all_inner_predictions.csv',index=False)
    frame=pd.DataFrame(rows);frame.to_csv(output/'inner_fold_results.csv',index=False)
    summary=frame.groupby(['profile','candidate_id','params_json'],as_index=False).agg(
        folds=('validation_year','nunique'),mean_rmse=('rmse','mean'),sd_rmse=('rmse',lambda s:s.std(ddof=0)),
        mean_mae=('mae','mean'),mean_r2=('r2','mean'))
    summary=summary[summary.folds.eq(3)].copy()
    summary['objective']=summary.mean_rmse+.15*summary.sd_rmse
    summary['profile_order']=summary.profile.map({p:i for i,p in enumerate(PROFILES)})
    summary=summary.sort_values(['objective','mean_mae','profile_order','candidate_id']).reset_index(drop=True)
    if set(summary.profile)!=set(PROFILES): raise RuntimeError('A profile has no complete three-fold candidate')
    winners=summary.drop_duplicates('profile').copy()
    selection=dict(selected_profile=str(summary.iloc[0].profile),selected_candidate_id=int(summary.iloc[0].candidate_id),
        within_profile_candidate_ids={r.profile:int(r.candidate_id) for r in winners.itertuples()},
        selected_using='2021/2022/2023 validation only; 2024 excluded')
    summary.to_csv(output/'candidate_summary.csv',index=False)
    winners.to_csv(output/'profile_winners.csv',index=False)
    write_json(output/'selection_before_2024.json',{**selection,'saved_utc':datetime.now(timezone.utc).isoformat()})
    return summary,selection


def evaluate_one(profile,spec,train,test,features,output):
    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter('always');fitted,pred=fit_predict(spec,train,test,features)
    out=test[['district_name','year','C_DW_generation_m3','ln_cdw_m3']+features].copy()
    out['pred_ln_cdw_m3']=pred;out['pred_cdw_m3']=np.exp(pred)
    out['residual_ln']=out.ln_cdw_m3-out.pred_ln_cdw_m3
    out['signed_relative_error']=out.pred_cdw_m3/out.C_DW_generation_m3-1
    out.to_csv(output/f'{profile}_2024_predictions.csv',index=False)
    pipe=fitted.named_steps
    audit=dict(profile=profile,spec=spec,features=features,n_train=len(train),train_start=2016,train_end=2023,
        training_medians=pipe['imputer'].statistics_.tolist(),scaler_mean=pipe['scale'].mean_.tolist(),
        scaler_scale=pipe['scale'].scale_.tolist(),weights=pipe['weight'].weights,
        coefficients_after_preprocessing=pipe['model'].coef_.tolist(),intercept=float(pipe['model'].intercept_),
        warnings=[dict(category=w.category.__name__,message=str(w.message)) for w in caught])
    write_json(output/f'{profile}_fitted_preprocessing.json',audit)
    return dict(profile=profile,candidate_id=spec['candidate_id'],params_json=spec['params_json'],
        n_train=len(train),n_test=len(test),structural_count=len(features)-1,features='|'.join(features),
        **metrics(test.ln_cdw_m3,pred))


def evaluate_selected(panel,selection,output):
    final=prepare_folds(panel,output,years=[2024])[2024]
    specs={s['candidate_id']:s for s in ridge_specs()};rows=[]
    for profile in PROFILES:
        train,test,features=final[profile]
        if len(test)!=9: raise ValueError('Expected GBA9 evaluation')
        row=evaluate_one(profile,specs[selection['within_profile_candidate_ids'][profile]],train,test,features,output)
        row['selected_by_validation']=profile==selection['selected_profile'];row['eligible_for_selection']=True
        rows.append(row)
    train,test,_=final['A_dynamic']
    # Historical set is a comparator only, excluded from profile/hyperparameter choice.
    baseline=evaluate_one('D_historical_four_reference',specs[23],train,test,BASELINE_FEATURES,output)
    np.testing.assert_allclose([baseline[k] for k in ['r2','rmse','mae']],
        [.9237854554663211,.2903509815876514,.2439864821763559],rtol=1e-8,atol=1e-10)
    baseline['selected_by_validation']=False;baseline['eligible_for_selection']=False;rows.append(baseline)
    result=pd.DataFrame(rows);result.to_csv(output/'comparison_2024.csv',index=False)
    # Show changes relative to A for every validation origin, using paired evaluation rows.
    inner=pd.read_csv(output/'inner_fold_results.csv');chosen=[]
    for profile in PROFILES:
        subset=inner[inner.profile.eq(profile)&inner.candidate_id.eq(selection['within_profile_candidate_ids'][profile])].copy()
        chosen.append(subset)
    chosen=pd.concat(chosen);base=chosen[chosen.profile.eq('A_dynamic')].set_index('validation_year').rmse
    chosen['rmse_difference_from_A']=chosen.rmse-chosen.validation_year.map(base)
    chosen.to_csv(output/'selected_validation_comparison.csv',index=False)
    inner_design=prepare_folds(panel);counts=[]
    for profile in PROFILES:
        for _,_,feature,_,eligible in VARIABLES:
            counts.append(dict(profile=profile,feature=feature,eligible=eligible,
                inner_folds_selected=sum(feature in folds[profile][2] for year,folds in
                    inner_design.items()),selected_final=feature in final[profile][2]))
    pd.DataFrame(counts).to_csv(output/'feature_stability.csv',index=False)
    return result


def file_hashes():
    paths=[ROOT/'protocol.json',ROOT/'main.py']
    for folder in ['src','data/inputs','data/original_workbooks','metadata']:
        paths.extend(p for p in (ROOT/folder).glob('*') if p.is_file() and p.name!='file_manifest.csv')
    return {str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(paths)}


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path,help='New/empty path relative to package; default timestamped runs directory')
    parser.add_argument('--select-only',action='store_true',help='Export selection results without 2024 evaluation')
    args=parser.parse_args()
    output=args.output or Path('runs')/datetime.now().strftime('%Y%m%d_%H%M%S_%f')
    if not output.is_absolute(): output=ROOT/output
    output.mkdir(parents=True,exist_ok=True)
    if any(output.iterdir()): raise FileExistsError(f'Output must be empty: {output}')
    write_json(output/'run_configuration.json',dict(protocol=json.loads((ROOT/'protocol.json').read_text()),
        input_and_code_sha256=file_hashes(),versions=dict(python=sys.version,numpy=np.__version__,
            pandas=pd.__version__,scipy=scipy.__version__,sklearn=sklearn.__version__,platform=platform.platform()),
        started_utc=datetime.now(timezone.utc).isoformat(),expected_inner_fits=270))
    panel=build_panel(ROOT);panel.to_csv(output/'derived_panel.csv',index=False)
    pd.DataFrame(VARIABLES,columns=['source_column','part1_name','feature','transform','eligible']).to_csv(output/'variable_dictionary.csv',index=False)
    folds=prepare_folds(panel,output)
    _,selection=run_selection(folds,output)
    print('Frozen selection:',json.dumps(selection),flush=True)
    if args.select_only: return
    result=evaluate_selected(panel,selection,output)
    print(result[['profile','params_json','structural_count','r2','rmse','mae','selected_by_validation']].to_string(index=False),flush=True)
    write_json(output/'completion.json',dict(status='complete',successful_inner_fits=len(pd.read_csv(output/'inner_fold_results.csv')),
        failed_inner_fits=len(pd.read_csv(output/'failed_candidates.csv')),selection=selection,
        historical_baseline_reproduced=True,final_metrics_used_for_selection=False))
    print('Complete:',output,flush=True)
