"""Historical Part1 rules, applied only to outcomes in each training window."""
from pathlib import Path
import warnings
import numpy as np
import pandas as pd
from scipy.stats import pearsonr

# Source English export, historical Part1 name, revised model name, transform, eligible.
VARIABLES = [
 ('construction_output_100m_rmb','ln_conout','L2_conout','log',True),
 ('construction_area_10k_m2','ln_conarea','L2_conarea','log',True),
 ('urbanization_rate','urban_rate_raw','L2_urban_rate','level',True),
 ('resident_population_10k','ln_pop_10k','L2_population','log',True),
 ('fixed_asset_investment_10k_rmb','ln_fai','L2_fai','log',True),
 ('real_estate_investment_million_rmb','ln_house_invest','L2_house_invest','log',True),
 ('gdp_10k_rmb','ln_gdp','L2_gdp','log',True),
 ('land_area_km2','ln_land_area','L2_land_area','log',False),
 ('tertiary_value_added_10k_rmb','ln_tertiary_value','L2_tertiary_value','log',True),
 ('ntl_mean_dn','ln_ntl','L2_ntl','log',True),
 ('new_construction_area_10k_m2','ln_new_start','L2_new_start','log',True),
 ('construction_profit_100m_rmb','ln_con_profit','L2_con_profit','log',True),
 ('disposable_income_rmb','ln_disp_income','L2_disp_income','log',True),
 ('consumption_expenditure_rmb','ln_consumption','L2_consumption','log',True),
 ('energy_intensity_growth','energy_growth_raw','L2_energy_growth','level',True),
 ('tertiary_share','ln_tertiary_share','L2_tertiary_share','log',True),
 ('construction_value_added_100m_rmb','ln_construction_va','L2_construction_va','log',True),
 ('real_estate_value_added_100m_rmb','ln_realestate_va','L2_realestate_va','log',True),
 ('annual_house_price_rmb_m2','ln_price','L2_price','log',True),
]
BASELINE_FEATURES=['L1_outcome','L2_ntl','L2_urban_rate','L2_fai','L2_disp_income']


def safe_log(series):
    values=pd.to_numeric(series,errors='coerce')
    return np.log(values.where(values>0))


def build_panel(root):
    root=Path(root)
    y=pd.read_csv(root/'data/inputs/outcomes.csv')
    x=pd.read_csv(root/'data/inputs/covariates.csv')
    cities=pd.read_csv(root/'metadata/city_dictionary.csv').rename(columns={'city':'district_name','is_gba':'GBA_dummy'})
    for df in [x,y]:
        if df.duplicated(['district_name','year']).any():
            raise ValueError('Duplicate city-year input')
    panel=y[y.year.between(2016,2024)].copy()
    panel['ln_cdw_m3']=safe_log(panel.C_DW_generation_m3)
    lag_y=y[['district_name','year','C_DW_generation_m3']].copy()
    lag_y['year']+=1
    lag_y['L1_outcome']=safe_log(lag_y.pop('C_DW_generation_m3'))
    panel=panel.merge(lag_y,on=['district_name','year'],how='left',validate='one_to_one')
    lag_x=x[['district_name','year']+[r[0] for r in VARIABLES]].copy()
    lag_x['year']+=2
    for source,_,feature,transform,_ in VARIABLES:
        lag_x[feature]=safe_log(lag_x[source]) if transform=='log' else pd.to_numeric(lag_x[source],errors='coerce')
    lag_x=lag_x.drop(columns=[r[0] for r in VARIABLES])
    panel=panel.merge(lag_x,on=['district_name','year'],how='left',validate='one_to_one')
    panel=panel.merge(cities,on='district_name',how='left',validate='many_to_one')
    if panel.city_id.isna().any(): raise ValueError('Unmapped city')
    return panel.sort_values(['city_id','year']).reset_index(drop=True)


def corr_with_p(y,x):
    pair=pd.concat([y,x],axis=1).dropna()
    if len(pair)<3 or pair.iloc[:,0].nunique()<2 or pair.iloc[:,1].nunique()<2:
        return np.nan,np.nan,len(pair)
    with warnings.catch_warnings():
        warnings.simplefilter('ignore')
        r=pearsonr(pair.iloc[:,0],pair.iloc[:,1])
    return float(r.statistic),float(r.pvalue),len(pair)


def calculate_vif(frame,variables):
    complete=frame[variables].dropna().astype(float)
    if len(complete)<=len(variables)+1 or len(variables)<2: return {},len(complete)
    scores={}
    for variable in variables:
        y=complete[variable].to_numpy()
        others=[v for v in variables if v!=variable]
        x=np.column_stack([np.ones(len(y)),complete[others].to_numpy()])
        beta,*_=np.linalg.lstsq(x,y,rcond=None)
        ss_res=float(np.sum((y-x@beta)**2));ss_tot=float(np.sum((y-y.mean())**2))
        r2=1-ss_res/ss_tot if ss_tot>0 else 1.0
        scores[variable]=float(1/(1-r2)) if r2<1 else np.inf
    return scores,len(complete)


def select_features(panel,cutoff):
    """No validation outcomes or validation predictors can influence this function."""
    frame=panel[panel.year.between(2018,cutoff)].copy()
    residual=pd.Series(np.nan,index=frame.index,dtype=float)
    pairs=frame[['ln_cdw_m3','L1_outcome']].dropna()
    if len(pairs)>=5:
        x=np.column_stack([np.ones(len(pairs)),pairs.L1_outcome.to_numpy()])
        beta,*_=np.linalg.lstsq(x,pairs.ln_cdw_m3.to_numpy(),rcond=None)
        residual.loc[pairs.index]=pairs.ln_cdw_m3.to_numpy()-x@beta
    rows=[];outcome_n=frame.ln_cdw_m3.notna().sum()
    for source,name,feature,transform,eligible in VARIABLES:
        r,p,n=corr_with_p(frame.ln_cdw_m3,frame[feature])
        rr,rp,rn=corr_with_p(residual,frame[feature])
        city_n=frame.loc[frame.ln_cdw_m3.notna() & frame[feature].notna(),'city_id'].nunique()
        coverage=n/outcome_n if outcome_n else np.nan
        coverage_pass=bool(outcome_n and coverage>=.85 and city_n>=15)
        pearson_pass=bool(pd.notna(r) and abs(r)>=.5)
        support=bool(pd.notna(rp) and rp<.10 and pd.notna(rr) and (rr>0)==(r>0))
        cls=('domain_or_control' if not eligible else 'rejected_low_coverage_or_weak_pearson'
             if not(coverage_pass and pearson_pass) else 'delta_candidate' if support else 'level_scale_proxy')
        rows.append(dict(screen_start=2018,screen_end=cutoff,feature=feature,part1_name=name,source_column=source,
            transform=transform,eligible=eligible,outcome_n=int(outcome_n),pair_n_y=n,coverage_y=coverage,
            city_coverage=int(city_n),pearson_pooled=r,pearson_pooled_p=p,persistence_resid_pair_n=rn,
            persistence_resid_corr=rr,persistence_resid_p=rp,coverage_pass=coverage_pass,
            pearson_pass=pearson_pass,change_support=support,downgrade_class=cls))
    table=pd.DataFrame(rows)
    # Historical implementation's VIF pool is coverage-pass eligible variables,
    # BEFORE intersecting with Pearson and residual-support gates.
    pool=table.loc[table.coverage_pass & table.eligible,'feature'].tolist()
    remaining=list(pool);trace=[]
    while len(remaining)>2:
        scores,n=calculate_vif(frame,remaining)
        valid={k:v for k,v in scores.items() if pd.notna(v)}
        if not valid: break
        worst=max(valid,key=valid.get)
        if valid[worst]<10: break
        trace.append(dict(screen_end=cutoff,step=len(trace)+1,removed=worst,vif=valid[worst],n_complete=n))
        remaining.remove(worst)
    scores,n=calculate_vif(frame,remaining)
    table['in_vif_pool']=table.feature.isin(pool)
    table['low_vif_subset']=table.feature.isin(remaining)
    table['final_vif']=table.feature.map(scores)
    table['vif_n_complete']=n
    table['vif_estimable']=bool(scores)
    table['selected']=(table.downgrade_class=='delta_candidate') & table.low_vif_subset
    table['decision_reason']=table.apply(lambda r:'selected' if r.selected else
        r.downgrade_class if r.downgrade_class!='delta_candidate' else 'removed_by_vif',axis=1)
    chosen=table.loc[table.selected,'feature'].tolist()
    return chosen,table,pd.DataFrame(trace,columns=['screen_end','step','removed','vif','n_complete'])
