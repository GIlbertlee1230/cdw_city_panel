# Full-pool foldwise predictor screening

Inspect and reproduce the separate full-pool screening sensitivity. Its selected inputs differ from the fixed four-predictor model.

## Contents

- `data/`
- `main.py`
- `metadata/`
- `original_code/`
- `protocol.json`
- `requirements.txt`
- `results/`
- `src/`

## Execution

Run from the project root in a separate Python process:

```bash
python analyses/foldwise_screening/main.py
```

This fitting command uses the distributed inputs and the recorded analysis protocol. Generated runs are separate from the archived results; this analysis does not replace the primary selected model.

## Interpretation

Definitions and analysis-specific limitations are in `docs/supplementary_information.md` at the project root. Scientific input files, labels and frozen results are preserved. The directory name describes the analysis rather than a review stage or internal experiment number.
