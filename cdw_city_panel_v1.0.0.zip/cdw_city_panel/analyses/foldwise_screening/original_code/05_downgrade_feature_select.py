"""
降级规则下的 Part1 特征筛选（预注册）。

背景：21 市主窗口 System GMM 作为硬门槛几乎全部失败（设定A primary 0 通过；
唯一的设定B"通过"Hansen p=0.994 属工具过度假通过）。按 v2 设计预注册的降级方案，
GMM 退为 supporting evidence，特征筛选改用：
    coverage >= 0.85
    |pooled Pearson| >= 0.50
    change-support: persistence-residual 相关 p < 0.10 且方向与 pooled 一致
并在此基础上用 VIF 标注低共线子集。

本脚本只读取已生成的 outputs/part1_candidate_summary.csv（GMM 不重跑），
输出 outputs/part1_downgrade_feature_sets.csv。
"""
from pathlib import Path
import pandas as pd

ROOT = Path("[local-workspace]/Desktop/毕业论文/Conference/迁移学习/Part1_rerun_20260609")
SUMMARY = ROOT / "outputs" / "part1_candidate_summary.csv"
OUT = ROOT / "outputs" / "part1_downgrade_feature_sets.csv"

RESID_P_GATE = 0.10


def classify(row):
    # 仅在普通 GMM 候选变量上做筛选；domain/scale 控制变量除外。
    if int(row.get("gmm_candidate", 0)) != 1:
        return "domain_or_control"
    if not (bool(row["coverage_pass"]) and bool(row["pearson_pass"])):
        return "rejected_low_coverage_or_weak_pearson"
    resid_p = row["persistence_resid_corr_p_eff"]
    resid_r = row["persistence_resid_corr"]
    pooled = row["pearson_pooled"]
    change_support = (
        pd.notna(resid_p)
        and resid_p < RESID_P_GATE
        and pd.notna(resid_r)
        and pd.notna(pooled)
        and (resid_r > 0) == (pooled > 0)
    )
    if change_support:
        return "delta_candidate"
    return "level_scale_proxy"


def main():
    df = pd.read_csv(SUMMARY)
    # persistence_resid_p 列名在 summary 中即 persistence_resid_p
    df["persistence_resid_corr_p_eff"] = df["persistence_resid_p"]

    df["downgrade_class"] = df.apply(classify, axis=1)
    df["low_vif_subset"] = df["vif_status"].eq("in_reduced_low_vif_group")

    keep = [
        "window",
        "variable",
        "cn_name",
        "category",
        "downgrade_class",
        "coverage_y",
        "pearson_pooled",
        "pearson_within",
        "delta_corr",
        "delta_p",
        "persistence_resid_corr",
        "persistence_resid_p",
        "vif_status",
        "low_vif_subset",
        "any_gmm_pass",
        "primary_gmm_pass",
    ]
    out = df[keep].sort_values(
        ["window", "downgrade_class", "persistence_resid_p"]
    ).reset_index(drop=True)
    out.to_csv(OUT, index=False, encoding="utf-8-sig")

    print("=== 降级规则筛选结果 ===")
    for window in ["L1", "L2"]:
        sub = out[out["window"] == window]
        print(f"\n[{window}]")
        for cls in ["delta_candidate", "level_scale_proxy",
                    "rejected_low_coverage_or_weak_pearson", "domain_or_control"]:
            vs = sub[sub["downgrade_class"] == cls]
            names = ", ".join(vs["cn_name"].tolist())
            print(f"  {cls} (n={len(vs)}): {names}")
        delta = sub[sub["downgrade_class"] == "delta_candidate"]
        low = delta[delta["low_vif_subset"]]
        print(f"  -> delta_candidate 中低共线子集 (n={len(low)}): "
              + ", ".join(low["cn_name"].tolist()))
    print(f"\nSaved: {OUT}")


if __name__ == "__main__":
    main()
