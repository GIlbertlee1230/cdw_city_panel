"""Actual 2026-06-09 candidate grid and estimators, extracted without algorithm changes.
I/O is supplied by run_reproduction.py; this module has no import-time writes.
"""
import itertools

import json

import math

import platform

import sys

from pathlib import Path

import numpy as np

import pandas as pd

import sklearn

from sklearn.base import BaseEstimator, TransformerMixin

from sklearn.ensemble import ExtraTreesRegressor, GradientBoostingRegressor, RandomForestRegressor

from sklearn.gaussian_process import GaussianProcessRegressor

from sklearn.gaussian_process.kernels import ConstantKernel, RBF

from sklearn.impute import SimpleImputer

from sklearn.kernel_ridge import KernelRidge

from sklearn.linear_model import ElasticNet, HuberRegressor, Ridge

from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

from sklearn.neural_network import MLPRegressor

from sklearn.pipeline import Pipeline

from sklearn.preprocessing import PolynomialFeatures, StandardScaler

from sklearn.svm import SVR

SEED = 20260609

TARGET = "ln_cdw_m3"

HOLDOUT_YEAR = 2024

TRAIN_START = 2016

TRAIN_END = 2023

INNER_VALIDATION_YEARS = [2021, 2022, 2023]

FEATURES = ["L1_outcome", "L2_ntl", "L2_urban_rate", "L2_fai", "L2_disp_income"]

COMPLEXITY_ORDER = {
    "Ridge": 0,
    "ElasticNet": 1,
    "Huber": 2,
    "SVR": 3,
    "KRR": 4,
    "PolynomialRidge": 5,
    "GPR": 6,
    "ExtraTrees": 7,
    "RandomForest": 8,
    "GradientBoosting": 9,
    "MLP": 10,
}

class ColumnWeighter(BaseEstimator, TransformerMixin):
    def __init__(self, weights=None):
        self.weights = weights

    def fit(self, x, y=None):
        return self

    def transform(self, x):
        if self.weights is None:
            return x
        return np.asarray(x, dtype=float) * np.asarray(self.weights, dtype=float)

def metrics(actual, prediction):
    actual = np.asarray(actual, dtype=float)
    prediction = np.asarray(prediction, dtype=float)
    return {
        "r2": float(r2_score(actual, prediction)),
        "rmse": float(math.sqrt(mean_squared_error(actual, prediction))),
        "mae": float(mean_absolute_error(actual, prediction)),
    }

def valid_rows(frame):
    return frame.dropna(subset=[TARGET, *FEATURES]).copy()

def weight_vector(dynamic_weight):
    return [float(dynamic_weight), 1.0, 1.0, 1.0, 1.0]

def candidate_specs():
    specs = []
    dynamic_weights = [1.0, 1.5, 2.0, 3.0, 5.0]

    for dynamic_weight, alpha in itertools.product(dynamic_weights, [0.001, 0.01, 0.1, 1.0, 10.0, 100.0]):
        specs.append(("Ridge", {"alpha": alpha, "dynamic_weight": dynamic_weight}))

    for dynamic_weight, alpha, l1_ratio in itertools.product(
        dynamic_weights, [0.0005, 0.001, 0.005, 0.01, 0.05, 0.1], [0.15, 0.3, 0.5, 0.7, 0.9]
    ):
        specs.append(("ElasticNet", {"alpha": alpha, "l1_ratio": l1_ratio, "dynamic_weight": dynamic_weight}))

    for dynamic_weight, epsilon in itertools.product(dynamic_weights, [1.1, 1.35]):
        specs.append(("Huber", {"epsilon": epsilon, "dynamic_weight": dynamic_weight}))

    for dynamic_weight, c, epsilon, gamma in itertools.product(
        dynamic_weights,
        [0.5, 1.0, 2.0, 4.0, 8.0, 16.0, 32.0, 64.0],
        [0.01, 0.03, 0.05, 0.08, 0.10, 0.15],
        [0.005, 0.01, 0.02, 0.03, 0.05, 0.08, 0.10, 0.20, "scale"],
    ):
        specs.append(("SVR", {"C": c, "epsilon": epsilon, "gamma": gamma, "dynamic_weight": dynamic_weight}))

    for dynamic_weight, alpha, gamma in itertools.product(
        dynamic_weights, [0.001, 0.003, 0.01, 0.03, 0.1, 0.3, 1.0, 3.0], [0.005, 0.01, 0.02, 0.03, 0.05, 0.08, 0.10, 0.20]
    ):
        specs.append(("KRR", {"alpha": alpha, "gamma": gamma, "dynamic_weight": dynamic_weight}))

    for dynamic_weight, degree, alpha in itertools.product(dynamic_weights, [2], [0.01, 0.1, 1.0, 10.0, 100.0]):
        specs.append(("PolynomialRidge", {"degree": degree, "alpha": alpha, "dynamic_weight": dynamic_weight}))

    for dynamic_weight, length_scale, alpha in itertools.product(dynamic_weights, [0.3, 0.7, 1.0, 2.0, 4.0], [0.005, 0.01, 0.03, 0.1]):
        specs.append(("GPR", {"length_scale": length_scale, "alpha": alpha, "dynamic_weight": dynamic_weight}))

    for leaf, max_features in itertools.product([1, 2, 3, 4, 6], [0.6, 0.8, 1.0]):
        specs.append(("ExtraTrees", {"min_samples_leaf": leaf, "max_features": max_features}))
        specs.append(("RandomForest", {"min_samples_leaf": leaf, "max_features": max_features}))

    for n_estimators, learning_rate, max_depth, subsample in itertools.product(
        [80, 150, 250], [0.02, 0.03, 0.05, 0.07], [1, 2, 3], [0.7, 1.0]
    ):
        specs.append(
            (
                "GradientBoosting",
                {
                    "n_estimators": n_estimators,
                    "learning_rate": learning_rate,
                    "max_depth": max_depth,
                    "subsample": subsample,
                },
            )
        )

    for dynamic_weight, hidden_layer_sizes, alpha, learning_rate_init in itertools.product(
        [1.0, 2.0, 3.0],
        [(3,), (5,), (8,), (5, 3)],
        [0.001, 0.01, 0.1],
        [0.001, 0.003],
    ):
        specs.append(
            (
                "MLP",
                {
                    "hidden_layer_sizes": hidden_layer_sizes,
                    "alpha": alpha,
                    "learning_rate_init": learning_rate_init,
                    "dynamic_weight": dynamic_weight,
                },
            )
        )

    return [
        {
            "candidate_id": index,
            "algorithm": algorithm,
            "params": params,
            "params_json": json.dumps(params, sort_keys=True),
        }
        for index, (algorithm, params) in enumerate(specs)
    ]

def estimator(spec):
    algorithm = spec["algorithm"]
    params = dict(spec["params"])
    dynamic_weight = params.pop("dynamic_weight", 1.0)
    weighted_steps = [
        ("imputer", SimpleImputer(strategy="median")),
        ("scale", StandardScaler()),
        ("weight", ColumnWeighter(weight_vector(dynamic_weight))),
    ]

    if algorithm == "Ridge":
        return Pipeline([*weighted_steps, ("model", Ridge(**params))])
    if algorithm == "ElasticNet":
        return Pipeline(
            [*weighted_steps, ("model", ElasticNet(max_iter=50000, random_state=SEED, **params))]
        )
    if algorithm == "Huber":
        return Pipeline([*weighted_steps, ("model", HuberRegressor(max_iter=5000, **params))])
    if algorithm == "SVR":
        return Pipeline([*weighted_steps, ("model", SVR(kernel="rbf", **params))])
    if algorithm == "KRR":
        return Pipeline([*weighted_steps, ("model", KernelRidge(kernel="rbf", **params))])
    if algorithm == "PolynomialRidge":
        degree = params.pop("degree")
        alpha = params.pop("alpha")
        return Pipeline(
            [
                *weighted_steps,
                ("poly", PolynomialFeatures(degree=degree, include_bias=False)),
                ("model", Ridge(alpha=alpha)),
            ]
        )
    if algorithm == "GPR":
        length_scale = params.pop("length_scale")
        alpha = params.pop("alpha")
        kernel = ConstantKernel(1.0, constant_value_bounds="fixed") * RBF(
            length_scale=length_scale, length_scale_bounds="fixed"
        )
        return Pipeline(
            [
                *weighted_steps,
                ("model", GaussianProcessRegressor(kernel=kernel, alpha=alpha, normalize_y=True, random_state=SEED)),
            ]
        )
    if algorithm == "ExtraTrees":
        return Pipeline(
            [
                ("imputer", SimpleImputer(strategy="median")),
                ("model", ExtraTreesRegressor(n_estimators=600, random_state=SEED, n_jobs=-1, **params)),
            ]
        )
    if algorithm == "RandomForest":
        return Pipeline(
            [
                ("imputer", SimpleImputer(strategy="median")),
                ("model", RandomForestRegressor(n_estimators=600, random_state=SEED, n_jobs=-1, **params)),
            ]
        )
    if algorithm == "GradientBoosting":
        return Pipeline(
            [
                ("imputer", SimpleImputer(strategy="median")),
                ("model", GradientBoostingRegressor(random_state=SEED, **params)),
            ]
        )
    if algorithm == "MLP":
        return Pipeline(
            [
                *weighted_steps,
                (
                    "model",
                    MLPRegressor(
                        max_iter=3000,
                        early_stopping=True,
                        validation_fraction=0.25,
                        random_state=SEED,
                        **params,
                    ),
                ),
            ]
        )
    raise ValueError(algorithm)

def evaluate_fold(panel, spec, validation_year):
    train = valid_rows(panel[panel["year"].between(TRAIN_START, validation_year - 1)])
    validation = valid_rows(panel[(panel["year"].eq(validation_year)) & (panel["GBA_dummy"].eq(1))])
    if len(train) < 12 or len(validation) < 8:
        return None
    model = estimator(spec)
    model.fit(train[FEATURES], train[TARGET])
    prediction = np.asarray(model.predict(validation[FEATURES]), dtype=float)
    return {
        "candidate_id": spec["candidate_id"],
        "algorithm": spec["algorithm"],
        "params_json": spec["params_json"],
        "validation_year": validation_year,
        "n_train": len(train),
        "n_validation": len(validation),
        **metrics(validation[TARGET], prediction),
    }

def run_inner(panel):
    rows = []
    specs = candidate_specs()
    for spec in specs:
        for validation_year in INNER_VALIDATION_YEARS:
            row = evaluate_fold(panel, spec, validation_year)
            if row is not None:
                rows.append(row)
    folds = pd.DataFrame(rows)
    summary = (
        folds.groupby(["candidate_id", "algorithm", "params_json"], as_index=False)
        .agg(
            folds=("validation_year", "nunique"),
            min_train_n=("n_train", "min"),
            min_validation_n=("n_validation", "min"),
            mean_inner_r2=("r2", "mean"),
            mean_inner_rmse=("rmse", "mean"),
            std_inner_rmse=("rmse", lambda s: s.std(ddof=0)),
            mean_inner_mae=("mae", "mean"),
        )
    )
    summary = summary[summary["folds"].eq(len(INNER_VALIDATION_YEARS))].copy()
    summary["objective"] = summary["mean_inner_rmse"] + 0.15 * summary["std_inner_rmse"]
    summary["complexity_order"] = summary["algorithm"].map(COMPLEXITY_ORDER)
    summary = summary.sort_values(
        ["objective", "mean_inner_mae", "complexity_order", "candidate_id"]
    ).reset_index(drop=True)
    selected = summary.iloc[0]
    specs_by_id = {spec["candidate_id"]: spec for spec in specs}
    return specs, folds, summary, selected, specs_by_id

def evaluate_holdout(panel, selected, specs_by_id):
    spec = specs_by_id[int(selected["candidate_id"])]
    train = valid_rows(panel[panel["year"].between(TRAIN_START, TRAIN_END)])
    test = valid_rows(panel[(panel["year"].eq(HOLDOUT_YEAR)) & (panel["GBA_dummy"].eq(1))])
    if len(test) != 9:
        raise ValueError(f"Expected 9 holdout rows, got {len(test)}")
    model = estimator(spec)
    model.fit(train[FEATURES], train[TARGET])
    prediction = np.asarray(model.predict(test[FEATURES]), dtype=float)
    score = metrics(test[TARGET], prediction)
    result = {
        "model": "dynamic_part1_deep_tuned",
        "domain": "Province-pooled",
        "window": "L2",
        "features": "|".join(FEATURES),
        "algorithm": spec["algorithm"],
        "params_json": spec["params_json"],
        "train_year_min": int(train["year"].min()),
        "train_year_max": int(train["year"].max()),
        "test_year": HOLDOUT_YEAR,
        "n_train": len(train),
        "n_test": len(test),
        **score,
        "meets_r2_085": score["r2"] >= 0.85,
    }
    predictions = test[["district_name", "year", "C_DW_generation_m3", TARGET, *FEATURES]].copy()
    predictions["pred_ln_cdw_m3"] = prediction
    predictions["pred_cdw_m3"] = np.exp(prediction)
    predictions["residual_ln"] = predictions[TARGET] - predictions["pred_ln_cdw_m3"]
    return pd.DataFrame([result]), predictions
