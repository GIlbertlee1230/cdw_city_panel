# Changelog

## 1.0.0 — 2026-11-04

First distribution under the `cdw_city_panel` project name.

- Organised compiled inputs, processed panels, extraction evidence, analysis modules and results into descriptive directories.
- Added a reader-oriented README, dataset metadata, citation guidance and file-level distribution lineage.
- Updated executable references for the new directory and primary file names.
- Preserved experimental observations, audit decisions, frozen protocol records and selected predictions.

This version identifies the distribution. It does not imply that a public repository record or persistent identifier has been assigned.
