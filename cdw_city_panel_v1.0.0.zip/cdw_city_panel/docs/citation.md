# Citation and access metadata

Associated manuscript:

*From fragmented public disclosures to auditable panel data: a city-scale construction and demolition waste forecasting workflow*.

Project: `cdw_city_panel`  
Distribution version: `1.0.0`  
Prepared: `2026-11-04`

Author names and contact details are withheld for anonymous review. This local distribution has no repository record, DOI or other persistent identifier. When deposited, use the repository's version-specific data/software citation and add the actual creators, identifier, publication year and access URL. Do not substitute the manuscript title for an assigned dataset identifier or fabricate a DOI.

The description and coverage metadata are supplied in `metadata/dataset_metadata.json`. Third-party data and quoted source evidence remain subject to their original attribution and reuse conditions.
