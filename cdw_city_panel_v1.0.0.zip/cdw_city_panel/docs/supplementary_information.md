# Supplementary Information

## S1. Source linkage, unit origins and complete confirmed-mass sensitivity

The 139-row model-input ledger retains source evidence, original units, conversion/rounding rules, historical decisions and unresolved cases. It links compiled values to the available evidence rather than asserting that a later extraction batch generated all earlier model inputs. Provincial precedence is a convention for comparable historical annual city totals, not proof of higher accuracy or common definitions. Generation is distinct from collection, disposal, utilisation, capacity, forecasts and district/subtype quantities. The conversion reference is the Shenzhen governance plan (2020-2035), November 2021, printed page 22, which uses 1.5 tonnes/m3 to relate 95.81 million m3 to approximately 144 million tonnes. Full government documents are not redistributed.

| Sample | Native volume | Confirmed tonne origin | Undocumented unit origin | Total |
|---|---:|---:|---:|---:|
| Complete modelling cohort | 104 | 7 | 1 | 112 |
| 2024 GBA9 targets | 1 | 7 | 1 | 9 |

All seven confirmed tonne-origin observations are 2024 targets: Guangzhou, Shenzhen, Foshan, Huizhou, Dongguan, Zhongshan and Jiangmen. Zhuhai 2024 is the retained direct-volume planning-attachment observation. Zhaoqing 2024 has no confirmed original unit in the retained ledger; it is not recoded as native volume or assigned an inferred tonne value. Unit-origin counts are different from the historical 103 exact / 5 conversion-rounding / 3 legacy / 1 attachment reconciliation labels. Those labels describe matching status and do not count all mass-origin records.

The complete confirmed-mass sensitivity fixes every prediction and rescales only the seven confirmed mass-derived outcomes as frozen_m3 *1.5/rho. This preserves historical rounding and exactly reproduces the frozen baseline at rho=1.5. The common-density scenario uses rho=1.300--1.800 in 0.001 increments (501 points). It changes log-R2 from 0.858026 to 0.937429, log-RMSE from 0.272130 to 0.377776 and original-scale MAPE from 21.5574% to 40.5059%. It does not re-estimate coefficients, change input features, select models or validate a physical density. The ledger's seven raw tonne amounts yield m3 values within 50 m3 of the frozen baseline due to historical rounding.

Zhaoqing remains fixed in the primary curve. A separately labelled scenario hypothetically applies the same scale factor to that record as well, giving log-R2 range 0.863496--0.933450 and MAPE 22.6316--42.7717%. This is a sensitivity to its unknown origin, not evidence that the record was reported in tonnes. The earlier five-record curve remains an archived historical calculation and is superseded by the seven-confirmed-record curve for current reporting.

Counts, per-record origins and all fixed-prediction curves are supplied in `analyses/density_sensitivity/`. Its `main.py` reproduces the arithmetic offline, without model fitting. Uncertainty in city-specific composition or the undocumented unit is not eliminated by this scenario analysis.

## S2. Excluded-passage review

After removal of the final extraction queue, previously annotated records and out-of-window candidates, 1,343 candidate fields yielded 737 exact-deduplicated passages. Three strata contained 23 generation-like, 197 ambiguous/collection and 517 other passages; 20 per stratum were sampled with seed 20261101. The author reviewed eligibility for city-level annual actual generation. The confirmed decisions are 5 positive, 53 negative and 2 uncertain; by stratum, 1/18/1, 1/18/1 and 3/17/0. Original decisions and confirmed changes are retained. Uncertain cases are not recoded as negatives.

The respective positive proportions among determinate labels are 1/19, 1/19 and 3/20, with Wilson 95% intervals 0.009–0.246, 0.009–0.246 and 0.052–0.360. These conditional intervals have no finite-population or document-cluster correction. The equal stratum allocation is not proportional; an unweighted 5/60 is not a population omission estimate. Varying the two uncertain sample labels and using population weights yields 12.01–13.51%, but this is only a sample-label sensitivity range, not a confidence interval or population bound.

Four positive quantities already appeared in other queued passages. The remaining positive was a municipal Jieyang 2023 alternative of 553.53 ten-thousand tonnes (3,690,200 m3), whereas the panel retained the provincial 3,334,400 m3. All five city-years were in the queue; some 2024 non-GBA cities are outside the modelling target. The check identifies screening-stage omissions but covers neither pre-parsing/full-document losses nor all city-years. Two passages remain uncertain because year or generation-versus-disposal meaning is unclear.

## S3. Rules-only comparison

The main deployment audit is 120 candidates stratified as 70 provincial generation, 20 annual generation, 16 annual non-target and 14 municipal non-target. Human labels are 91 positive and 29 negative. The matched refined rules produced TP/FP/FN/TN = 91/2/0/27, precision 0.978, recall 1.000, F1 0.989. Archived DeepSeek outputs gave 91/3/0/26, precision 0.968, recall 1.000, F1 0.984. Both recovered target fields on 91/91 positives. On 111 exact-deduplicated passages, both gave 87/2/0/22. The refined rule system was developed with access to these labels; this comparison is retrospective.

The initial rule prototype gave 80/1/11/28, precision 0.988, recall 0.879, F1 0.930. Existing-city/year-metadata-aligned target-field correctness was 77/91, versus 91/91 for the archived LLM. The unaligned prototype result is not used to quantify LLM value because its year parsing inflated the difference. Neither rule engineering effort nor reviewer time was measured; the data do not establish LLM necessity, superior generalisation or time savings.

## S4. Historically informed compact core and full-pool sensitivity

The compact core fixes four representatives: NTL for urban activity, urbanisation for composition, fixed-asset investment for investment activity and disposable income for household socioeconomic conditions. This is a post-review formalisation informed by the full-window exploratory analysis, not preregistration or an optimal ranking among all proxies. Checks within 2018–2020 / 2018–2021 / 2018–2022 require coverage >=0.85, at least 15 cities, absolute Pearson r >=0.50, and quartet VIF below the reference of 10. No persistence-residual gate is used. All four pass, with maximum VIF 9.8677 / 9.4442 / 7.6167. Repeating the original 2,969 configurations selects Ridge alpha=100, w=3; 2024 R2 remains 0.923785. This establishes training-window admissibility conditional on the core, not independent recovery of four representatives.

A separate full-pool training-fold screening sensitivity yields a final ten-predictor set and 2024 R2=0.914325; its dynamic-only comparator gives 0.928342. It uses its own complete-outcome cohort and training-fold preprocessing, with saved membership and missing-value handling in the module. It is not the original four-variable model, and neither analysis restores an untouched 2024 test. The archived all-pool and compact-core protocols are separate reproducible analyses.

The Fig.1 Pearson window contains 118 city-years in 2018-2023. The original 18-variable VIF pool has 114 complete rows; four rows have missing wider-pool covariates (Yunfu 2018/2019, Meizhou 2018 and Chaozhou 2018). The historical reduced pool retains 11 variables on that common 114-row cohort. Displayed VIFs of 2.3513--8.8496 refer to the four retained indicators assessed within that wider pool, not a joint four-variable regression or a fold-specific maximum. These definitions and the four omitted keys are in `analyses/screening_sample_audit/`.

## S5. Matched Ridge ablation

S, D and DS use the same 112 complete rows, training/validation sizes 42/8, 61/9 and 82/9, and final 103/9. Preprocessing is training-only. Each uses alpha in {0.001,0.01,0.1,1,10,100}; D and DS additionally use w in {1,1.5,2,3,5}. The objective is mean log-RMSE + 0.15 population SD; MAE and deterministic tie-breakers follow the archived search. Selected alpha is 100 for all, with w=3 for D and DS. S has no dynamic weight.

Mean inner log-RMSE is 1.063171 / 0.724415 / 0.696507 for S/D/DS. Their 2024 R2 values are 0.683635 / 0.928342 / 0.923785; log-RMSE 0.591559 / 0.281538 / 0.290351; log-MAE 0.488531 / 0.214016 / 0.243986; MAPE 55.82% / 21.36% / 28.25%. Adding structures improves mean inner validation by 3.8%, with gains/losses varying by year, but does not improve aggregate 2024 accuracy. The original mixed-algorithm table is retained only under `results/manuscript_baseline/`. Single-model bootstrap interval width does not establish statistical equivalence of two models.

## S6. Original-scale error interpretation

For e = log(observed) - log(predicted), signed relative prediction error = exp(-e)-1. Forecasts are exponentiated point estimates, without a lognormal mean correction. The DS MAPE is 28.2483%, median absolute percentage error 24.1203%; naive persistence gives 40.9584% and 34.4201%. Zhuhai is 80.1927% overpredicted, with 10.1148 million m3 predicted versus 5.6133 observed. Its 2023 value was 7.9013 million. Six target cities declined in 2024; seven DS forecasts overpredicted. These are descriptive observations, not a causal account of economic change or a validated application-specific tolerance.

## S7. Non-adopted predictive explorations

Archived protocols, receipts and target comparisons for group-penalty and temporal residual-correction trials are under `analyses/exploratory_specifications/`. The group-penalty validation selected the original combined penalty setting; the time-ordered residual correction gave target R2=0.919125, below the original combined 0.923785 and dynamic-only 0.928342. They were not adopted and do not support a positive aggregate 2024 structural gain. These compact archives document the exploratory statement in the response; they are not additional confirmatory evaluations or new recommended models.

## S8. Final original-grid comparison and fixed baselines

The original 11-family grid and estimator factory are reused without adding models, kernels or parameter values. S removes dynamic_weight and deduplicates to 685 configurations; D retains all 2,969. DS reuses its original 2,969-candidate summary and 8,907 fold records. All groups use the common 103/9 final cohort and 42/61/82 versus 8/9/9 internal folds. Selection minimises mean validation log-RMSE plus 0.15 population SD, then mean log-MAE, original complexity order and original ID. Saved S/D/DS winner IDs are 2799/352/23. Frozen sources, candidate membership and the selection-before-current-scoring record are under `analyses/model_comparison/results/main_run/`.

| Input | Selected model | Objective | 2024 log-R2 | log-RMSE | log-MAE | MAPE |
|---|---|---:|---:|---:|---:|---:|
| S | Extra Trees | 0.723813 | 0.815110 | 0.452232 | 0.399828 | 43.6620% |
| D | RBF-SVR | 0.717295 | 0.930802 | 0.276662 | 0.210675 | 21.3852% |
| DS | Ridge | 0.704436 | 0.923785 | 0.290351 | 0.243986 | 28.2483% |

S uses 600 trees, min_samples_leaf=1 and max_features=1.0. D uses C=4, epsilon=0.01, gamma=0.005 and w=1. DS retains alpha=100 and w=3. The original staged S/D target scores 0.873393/0.910831 are separate historical results, replaced for the final common-protocol comparison.

The new S/D search completed 10,962 fold fits without failures and retained 123 MLP warnings. Neither winner is MLP. Independent-process refits of the three winners reproduced target predictions exactly. The execution log contains ignored resource-tracker cleanup messages after scoring; the process exited with code 0 and all fold records were verified. The only adapters concern weight-vector dimension and forest single-thread resource control. MLP preserves its original random early-stopping split inside each historical training fold. No stopping rule, seed or tree count was changed.

The mean baseline uses a fresh mean of training log outcomes in each fold. It is neither a target mean nor an equally weighted provincial city mean. Exact fold calculations and the eight manuscript rows are in `fixed_baselines_by_year.csv` and `manuscript_table4_values.csv`.

| Fixed reference | 2021/2022/2023 log-RMSE | Objective | 2024 log-R2 | log-RMSE | log-MAE | MAPE |
|---|---|---:|---:|---:|---:|---:|
| Training log mean | 1.689630 / 1.439720 / 1.624027 | 1.600328 | -0.772680 | 1.400295 | 1.153280 | 69.3886% |
| Naive persistence | 0.724431 / 0.825360 / 0.766467 | 0.778295 | 0.851965 | 0.404657 | 0.374233 | 40.9584% |

These comparisons are retrospective and conditional on historically chosen inputs. S omits L1 as a feature, but target cities' earlier labels remain in training. It is not a test of cities without outcome histories. The representative-proxy audit and full-pool sensitivity remain separate screening analyses. Current results do not remove historical design exposure, show an aggregate 2024 structural gain or establish equivalence between models. Only the three profile winners and two fixed baselines were scored in the original-grid target comparison.
