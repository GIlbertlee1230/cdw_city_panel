# Analysis notes

This document distinguishes archived results, reproduction commands and the interpretation of the supplied analyses.

## Forecasting

The selected combined model is Ridge(alpha=100, dynamic_weight=3). Candidate selection minimises mean 2021–2023 validation log-RMSE plus 0.15 times its population standard deviation, followed by mean log-MAE, algorithm complexity and original candidate ID. Training-fold preprocessing uses only the corresponding training period.

The final cohort contains 103 training observations and nine 2024 targets. These targets were excluded from the final training and tuning operations but had been inspected historically. The evaluation is retrospective. The structural-only comparison retains past labelled observations from target cities; it does not test cities without disclosure histories.

The model comparison separates matched Ridge tuning from the original 11-family search rule. The combined model has the lowest historical selection objective but does not outperform dynamic-only models on the aggregate 2024 target. Bootstrap intervals from one model do not establish equivalence between models.

## Extraction and screening

The 120-candidate deployment audit and 60-passage excluded-screening check are separate evaluations. Refined rules had access to audit labels. Candidate-stage precision and recall do not estimate full-document recall. Two excluded passages remain uncertain rather than being reclassified as negatives.

The label file `extraction_audit_labels.csv` retains the original decisions. Its formal name describes the actual audit design; it does not imply an independently held-out gold benchmark.

## Units and source records

Outcomes are the compiled values used in the experiment. Unit-origin categories and reconciliation categories have different meanings. Seven modelling outcomes have confirmed mass origin and one has an undocumented origin. The complete confirmed-mass density scenario preserves predictions and historical rounding. The unknown-origin scenario remains hypothetical.

Historical source discrepancies, attachment decisions and missing provenance are retained in the ledger. New source editions or online retrievals have not replaced experimental inputs.

## Numerical reporting

R², RMSE and MAE use natural-log outcomes unless stated otherwise. MAPE and median absolute percentage error use exponentiated point predictions without a lognormal mean correction. The selected MAPE is 28.2483%, reported as 28.2% to one decimal place. The Wilson lower bound for 30/30 agreement is approximately 0.886486, reported as 0.886 to three decimal places.

The distributed outputs are immutable reference records. Reproduction commands write separately. File renaming is recorded in the distribution lineage; protocol and result contents are not retrospectively presented as newly generated evidence.
