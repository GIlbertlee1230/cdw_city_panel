# Data dictionary

All quantities below describe the supplied experiment inputs. They are not replacements derived from a different source edition. Empty CSV fields represent missing values, never observed zeros. `district_name` plus integer `year` is the city-year key. English city labels are defined in `metadata/city_dictionary.csv`.

## Outcome input

| Field | Meaning | Unit / representation |
|---|---|---|
| `district_name` | City identifier | English city label |
| `year` | Outcome year | Calendar year |
| `C_DW_generation_m3` | Compiled C&DW generation used in the experiment | Cubic metres |

The 139-row file includes eight historical observations outside 2016–2024. Restricting to 2016–2024 gives 131 rows. These are the actual compiled standardized outcomes; the model does not reconvert tonnes when reading this table.

## Covariate input

The input has 252 rows, covering 21 cities in 2013–2024. There are 19 Part1 candidate covariates, one retained auxiliary population column, two key columns and one GBA flag. A field name describes the input's compiled unit; no unit conversion is introduced by the English export.

| Field | Meaning / compiled unit | Part1 transformed feature |
|---|---|---|
| `construction_output_100m_rmb` | Construction-enterprise output, 100 million RMB | `ln_conout` |
| `construction_area_10k_m2` | Building construction area, 10,000 m² | `ln_conarea` |
| `urbanization_rate` | Urbanization fraction, retained in levels | `urban_rate_raw` |
| `resident_population_10k` | Resident population, 10,000 persons | `ln_pop_10k` |
| `fixed_asset_investment_10k_rmb` | Fixed-asset investment, 10,000 RMB | `ln_fai` |
| `real_estate_investment_million_rmb` | Real-estate investment, million RMB | `ln_house_invest` |
| `gdp_10k_rmb` | GDP, 10,000 RMB | `ln_gdp` |
| `land_area_km2` | Administrative land area, km² | `ln_land_area` |
| `tertiary_value_added_10k_rmb` | Tertiary-sector value added, 10,000 RMB | `ln_tertiary_value` |
| `ntl_mean_dn` | Annual compiled nighttime-light mean DN | `ln_ntl` |
| `new_construction_area_10k_m2` | Newly started area, 10,000 m² | `ln_new_start` |
| `construction_profit_100m_rmb` | Construction-enterprise profit, 100 million RMB | `ln_con_profit` |
| `disposable_income_rmb` | Per-capita disposable-income series as supplied, RMB | `ln_disp_income` |
| `consumption_expenditure_rmb` | Per-capita consumption-expenditure series as supplied, RMB | `ln_consumption` |
| `energy_intensity_growth` | Growth of energy consumption per unit GDP, original numeric rate | `energy_growth_raw`, retained in levels |
| `tertiary_share` | Tertiary-sector share, original percentage-like values | `ln_tertiary_share` in Part1 |
| `construction_value_added_100m_rmb` | Construction value added, 100 million RMB | `ln_construction_va` |
| `real_estate_value_added_100m_rmb` | Real-estate value added, 100 million RMB | `ln_realestate_va` |
| `annual_house_price_rmb_m2` | Annual house-price series, RMB/m² | `ln_price` |
| `population_auxiliary` | Additional population column retained from the actual workbook | Not a Part1 candidate; do not substitute it for `resident_population_10k` |
| `GBA_dummy` | Membership in the nine-city target region | 0 / 1 |

The `ln_` columns use natural logarithms. The four final structural predictors are NTL, urbanization, FAI and disposable income. Their model-ready names are `L2_ntl`, `L2_urban_rate`, `L2_fai`, `L2_disp_income`. The final dynamic feature is `L1_outcome`, in natural-log outcome units. See README for their exact calendar-year definitions. Income and consumption labels refer to the series actually supplied to the experiment; this release performs no source-edition substitution.

## Model-ready and prepared files

- `data/lagged_features/`: outcome year remains `year`; covariates are selected from the same city in year `year`, `year-1` or `year-2` according to the filename. All 21 supplied covariate/flag columns are retained alongside the outcome and keys.
- `data/screening/`: 122 rows in each prepared window. The primary 2018–2023 screen restricts that panel to 118 rows. `city_id` preserves the original numerical city identifier. `L1_ln_cdw_m3` and `delta_ln_cdw_m3` refer to outcome persistence and outcome change. `delta_ln_cdw_m3` does not imply that the predictor is also differenced.
- `data/processed/forecast_panel.csv`: 131 raw forecasting rows; the complete-case filter requires `ln_cdw_m3` and all five selected features. `GBA_dummy` identifies inner/target validation membership.
- Prediction files: `pred_ln_cdw_m3` is the prediction on the model scale; `pred_cdw_m3` is its direct exponential without a bias correction; `residual_ln` is observed log outcome minus predicted log outcome. Reported RMSE and MAE use log units.
- Inner-search files: `params_json` contains the actual candidate parameters; `objective = mean_inner_rmse + 0.15 * std_inner_rmse`, with population standard deviation across the three folds. Saved ranking tie-breakers are mean MAE, complexity order and candidate ID.

## Part0 records

`field_id`/`sample_id` link the frozen candidate context to attempts and final model decisions; `benchmark_id` links the human audit. `raw_value`/`raw_unit` and `llm_raw_value`/`llm_raw_unit` refer to candidate/model extraction fields. They are not the forecasting table's standardized outcome. Literal Chinese unit tokens and evidence remain unchanged, as do model response strings. `source_url` is an archived registry field and may be blank; no fresh source retrieval is required by the offline reproduction.

`attempt_number`, `format_recovered`, `validation_error_codes`, `decision`, `indicator_type` and `final_decision` retain their experiment meanings. Human labels and model labels are separate columns. `human_positive`/`model_positive` support the candidate-stage confusion counts. A record selected by source-priority code is not automatically a separately human-audited record. The 120-candidate benchmark measures the deployed candidate sample, not passage/document recall. The second-review comparison contains 30 decisions and omits free-text reviewer rationale from its English comparison view.
