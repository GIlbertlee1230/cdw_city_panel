# Reuse and attribution

This release is prepared for accompanying the associated manuscript. Refer to the manuscript and the exact package version when discussing or reproducing the experiment. Repository identifiers must be taken from the eventual deposited record.

Packaging has not assigned a new software or data licence, transferred third-party rights, or claimed ownership of quoted source text. Source-language candidate excerpts remain attributed through the archived registry fields. Full source documents, imagery and statistical-yearbook volumes are not included. The main numerical files are the compiled experiment inputs and their derived analysis results.

If a repository requests a licence selection, the depositing authors should choose terms consistent with their rights and the original data-provider conditions. This note does not invent an access restriction or imply that the local package is already publicly deposited.
