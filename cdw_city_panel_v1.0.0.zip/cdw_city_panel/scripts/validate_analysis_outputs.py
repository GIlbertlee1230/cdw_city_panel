"""Offline arithmetic checks of saved revision results; no model fits or API calls."""
from pathlib import Path
import json
import numpy as np
import pandas as pd

ROOT=Path(__file__).resolve().parents[1]

def read(path):return pd.read_csv(ROOT/path,float_precision='round_trip')

panel=read('data/processed/forecast_panel.csv')
features=['L1_outcome','L2_ntl','L2_urban_rate','L2_fai','L2_disp_income']
complete=panel.dropna(subset=features+['ln_cdw_m3'])
naive=[]
for year in [2021,2022,2023,2024]:
    t=complete[(complete.year==year)&(complete.GBA_dummy==1)].copy()
    e=t.ln_cdw_m3-t.L1_outcome
    naive.append(dict(year=year,n=len(t),r2=1-float((e**2).sum()/((t.ln_cdw_m3-t.ln_cdw_m3.mean())**2).sum()),
                      log_rmse=float(np.sqrt(np.mean(e**2))),log_mae=float(np.mean(abs(e))),
                      mape=float(np.mean(abs(np.expm1(-e)))),median_ape=float(np.median(abs(np.expm1(-e))))))

pred=read('results/forecasting/forecast_predictions_2024.csv')
errors=pred[['district_name','year','C_DW_generation_m3','pred_ln_cdw_m3']].copy()
errors['predicted_m3']=np.exp(errors.pred_ln_cdw_m3)
errors['log_residual']=np.log(errors.C_DW_generation_m3)-errors.pred_ln_cdw_m3
errors['signed_relative_error']=np.expm1(-errors.log_residual)
errors['absolute_relative_error']=abs(errors.signed_relative_error)
previous=complete[complete.year==2024][['district_name','year','L1_outcome']]
errors=errors.merge(previous,on=['district_name','year'],validate='one_to_one')
errors['previous_year_m3']=np.exp(errors.L1_outcome)
errors['observed_annual_change']=errors.C_DW_generation_m3/errors.previous_year_m3-1
errors['naive_absolute_relative_error']=abs(errors.previous_year_m3/errors.C_DW_generation_m3-1)
assert len(errors)==9
assert abs(errors.absolute_relative_error.mean()-.282483336258766)<1e-10
labels=read('analyses/excluded_passage_audit/human_decisions.csv')
counts=labels.decision.astype(str).value_counts().to_dict()
assert counts=={'0':53,'1':5,'?':2},counts
screen=read('analyses/fixed_predictors/results/archived/fold_screening_checks.csv')
assert screen.passed.all()
vifs=screen[screen.validation_year.lt(2024)].groupby('validation_year').vif.max()
rules=read('analyses/rule_comparison/results/archived/matched_comparison_by_scope.csv')
ridge=read('analyses/ridge_ablation/results/archived/comparison_2024.csv')
assert abs(ridge.set_index('profile').loc['DS_combined','r2']-.9237854554663212)<1e-12
target=read('analyses/fixed_predictors/results/archived/target_predictions.csv')
assert len(target)==9
ledger=read('evidence/records/outcome_source_ledger.csv')
xy=read('data/compiled/cdw_generation.csv').merge(ledger,on=['district_name','year'],validate='one_to_one')
assert len(xy)==139
assert np.allclose(xy.C_DW_generation_m3,xy.panel_value_m3,rtol=0,atol=0)
zh=ledger[(ledger.district_name=='Zhuhai')&(ledger.year==2024)].iloc[0]
assert zh.unit_origin=='NATIVE_VOLUME'
out=ROOT/'outputs/revision_checks';out.mkdir(parents=True,exist_ok=True)
pd.DataFrame(naive).to_csv(out/'naive_persistence_by_year.csv',index=False)
errors.to_csv(out/'original_scale_errors_2024.csv',index=False)
report=dict(status='PASS',model_fits=0,llm_calls=0,network_calls=0,
            excluded_labels=counts,maximum_vif_by_validation_year=vifs.to_dict(),
            selected_mape=float(errors.absolute_relative_error.mean()),
            selected_median_ape=float(errors.absolute_relative_error.median()),
            target_declines=int((errors.observed_annual_change<0).sum()),
            target_overpredictions=int((errors.signed_relative_error>0).sum()),
            compared_to_naive_worse_cities=errors.loc[errors.absolute_relative_error>errors.naive_absolute_relative_error,'district_name'].tolist(),
            source_ledger_exact_model_input_matches=139,zhuhai_2024_unit_origin=zh.unit_origin)
(out/'verification.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
