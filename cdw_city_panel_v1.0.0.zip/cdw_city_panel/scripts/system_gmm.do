clear all
set more off
set linesize 255

* Run from the package root; numerical specification unchanged.
capture mkdir "reproduced"
capture mkdir "reproduced/part1_gmm"
log using "reproduced/part1_gmm/run_part1_gmm_A_B.log", replace text

capture which xtabond2
if _rc != 0 {
    display as error "xtabond2 is required but not installed."
    exit 199
}

local xvars ///
    ln_conout ln_conarea urban_rate_raw ln_pop_10k ln_fai ///
    ln_house_invest ln_gdp ln_tertiary_value ln_ntl ln_new_start ///
    ln_con_profit ln_disp_income ln_consumption energy_growth_raw ///
    ln_tertiary_share ln_construction_va ln_realestate_va ln_price

tempname memhold
postfile `memhold' str30 sample str4 window str14 spec str6 inst_lag str32 xvar ///
    double xcoef xse xtstat xpvalue ylagcoef ylagse ylagtstat ylagpvalue ///
    double N groups instruments ar1p ar2p hansenp sarganp rc ///
    using "reproduced/part1_gmm/gmm_A_B_all_results.dta", replace

foreach window in L1 L2 {
    import delimited "data/screening/panel_`window'_2018_2023.csv", varnames(1) case(preserve) clear
    xtset city_id year

    foreach sample in primary_2018_2023 sensitivity_2016_2023 sensitivity_GBA_2018_2023 sensitivity_nonGBA_2018_2023 {
        local sample_if "inrange(year, 2018, 2023)"
        if "`sample'" == "sensitivity_2016_2023" local sample_if "inrange(year, 2016, 2023)"
        if "`sample'" == "sensitivity_GBA_2018_2023" local sample_if "inrange(year, 2018, 2023) & GBA_dummy == 1"
        if "`sample'" == "sensitivity_nonGBA_2018_2023" local sample_if "inrange(year, 2018, 2023) & GBA_dummy == 0"

        foreach x of local xvars {
            foreach spec in A B {
                foreach inst_lag in lag22 lag23 {
                    local lagopt "lag(2 2)"
                    if "`inst_lag'" == "lag23" local lagopt "lag(2 3)"

                    if "`spec'" == "A" {
                        capture noisily xtabond2 ln_cdw_m3 L.ln_cdw_m3 `x' if `sample_if', ///
                            gmm(L.ln_cdw_m3, `lagopt' collapse) ///
                            iv(`x', equation(both)) ///
                            twostep robust small
                    }
                    else {
                        capture noisily xtabond2 ln_cdw_m3 L.ln_cdw_m3 `x' if `sample_if', ///
                            gmm(L.ln_cdw_m3 `x', `lagopt' collapse) ///
                            twostep robust small
                    }
                    local modelrc = _rc

                    scalar xb = .
                    scalar xs = .
                    scalar xt = .
                    scalar xp = .
                    scalar yb = .
                    scalar ys = .
                    scalar yt = .
                    scalar yp = .
                    scalar nobs = .
                    scalar ngroups = .
                    scalar inst = .
                    scalar a1p = .
                    scalar a2p = .
                    scalar hp = .
                    scalar sp = .

                    if `modelrc' == 0 {
                        capture scalar xb = _b[`x']
                        if _rc == 0 {
                            scalar xs = _se[`x']
                            scalar xt = xb / xs
                            capture scalar xp = 2 * ttail(e(df_r), abs(xt))
                            if _rc != 0 scalar xp = 2 * normal(-abs(xt))
                        }
                        capture scalar yb = _b[L.ln_cdw_m3]
                        if _rc == 0 {
                            scalar ys = _se[L.ln_cdw_m3]
                            scalar yt = yb / ys
                            capture scalar yp = 2 * ttail(e(df_r), abs(yt))
                            if _rc != 0 scalar yp = 2 * normal(-abs(yt))
                        }
                        capture scalar nobs = e(N)
                        capture scalar ngroups = e(N_g)
                        capture scalar inst = e(j)
                        capture scalar a1p = e(ar1p)
                        capture scalar a2p = e(ar2p)
                        capture scalar hp = e(hansenp)
                        capture scalar sp = e(sarganp)
                    }

                    post `memhold' ("`sample'") ("`window'") ("`spec'") ("`inst_lag'") ("`x'") ///
                        (xb) (xs) (xt) (xp) (yb) (ys) (yt) (yp) ///
                        (nobs) (ngroups) (inst) (a1p) (a2p) (hp) (sp) (`modelrc')
                }
            }
        }
    }
}

postclose `memhold'

use "reproduced/part1_gmm/gmm_A_B_all_results.dta", clear
gen diagnostics_ok = ar2p > 0.10 & hansenp > 0.10 & instruments <= groups ///
    if ar2p < . & hansenp < . & instruments < . & groups < .
gen coefficient_sig10 = xpvalue < 0.10 if xpvalue < .
gen gmm_pass = coefficient_sig10 == 1 & diagnostics_ok == 1 & rc == 0
gen spec_lag = spec + "_" + inst_lag
order sample window xvar spec inst_lag spec_lag xcoef xse xtstat xpvalue ylagcoef ylagse ylagtstat ylagpvalue N groups instruments ar1p ar2p hansenp sarganp rc diagnostics_ok coefficient_sig10 gmm_pass
sort sample window xvar spec inst_lag
export delimited using "reproduced/part1_gmm/gmm_A_B_all_results.csv", replace

preserve
keep if window == "L1"
export delimited using "reproduced/part1_gmm/gmm_A_B_L1_results.csv", replace
restore

preserve
keep if window == "L2"
export delimited using "reproduced/part1_gmm/gmm_A_B_L2_results.csv", replace
restore

log close
exit, clear
