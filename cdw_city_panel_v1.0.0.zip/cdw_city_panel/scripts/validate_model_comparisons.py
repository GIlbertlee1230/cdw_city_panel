"""Arithmetic-only verification of the final table, baselines and frozen results."""
from pathlib import Path
import hashlib,json
import numpy as np
import pandas as pd
ROOT=Path(__file__).resolve().parents[1]
G=ROOT/'analyses/model_comparison';D=G/'results/main_run'
read=lambda p:pd.read_csv(p,float_precision='round_trip')
protocol=json.loads((D/'protocol_frozen.json').read_text())
for rel,digest in protocol['source_hashes'].items():
    assert hashlib.sha256((G/rel).read_bytes()).hexdigest()==digest,rel
saved=json.loads((D/'selected_models_before_target.json').read_text())
record=json.loads((D/'target_evaluation_record.json').read_text())
assert saved['frozen_at_utc']<record['evaluated_at_utc']
assert hashlib.sha256((D/'selected_models_before_target.json').read_bytes()).hexdigest()==record['selected_file_sha256']
for p,n in [('S',685),('D',2969)]:
    folds=read(D/f'{p}_inner_folds.csv');summary=read(D/f'{p}_candidate_summary.csv')
    assert len(folds)==3*n and len(summary)==n and folds.status.eq('ok').all()
    assert not folds.duplicated(['candidate_id','validation_year']).any()
    winner=summary.sort_values(['objective','mean_inner_mae','complexity_order','candidate_id']).iloc[0]
    assert int(winner.candidate_id)==next(x for x in saved['selections']if x['profile']==p)['spec']['candidate_id']
frame=read(D/'target_comparison_2024.csv').set_index('profile')
pred=read(D/'target_predictions_2024.csv')
for profile in ['S','D','DS','training_log_mean','naive_persistence']:
    rows=pred[pred.profile.eq(profile)];assert len(rows)==9
    y=rows.ln_cdw_m3.to_numpy();q=rows.pred_ln_cdw_m3.to_numpy();e=y-q
    values=[1-np.sum(e**2)/np.sum((y-y.mean())**2),np.sqrt(np.mean(e**2)),np.mean(abs(e)),np.mean(abs(np.expm1(-e)))]
    np.testing.assert_allclose(values,frame.loc[profile,['r2','rmse','mae','mape']].astype(float),atol=1e-12,rtol=1e-12)
panel=read(G/'data/model_panel_original.csv').dropna(subset=['ln_cdw_m3','L1_outcome','L2_ntl','L2_urban_rate','L2_fai','L2_disp_income'])
baselines=read(D/'fixed_baselines_by_year.csv');table=read(D/'manuscript_table4_values.csv')
assert len(table)==8
for name in ['training_log_mean','naive_persistence']:
    rmses=[]
    for year in [2021,2022,2023,2024]:
        train=panel[panel.year.between(2016,year-1)];v=panel[panel.year.eq(year)&panel.GBA_dummy.eq(1)]
        q=np.full(len(v),train.ln_cdw_m3.mean())if name=='training_log_mean'else v.L1_outcome.to_numpy()
        e=v.ln_cdw_m3.to_numpy()-q;value=float(np.sqrt(np.mean(e**2)))
        old=baselines[(baselines.baseline==name)&baselines.year.eq(year)].iloc[0]
        np.testing.assert_allclose(value,old.rmse,atol=1e-12,rtol=1e-12)
        if year<2024:rmses.append(value)
    objective=float(np.mean(rmses)+.15*np.std(rmses,ddof=0))
    np.testing.assert_allclose(table[table.profile.eq(name)].objective.iloc[0],objective,atol=1e-12,rtol=1e-12)
a=read(G/'historical_reference/partA_ridge_comparison_2024.csv').set_index('profile')
at=read(G/'historical_reference/partA_ridge_tuning.csv').set_index('profile')
for row in table.to_dict('records'):
    if row['part']=='A':
        ref=a.loc[row['profile']];objective=at.loc[row['profile'],'objective']
    else:
        ref=frame.loc[row['profile']];objective=ref['objective']if row['part']=='B'else row['objective']
    cols=['r2','rmse','mae','mape']
    np.testing.assert_allclose([row[x]for x in cols],ref[cols].astype(float),atol=1e-12,rtol=1e-12)
    np.testing.assert_allclose(row['objective'],objective,atol=1e-12,rtol=1e-12)
outer=read(ROOT/'results/forecasting/forecast_predictions_2024.csv')
inner=read(G/'historical_reference/combined_2024_predictions.csv')
pd.testing.assert_frame_equal(outer,inner)
out=ROOT/'outputs/final_revision';out.mkdir(parents=True,exist_ok=True)
result=dict(status='PASS',model_fits=0,network_calls=0,llm_calls=0,table_rows=8,shared_train_n=103,target_n=9,new_search_fold_records=10962,original_grid_frozen_source_hashes_verified=True,selected_predictions_unchanged=True,fold_specific_baselines_verified=True)
(out/'verification.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
