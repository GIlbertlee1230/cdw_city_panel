"""Offline reproduction of the submitted experiment using English input exports.

Default: rebuild inputs, refit the selected Ridge, verify archived search/audit.
--full-search additionally reruns all 2,969 candidates and may take a long time.
No HTTP requests or LLM calls are made. All output goes to reproduced/.
"""
from pathlib import Path
import argparse,csv,hashlib,json,platform,sys
import numpy as np
import pandas as pd
import sklearn
from scipy.stats import pearsonr
import forecast_models as exp

ROOT=Path(__file__).resolve().parents[1]
FEATURES=exp.FEATURES
def read(rel):return pd.read_csv(ROOT/rel,float_precision='round_trip')
def same(a,b,label,tol=1e-10):
    assert len(a)==len(b),label
    assert np.allclose(np.asarray(a,float),np.asarray(b,float),rtol=tol,atol=tol,equal_nan=True),label
def bool_values(s):return s.astype(str).str.lower().isin(['true','1','1.0'])
def wilson(k,n):
    from scipy.stats import norm
    z=norm.ppf(.975);p=k/n;den=1+z*z/n;center=(p+z*z/(2*n))/den
    margin=z*np.sqrt(p*(1-p)/n+z*z/(4*n*n))/den
    return [float(center-margin),float(center+margin)]
def rebuild_panel():
    y=read('data/compiled/cdw_generation.csv');x=read('data/compiled/city_covariates.csv')
    assert len(y)==139 and len(x)==252
    assert not y.duplicated(['district_name','year']).any()
    assert not x.duplicated(['district_name','year']).any()
    yp=y.set_index(['district_name','year']).C_DW_generation_m3
    xp=x.set_index(['district_name','year'])
    citymap=read('metadata/city_dictionary.csv').set_index('city')
    base=y[y.year.between(2016,2024)].copy()
    base['GBA_dummy']=base.district_name.map(citymap.is_gba)
    base['ln_cdw_m3']=np.log(base.C_DW_generation_m3)
    base['L1_outcome']=[np.log(yp.get((c,int(t)-1),np.nan)) for c,t in zip(base.district_name,base.year)]
    for feat,col,log in [('L2_ntl','ntl_mean_dn',True),('L2_urban_rate','urbanization_rate',False),('L2_fai','fixed_asset_investment_10k_rmb',True),('L2_disp_income','disposable_income_rmb',True)]:
        v=np.array([xp.loc[(c,int(t)-2),col] for c,t in zip(base.district_name,base.year)],float)
        base[feat]=np.log(v) if log else v
    saved=read('data/processed/forecast_panel.csv')
    # Preserve the original experiment row order, rather than reordering cities
    # alphabetically after transliterating their labels.
    frame=saved[['district_name','year']].merge(base,on=['district_name','year'],validate='one_to_one',sort=False)
    assert len(frame)==131
    for col in ['C_DW_generation_m3','ln_cdw_m3','GBA_dummy']+FEATURES:same(frame[col],saved[col],col)
    # Rebuild the three actual prebuilt inputs without altering any source value.
    for lag,tag in [(0,'contemporaneous'),(1,'lag1'),(2,'lag2')]:
        expected=read(f'data/lagged_features/panel_{tag}_2016_2023.csv')
        assert len(expected)==122
        for row in expected.to_dict('records'):
            c,t=row['district_name'],int(row['year']);same([row['C_DW_generation_m3']],[yp.loc[(c,t)]],tag+' outcome')
            for col in x.columns:
                if col not in ['district_name','year']:same([row[col]],[xp.loc[(c,t-lag),col]],tag+' '+col)
    return frame
def verify_part1():
    panel=read('data/screening/panel_L2_2018_2023.csv')
    panel=panel[panel.year.between(2018,2023)].copy()
    expected=read('results/screening/table_part1_selected_l2_feature_evidence.csv')
    contexts=read('results/diagnostics/part1_locked_within_change_correlation_context.csv')
    names={'L2_fai':'ln_fai','L2_urban_rate':'urban_rate_raw','L2_ntl':'ln_ntl','L2_disp_income':'ln_disp_income'}
    rows=[]
    for r in expected.to_dict('records'):
        feat=r['model_feature'];col=names[feat];sub=panel[['district_name','ln_cdw_m3',col,'delta_ln_cdw_m3']].dropna(subset=['ln_cdw_m3',col])
        pooled=float(pearsonr(sub.ln_cdw_m3,sub[col]).statistic)
        demeaned=sub[['ln_cdw_m3',col]]-sub.groupby('district_name')[['ln_cdw_m3',col]].transform('mean')
        within=float(pearsonr(demeaned.ln_cdw_m3,demeaned[col]).statistic)
        diff=sub.dropna(subset=['delta_ln_cdw_m3']);delta=float(pearsonr(diff.delta_ln_cdw_m3,diff[col]).statistic)
        same([pooled],[r['pearson_pooled']],feat+' pooled',1e-8)
        ctx=contexts[contexts.model_feature.eq(feat)].iloc[0]
        same([within,delta],[ctx.pearson_within,ctx.delta_corr],feat+' correlations',1e-8)
        rows.append(dict(model_feature=feat,pairs=len(sub),pooled=pooled,within_city=within,delta_outcome_vs_predictor_level=delta))
    return rows
def verify_search(panel,full=False):
    specs=exp.candidate_specs();saved=read('results/forecasting/candidate_validation_scores.csv')
    assert len(specs)==len(saved)==2969
    byid={r['candidate_id']:r for r in specs}
    for row in saved.to_dict('records'):
        spec=byid[int(row['candidate_id'])]
        assert spec['algorithm']==row['algorithm']
        assert json.loads(json.dumps(spec['params']))==json.loads(row['params_json'])
    order=saved.sort_values(['objective','mean_inner_mae','complexity_order','candidate_id'])
    selected=order.iloc[0];assert int(selected.candidate_id)==23
    archived=read('results/forecasting/temporal_validation_scores.csv')
    assert len(archived)==8907
    folds=[]
    for year in exp.INNER_VALIDATION_YEARS:
        r=exp.evaluate_fold(panel,byid[23],year);old=archived[(archived.candidate_id.eq(23))&(archived.validation_year.eq(year))].iloc[0]
        same([r[k] for k in ['r2','rmse','mae']],[old[k] for k in ['r2','rmse','mae']],f'fold {year}',1e-8)
        assert r['n_train']==old.n_train and r['n_validation']==old.n_validation
        folds.append(r)
    if full:
        _,newfolds,summary,chosen,_=exp.run_inner(panel)
        newfolds.to_csv(ROOT/'outputs/full_search_folds.csv',index=False)
        summary.to_csv(ROOT/'outputs/full_search_candidates.csv',index=False)
        selected=chosen
    return byid,selected,folds
def verify_audit():
    d=read('evidence/records/extraction_audit_labels.csv');assert len(d)==120
    actual=bool_values(d.human_positive);pred=bool_values(d.model_positive)
    tp=int((actual&pred).sum());fp=int((~actual&pred).sum());fn=int((actual&~pred).sum());tn=int((~actual&~pred).sum())
    assert (tp,fp,fn,tn)==(91,3,0,26)
    second=read('evidence/records/independent_audit_comparison.csv')
    exact=int(bool_values(second.exact_decision_agreement).sum());target=int(bool_values(second.target_agreement).sum())
    assert len(second)==30 and exact==28 and target==30
    return dict(n=120,tp=tp,fp=fp,fn=fn,tn=tn,precision=tp/(tp+fp),recall=tp/(tp+fn),accuracy=(tp+tn)/120,
        precision_wilson95=wilson(tp,tp+fp),recall_wilson95=wilson(tp,tp+fn),
        second_review_n=30,target_agreement=target,exact_decision_agreement=exact,target_agreement_wilson95=wilson(target,30))
def integrity():
    manifest=ROOT/'metadata/file_manifest.csv'
    if not manifest.exists():return dict(checked=False,reason='Manifest not finalized during release assembly')
    rows=list(csv.DictReader(manifest.open(encoding='utf-8')));bad=[]
    for r in rows:
        p=ROOT/r['path']
        if not p.is_file() or hashlib.sha256(p.read_bytes()).hexdigest()!=r['sha256']:bad.append(r['path'])
    assert not bad,bad
    return dict(checked=True,files=len(rows),failures=bad)
def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--full-search',action='store_true');args=ap.parse_args()
    (ROOT/'outputs').mkdir(exist_ok=True)
    frame=rebuild_panel();part1=verify_part1();byid,selected,folds=verify_search(frame,args.full_search)
    results,predictions=exp.evaluate_holdout(frame,selected,byid)
    saved=read('results/forecasting/forecast_predictions_2024.csv')
    compare=predictions.merge(saved[['district_name','year','pred_ln_cdw_m3']],on=['district_name','year'],suffixes=('_new','_saved'),validate='one_to_one')
    delta=float(abs(compare.pred_ln_cdw_m3_new-compare.pred_ln_cdw_m3_saved).max());assert delta<1e-8
    unweighted=exp.estimator(byid[5]);assert byid[5]['params']=={'alpha':100.0,'dynamic_weight':1.0}
    train=exp.valid_rows(frame[frame.year.le(2023)]);test=exp.valid_rows(frame[frame.year.eq(2024)])
    unweighted.fit(train[FEATURES],train[exp.TARGET]);w1=exp.metrics(test[exp.TARGET],unweighted.predict(test[FEATURES]))
    report=dict(release='cdw_city_panel-1.0.0',scope='Actual experiment inputs and saved outputs; no source-truth reassessment',
        input_rows=dict(outcomes=139,covariates=252,prebuilt_each=122,forecasting=131,complete=112,train=103,target=9),
        feature_mismatches=0,selected_specification=byid[int(selected.candidate_id)],selected_metrics=exp.metrics(predictions[exp.TARGET],predictions.pred_ln_cdw_m3),
        max_prediction_difference=delta,w1_comparison=w1,inner_selected_folds=folds,part1_recomputed=part1,part0_audit=verify_audit(),
        full_search_rerun=args.full_search,gmm_rerun=False,llm_calls=0,network_requests=0,
        environment=dict(python=platform.python_version(),numpy=np.__version__,pandas=pd.__version__,sklearn=sklearn.__version__),integrity=integrity())
    predictions.to_csv(ROOT/'outputs/selected_predictions.csv',index=False)
    (ROOT/'outputs/verification_report.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    print('PASS: inputs, lags, transformations, prebuilt panels, selected folds, candidate grid, Ridge predictions and audit counts')
    print(json.dumps({k:report[k] for k in ['selected_metrics','max_prediction_difference','full_search_rerun','gmm_rerun','llm_calls','integrity']},indent=2))
if __name__=='__main__':main()
