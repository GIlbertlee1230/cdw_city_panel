"""Broad construction-waste relevance screening for complete source chunks."""
import re

SCREENING_VERSION = 'cdw_object_relevance_v2'
OBJECT_TERMS = (
    '建筑垃圾', '建筑废弃物', '建筑废物', '建筑固体废物', '建设废弃物',
    '建造废弃物', '建拆废弃物', '拆建垃圾', '拆建废料', '建设工程垃圾',
    '工程渣土', '建筑渣土', '工程泥浆', '废弃泥浆', '工程垃圾', '工程弃料',
    '施工废弃物', '施工垃圾', '拆除垃圾', '拆除弃料', '拆除废弃物',
    '拆迁垃圾', '装修垃圾', '装修废弃物', '装潢垃圾', '装饰装修垃圾',
    '余泥渣土', '渣土', '泥浆',
)
ENGLISH_PATTERNS = (
    r'\bconstruction(?:\s*(?:and|&)\s*demolition)?\s*(?:waste|debris)\b',
    r'\bdemolition\s*(?:waste|debris)\b',
    r'\bC\s*&\s*D\s*W\b',
    r'\bCDW\b',
)


def keyword_hits(text):
    text = str(text or '')
    compact = re.sub(r'\s+', '', text)
    hits = [term for term in OBJECT_TERMS if term in compact]
    for pattern in ENGLISH_PATTERNS:
        for match in re.finditer(pattern, text, re.IGNORECASE):
            if match.group() not in hits:
                hits.append(match.group())
    return hits


def screen_chunk(chunk):
    body_hits = keyword_hits(chunk.get('text', ''))
    context_hits = keyword_hits(chunk.get('context_text', ''))
    if body_hits:
        decision, reason = 'retain', 'object_in_chunk'
    elif context_hits:
        decision, reason = 'retain', 'object_in_source_context'
    else:
        decision, reason = 'exclude', 'no_cdw_object_in_chunk_or_context'
    return {
        'screen_decision': decision,
        'screen_reason': reason,
        'body_keyword_hits': body_hits,
        'context_keyword_hits': context_hits,
        'screening_version': SCREENING_VERSION,
    }
