# Supplementary materials

## Part0

1. `Raw documents` contains the 95 production source files. Provincial sources use `province`, municipal plans use `City_plan`, and annual documents use `City_year`. Numbered suffixes distinguish files with the same city and year. `Jieyang_index` is an undated disclosure index. `document_index.csv` maps the renamed files to their original titles, recorded URLs and SHA256 hashes.
2. `Screening rules/screening_rules.py` provides the actual Python object-relevance rules applied before extraction. `screen_chunk` accepts a parsed block with `text` and optional `context_text` and returns the screening decision and matched terms. Parsing and context assembly precede this function.
3. `Prompts and schemas/Prompts.docx` contains the English production and eligibility instructions. The corresponding output contracts are in `JSON schema`. The Word document preserves the instruction text and identifies the schema used for each stage. Chinese source-term examples remain verbatim.
4. `Evaluation` contains two tables. `Accuracy evaluation 120.xlsx` records the v2 human labels, archived MoE predictions and original passages for the previously used development evaluation set. It has 71 positive and 49 negative labels, with 120 correct predictions. NSB-104 uses the author-corrected label of 1. This broader evaluation set includes 2025 passages and has its own scope. `Excluded passage audit 60.xlsx` records the 60 sampled production exclusions and the returned author judgments, all 0. The exclusions were sampled using seed 20261110, with 20 items from each of three prespecified strata after source-text deduplication.
5. `CDW generation panel.csv` contains 133 rows and exactly three columns, `city`, `year`, and `C&DW generation`. The unit is cubic metres. The panel contains the retained 2018–2023 Guangdong observations, the nine 2024 GBA observations, and the Guangzhou/Shenzhen historical support observations for 2015–2017. Mass disclosures use the conversion density of 1.5 tonnes per cubic metre. This is the standardized modelling-label panel.

## Part1

`Predictor panel.csv` contains 252 city-year rows for 2013–2024 and six columns. `NTL` is mean VIIRS nighttime-light intensity, `urbanization_rate` is a proportion, `fixed_asset_investment` is in ten thousand RMB, and `disposable_income` is annual RMB per person. These are the raw contemporaneous predictor values. In the forecasting code, NTL, investment and income are log-transformed, urbanization is retained as a proportion, and all four structural predictors are lagged by two calendar years.

## Part2

The code reads the Part0 and Part1 CSV files directly. It constructs log generation, its one-year lag, and the four two-year-lagged predictors. Complete common inputs yield 103 training observations for 2016–2023 and nine 2024 GBA target observations.

`train_models.py` performs the fitting, `models.py` preserves the estimator definitions, and `parameter_grid.json` specifies the actual 7,848 configurations across 11 algorithm families and three input profiles. Each profile uses the same three validation years, 2021, 2022 and 2023. Candidate ranking uses mean annual log-RMSE plus 0.15 times its population standard deviation, followed by mean MAE, model complexity and candidate ID. Median imputation, standardization and feature weighting are fitted within each training fold. The final joint Ridge uses alpha 158.48931924611173 and dynamic weight 3.

From the package root, install the recorded dependencies and replay the three input groups at the joint model parameters.

```bash
python3 -m pip install -r Part2/requirements.txt
python3 Part2/train_models.py
```

To rerun the complete temporal parameter search, choose a fresh output directory.

```bash
python3 Part2/train_models.py --search --workers 4 --output Part2/search_outputs
```

The complete grid is supplied explicitly. Its Ridge search has the expanded alpha and dynamic-weight combinations, while the other families retain their original grids. The recorded numerical environment used Python 3.13.5. Reconstructed transformations can differ from historical serialized features at machine precision.

Outputs are created only when the training code is run. They contain model metrics, city-level errors and, when requested, the full validation results, warnings, failures and model-selection record.
