"""Estimator definitions retained from the original forecasting implementation."""

import itertools

import json

import math

import platform

import sys

from pathlib import Path

import numpy as np

import pandas as pd

import sklearn

from sklearn.base import BaseEstimator, TransformerMixin

from sklearn.ensemble import ExtraTreesRegressor, GradientBoostingRegressor, RandomForestRegressor

from sklearn.gaussian_process import GaussianProcessRegressor

from sklearn.gaussian_process.kernels import ConstantKernel, RBF

from sklearn.impute import SimpleImputer

from sklearn.kernel_ridge import KernelRidge

from sklearn.linear_model import ElasticNet, HuberRegressor, Ridge

from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

from sklearn.neural_network import MLPRegressor

from sklearn.pipeline import Pipeline

from sklearn.preprocessing import PolynomialFeatures, StandardScaler

from sklearn.svm import SVR

SEED = 20260609

class ColumnWeighter(BaseEstimator, TransformerMixin):
    def __init__(self, weights=None):
        self.weights = weights

    def fit(self, x, y=None):
        return self

    def transform(self, x):
        if self.weights is None:
            return x
        return np.asarray(x, dtype=float) * np.asarray(self.weights, dtype=float)

def weight_vector(dynamic_weight):
    return [float(dynamic_weight), 1.0, 1.0, 1.0, 1.0]

def estimator(spec):
    algorithm = spec["algorithm"]
    params = dict(spec["params"])
    dynamic_weight = params.pop("dynamic_weight", 1.0)
    weighted_steps = [
        ("imputer", SimpleImputer(strategy="median")),
        ("scale", StandardScaler()),
        ("weight", ColumnWeighter(weight_vector(dynamic_weight))),
    ]

    if algorithm == "Ridge":
        return Pipeline([*weighted_steps, ("model", Ridge(**params))])
    if algorithm == "ElasticNet":
        return Pipeline(
            [*weighted_steps, ("model", ElasticNet(max_iter=50000, random_state=SEED, **params))]
        )
    if algorithm == "Huber":
        return Pipeline([*weighted_steps, ("model", HuberRegressor(max_iter=5000, **params))])
    if algorithm == "SVR":
        return Pipeline([*weighted_steps, ("model", SVR(kernel="rbf", **params))])
    if algorithm == "KRR":
        return Pipeline([*weighted_steps, ("model", KernelRidge(kernel="rbf", **params))])
    if algorithm == "PolynomialRidge":
        degree = params.pop("degree")
        alpha = params.pop("alpha")
        return Pipeline(
            [
                *weighted_steps,
                ("poly", PolynomialFeatures(degree=degree, include_bias=False)),
                ("model", Ridge(alpha=alpha)),
            ]
        )
    if algorithm == "GPR":
        length_scale = params.pop("length_scale")
        alpha = params.pop("alpha")
        kernel = ConstantKernel(1.0, constant_value_bounds="fixed") * RBF(
            length_scale=length_scale, length_scale_bounds="fixed"
        )
        return Pipeline(
            [
                *weighted_steps,
                ("model", GaussianProcessRegressor(kernel=kernel, alpha=alpha, normalize_y=True, random_state=SEED)),
            ]
        )
    if algorithm == "ExtraTrees":
        return Pipeline(
            [
                ("imputer", SimpleImputer(strategy="median")),
                ("model", ExtraTreesRegressor(n_estimators=600, random_state=SEED, n_jobs=-1, **params)),
            ]
        )
    if algorithm == "RandomForest":
        return Pipeline(
            [
                ("imputer", SimpleImputer(strategy="median")),
                ("model", RandomForestRegressor(n_estimators=600, random_state=SEED, n_jobs=-1, **params)),
            ]
        )
    if algorithm == "GradientBoosting":
        return Pipeline(
            [
                ("imputer", SimpleImputer(strategy="median")),
                ("model", GradientBoostingRegressor(random_state=SEED, **params)),
            ]
        )
    if algorithm == "MLP":
        return Pipeline(
            [
                *weighted_steps,
                (
                    "model",
                    MLPRegressor(
                        max_iter=3000,
                        early_stopping=True,
                        validation_fraction=0.25,
                        random_state=SEED,
                        **params,
                    ),
                ),
            ]
        )
    raise ValueError(algorithm)
