"""Read the two disclosed panels, reconstruct features, and train forecasting models."""
import os

for variable in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','VECLIB_MAXIMUM_THREADS'):
    os.environ[variable]='1'

import argparse
import sys
from concurrent.futures import ProcessPoolExecutor
import json
from pathlib import Path
import warnings

sys.dont_write_bytecode=True

import numpy as np
import pandas as pd

import models

ROOT=Path(__file__).resolve().parent
FEATURES=['L1_outcome','L2_ntl','L2_urban_rate','L2_fai','L2_disp_income']
PROFILES={'S':FEATURES[1:],'D':FEATURES[:1],'DS':FEATURES}
GBA={'Guangzhou','Shenzhen','Zhuhai','Foshan','Huizhou','Dongguan','Zhongshan','Jiangmen','Zhaoqing'}
ALPHA=158.48931924611173
TRAIN=None


def model_panel():
    outcome=pd.read_csv(ROOT.parent/'Part0/CDW generation panel.csv',float_precision='round_trip')
    predictors=pd.read_csv(ROOT.parent/'Part1/Predictor panel.csv',float_precision='round_trip')
    assert outcome.columns.tolist()==['city','year','C&DW generation']
    assert predictors.columns.tolist()==['city','year','NTL','urbanization_rate','fixed_asset_investment','disposable_income']
    assert not outcome.duplicated(['city','year']).any()
    assert not predictors.duplicated(['city','year']).any()
    if (outcome['C&DW generation']<=0).any():
        raise ValueError('Outcome values must be positive before logarithms.')
    outcome['ln_cdw_m3']=np.log(outcome['C&DW generation'])
    lag=outcome[['city','year','ln_cdw_m3']].copy()
    lag['year']+=1
    lag=lag.rename(columns={'ln_cdw_m3':'L1_outcome'})
    lagged=predictors.copy()
    for raw,target in [('NTL','L2_ntl'),('fixed_asset_investment','L2_fai'),('disposable_income','L2_disp_income')]:
        if (lagged[raw].dropna()<=0).any():
            raise ValueError('Log-transformed predictors must be positive.')
        lagged[target]=np.log(lagged[raw])
    lagged['L2_urban_rate']=lagged['urbanization_rate']
    lagged['year']+=2
    panel=outcome.merge(lag,on=['city','year'],how='left',validate='one_to_one')
    panel=panel.merge(lagged[['city','year',*FEATURES[1:]]],on=['city','year'],how='left',validate='one_to_one')
    panel=panel[panel.year.between(2016,2024)].sort_values(['year','city'],kind='stable')
    panel=panel.dropna(subset=['ln_cdw_m3',*FEATURES])
    train=panel[panel.year.le(2023)].copy()
    target=panel[panel.year.eq(2024)&panel.city.isin(GBA)].copy()
    assert len(train)==103 and len(target)==9
    return train,target


def estimator(profile,spec):
    original=models.weight_vector
    models.weight_vector=lambda weight: ([1.]*4 if profile=='S' else [float(weight)] if profile=='D' else original(weight))
    try:
        model=models.estimator(spec)
    finally:
        models.weight_vector=original
    if spec['algorithm'] in ('ExtraTrees','RandomForest'):
        model.set_params(model__n_jobs=1)
    return model


def metric(actual,predicted):
    actual=np.asarray(actual,dtype=float)
    predicted=np.asarray(predicted,dtype=float)
    if not np.isfinite(predicted).all():
        raise ValueError('Nonfinite predictions.')
    residual=actual-predicted
    return dict(log_r2=float(1-np.sum(residual**2)/np.sum((actual-actual.mean())**2)),
        log_rmse=float(np.sqrt(np.mean(residual**2))),log_mae=float(np.mean(np.abs(residual))),
        mape_percent=float(np.mean(np.abs(np.expm1(predicted-actual)))*100))


def initialize():
    global TRAIN
    TRAIN,_=model_panel()


def candidate_result(spec):
    features=PROFILES[spec['profile']]
    folds,notes,errors=[],[],[]
    for year in (2021,2022,2023):
        fit=TRAIN[TRAIN.year.lt(year)]
        valid=TRAIN[TRAIN.year.eq(year)&TRAIN.city.isin(GBA)]
        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter('always')
            try:
                model=estimator(spec['profile'],spec)
                model.fit(fit[features],fit.ln_cdw_m3)
                predicted=np.asarray(model.predict(valid[features]),dtype=float)
                folds.append(dict(year=year,train_n=len(fit),validation_n=len(valid),**metric(valid.ln_cdw_m3,predicted)))
            except Exception as error:
                errors.append(dict(year=year,error_type=type(error).__name__,message=str(error)))
            notes.extend(dict(year=year,category=item.category.__name__,message=str(item.message)) for item in caught)
    eligible=len(folds)==3 and not errors
    result=dict(candidate_id=spec['job_id'],profile=spec['profile'],algorithm=spec['algorithm'],
        params=spec['params'],eligible=eligible,folds=folds,warnings=notes,errors=errors,
        complexity_order=spec['complexity_order'],numeric_candidate_id=spec['candidate_id'])
    if eligible:
        rmse=np.array([fold['log_rmse'] for fold in folds])
        result.update(mean_inner_rmse=float(rmse.mean()),std_inner_rmse=float(rmse.std(ddof=0)),
            mean_inner_mae=float(np.mean([fold['log_mae'] for fold in folds])),
            objective=float(rmse.mean()+.15*rmse.std(ddof=0)))
    return result


def search(grid,output,workers):
    results=[]
    with (output/'validation_results.jsonl').open('w',encoding='utf-8') as stream:
        with ProcessPoolExecutor(max_workers=workers,initializer=initialize) as pool:
            for index,result in enumerate(pool.map(candidate_result,grid,chunksize=8),1):
                stream.write(json.dumps(result,ensure_ascii=False,allow_nan=False)+'\n')
                stream.flush()
                results.append(result)
                if index%250==0 or index==len(grid):
                    print(f'Validated {index}/{len(grid)} candidates',flush=True)
    ranking=pd.DataFrame([{key:value for key,value in result.items() if key not in ('folds','warnings','errors')} for result in results if result['eligible']])
    if ranking.empty:
        raise ValueError('No candidate completed all three validation folds. Inspect validation_results.jsonl.')
    ranking=ranking.sort_values(['objective','mean_inner_mae','complexity_order','numeric_candidate_id'],kind='stable')
    ranking.to_csv(output/'validation_ranking.csv',index=False)
    winners=ranking.drop_duplicates('profile')
    if set(winners.profile)!=set(PROFILES):
        raise ValueError('At least one profile has no eligible candidate.')
    selected=winners.candidate_id.tolist()
    (output/'selection_before_target.json').write_text(json.dumps(dict(selected_ids=selected,
        score='mean annual log-RMSE + 0.15 population standard deviation',
        validation_years=[2021,2022,2023],failed_candidates=sum(not result['eligible'] for result in results)),indent=2),encoding='utf-8')
    return [spec for spec in grid if spec['job_id'] in selected]


def evaluate(train,target,specs,output):
    summaries,city_rows=[],[]
    for spec in specs:
        features=PROFILES[spec['profile']]
        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter('always')
            model=estimator(spec['profile'],spec)
            model.fit(train[features],train.ln_cdw_m3)
            predictions=np.asarray(model.predict(target[features]),dtype=float)
        summaries.append(dict(candidate_id=spec['job_id'],profile=spec['profile'],algorithm=spec['algorithm'],
            params_json=json.dumps(spec['params'],sort_keys=True),warning_count=len(caught),**metric(target.ln_cdw_m3,predictions)))
        for row,prediction in zip(target.itertuples(index=False),predictions):
            actual_log=float(row.ln_cdw_m3)
            actual=float(np.exp(actual_log))
            predicted=float(np.exp(prediction))
            city_rows.append(dict(candidate_id=spec['job_id'],profile=spec['profile'],city=row.city,year=int(row.year),
                actual_m3=actual,predicted_m3=predicted,actual_log=actual_log,predicted_log=float(prediction),
                signed_error_percent=float(np.expm1(prediction-actual_log)*100),
                ape_percent=float(abs(np.expm1(prediction-actual_log))*100)))
    pd.DataFrame(summaries).to_csv(output/'target_metrics.csv',index=False)
    pd.DataFrame(city_rows).to_csv(output/'city_predictions.csv',index=False)
    print(pd.DataFrame(summaries).to_string(index=False))


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--search',action='store_true',help='Rerun all 7,848 configurations across the three time folds.')
    parser.add_argument('--workers',type=int,default=4)
    parser.add_argument('--output',type=Path,default=ROOT/'outputs')
    args=parser.parse_args()
    if args.workers<1:
        parser.error('--workers must be positive')
    if args.output.exists() and any(args.output.iterdir()):
        raise FileExistsError('Output directory is nonempty. Choose a new --output directory.')
    args.output.mkdir(parents=True,exist_ok=True)
    train,target=model_panel()
    grid=json.loads((ROOT/'parameter_grid.json').read_text(encoding='utf-8'))
    assert len(grid)==7848 and len({spec['algorithm'] for spec in grid})==11
    if args.search:
        specs=search(grid,args.output,args.workers)
    else:
        # Refit the three input groups at the joint model's selected alpha and weight.
        specs=[]
        for profile in PROFILES:
            params=dict(alpha=ALPHA)
            if profile!='S':
                params['dynamic_weight']=3.0
            specs.append(next(spec for spec in grid if spec['profile']==profile and spec['algorithm']=='Ridge' and spec['params']==params))
    evaluate(train,target,specs,args.output)


if __name__=='__main__':
    main()
